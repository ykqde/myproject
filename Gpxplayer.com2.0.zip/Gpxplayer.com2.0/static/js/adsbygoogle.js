(function (sttc) {
  /* 
   
   Copyright The Closure Library Authors. 
   SPDX-License-Identifier: Apache-2.0 
  */
  'use strict';
  var aa = {},
    m = this || self;

  function ba(a) {
    a = a.split(".");
    for (var b = m, c = 0; c < a.length; c++)
      if (b = b[a[c]], null == b) return null;
    return b
  }

  function ca(a) {
    var b = typeof a;
    return "object" != b ? b : a ? Array.isArray(a) ? "array" : b : "null"
  }

  function da(a) {
    var b = ca(a);
    return "array" == b || "object" == b && "number" == typeof a.length
  }

  function ea(a) {
    var b = typeof a;
    return "object" == b && null != a || "function" == b
  }

  function fa(a) {
    return Object.prototype.hasOwnProperty.call(a, ha) && a[ha] || (a[ha] = ++ia)
  }
  var ha = "closure_uid_" + (1E9 * Math.random() >>> 0),
    ia = 0;

  function ja(a, b, c) {
    return a.call.apply(a.bind, arguments)
  }

  function ka(a, b, c) {
    if (!a) throw Error();
    if (2 < arguments.length) {
      var d = Array.prototype.slice.call(arguments, 2);
      return function () {
        var e = Array.prototype.slice.call(arguments);
        Array.prototype.unshift.apply(e, d);
        return a.apply(b, e)
      }
    }
    return function () {
      return a.apply(b, arguments)
    }
  }

  function la(a, b, c) {
    Function.prototype.bind && -1 != Function.prototype.bind.toString().indexOf("native code") ? la = ja : la = ka;
    return la.apply(null, arguments)
  }

  function ma(a, b) {
    var c = Array.prototype.slice.call(arguments, 1);
    return function () {
      var d = c.slice();
      d.push.apply(d, arguments);
      return a.apply(this, d)
    }
  }

  function na(a, b) {
    a = a.split(".");
    var c = m;
    a[0] in c || "undefined" == typeof c.execScript || c.execScript("var " + a[0]);
    for (var d; a.length && (d = a.shift());) a.length || void 0 === b ? c[d] && c[d] !== Object.prototype[d] ? c = c[d] : c = c[d] = {} : c[d] = b
  }

  function oa(a) {
    return a
  };
  let pa = (new Date).getTime();
  var qa = {};

  function ra(a) {
    return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]
  }

  function sa(a, b) {
    let c = 0;
    a = ra(String(a)).split(".");
    b = ra(String(b)).split(".");
    const d = Math.max(a.length, b.length);
    for (let g = 0; 0 == c && g < d; g++) {
      var e = a[g] || "",
        f = b[g] || "";
      do {
        e = /(\d*)(\D*)(.*)/.exec(e) || ["", "", "", ""];
        f = /(\d*)(\D*)(.*)/.exec(f) || ["", "", "", ""];
        if (0 == e[0].length && 0 == f[0].length) break;
        c = ta(0 == e[1].length ? 0 : parseInt(e[1], 10), 0 == f[1].length ? 0 : parseInt(f[1], 10)) || ta(0 == e[2].length, 0 == f[2].length) || ta(e[2], f[2]);
        e = e[3];
        f = f[3]
      } while (0 == c)
    }
    return c
  }

  function ta(a, b) {
    return a < b ? -1 : a > b ? 1 : 0
  };

  function ua() {
    var a = m.navigator;
    return a && (a = a.userAgent) ? a : ""
  }

  function n(a) {
    return -1 != ua().indexOf(a)
  };

  function wa() {
    return n("Trident") || n("MSIE")
  }

  function xa() {
    return (n("Chrome") || n("CriOS")) && !n("Edge") || n("Silk")
  }

  function Aa(a) {
    const b = {};
    a.forEach(c => {
      b[c[0]] = c[1]
    });
    return c => b[c.find(d => d in b)] || ""
  }

  function Ba() {
    var a = ua();
    if (wa()) {
      var b = /rv: *([\d\.]*)/.exec(a);
      if (b && b[1]) a = b[1];
      else {
        b = "";
        var c = /MSIE +([\d\.]+)/.exec(a);
        if (c && c[1])
          if (a = /Trident\/(\d.\d)/.exec(a), "7.0" == c[1])
            if (a && a[1]) switch (a[1]) {
              case "4.0":
                b = "8.0";
                break;
              case "5.0":
                b = "9.0";
                break;
              case "6.0":
                b = "10.0";
                break;
              case "7.0":
                b = "11.0"
            } else b = "7.0";
            else b = c[1];
        a = b
      }
      return a
    }
    c = RegExp("([A-Z][\\w ]+)/([^\\s]+)\\s*(?:\\((.*?)\\))?", "g");
    b = [];
    let d;
    for (; d = c.exec(a);) b.push([d[1], d[2], d[3] || void 0]);
    a = Aa(b);
    return n("Opera") ? a(["Version", "Opera"]) :
      n("Edge") ? a(["Edge"]) : n("Edg/") ? a(["Edg"]) : n("Silk") ? a(["Silk"]) : xa() ? a(["Chrome", "CriOS", "HeadlessChrome"]) : (a = b[2]) && a[1] || ""
  };

  function Ca(a, b) {
    if ("string" === typeof a) return "string" !== typeof b || 1 != b.length ? -1 : a.indexOf(b, 0);
    for (let c = 0; c < a.length; c++)
      if (c in a && a[c] === b) return c;
    return -1
  }

  function Da(a, b) {
    const c = a.length,
      d = "string" === typeof a ? a.split("") : a;
    for (let e = 0; e < c; e++) e in d && b.call(void 0, d[e], e, a)
  }

  function Ea(a, b) {
    const c = a.length,
      d = [];
    let e = 0;
    const f = "string" === typeof a ? a.split("") : a;
    for (let g = 0; g < c; g++)
      if (g in f) {
        const h = f[g];
        b.call(void 0, h, g, a) && (d[e++] = h)
      } return d
  }

  function Fa(a, b) {
    const c = a.length,
      d = Array(c),
      e = "string" === typeof a ? a.split("") : a;
    for (let f = 0; f < c; f++) f in e && (d[f] = b.call(void 0, e[f], f, a));
    return d
  }

  function Ga(a, b) {
    const c = a.length,
      d = "string" === typeof a ? a.split("") : a;
    for (let e = 0; e < c; e++)
      if (e in d && b.call(void 0, d[e], e, a)) return !0;
    return !1
  }

  function Ha(a, b) {
    a: {
      const c = a.length,
        d = "string" === typeof a ? a.split("") : a;
      for (let e = 0; e < c; e++)
        if (e in d && b.call(void 0, d[e], e, a)) {
          b = e;
          break a
        } b = -1
    }
    return 0 > b ? null : "string" === typeof a ? a.charAt(b) : a[b]
  }

  function Ia(a, b) {
    a: {
      var c = a.length;
      const d = "string" === typeof a ? a.split("") : a;
      for (--c; 0 <= c; c--)
        if (c in d && b.call(void 0, d[c], c, a)) {
          b = c;
          break a
        } b = -1
    }
    return 0 > b ? null : "string" === typeof a ? a.charAt(b) : a[b]
  }

  function Ja(a, b) {
    return 0 <= Ca(a, b)
  }

  function Ka(a) {
    const b = a.length;
    if (0 < b) {
      const c = Array(b);
      for (let d = 0; d < b; d++) c[d] = a[d];
      return c
    }
    return []
  };

  function La(a) {
    La[" "](a);
    return a
  }
  La[" "] = function () {};
  var Ma = wa();
  !n("Android") || xa();
  xa();
  !n("Safari") || xa();
  var Na = {},
    Oa = null;

  function Qa(a) {
    var b;
    void 0 === b && (b = 0);
    Ra();
    b = Na[b];
    const c = Array(Math.floor(a.length / 3)),
      d = b[64] || "";
    let e = 0,
      f = 0;
    for (; e < a.length - 2; e += 3) {
      var g = a[e],
        h = a[e + 1],
        k = a[e + 2],
        l = b[g >> 2];
      g = b[(g & 3) << 4 | h >> 4];
      h = b[(h & 15) << 2 | k >> 6];
      k = b[k & 63];
      c[f++] = l + g + h + k
    }
    l = 0;
    k = d;
    switch (a.length - e) {
      case 2:
        l = a[e + 1], k = b[(l & 15) << 2] || d;
      case 1:
        a = a[e], c[f] = b[a >> 2] + b[(a & 3) << 4 | l >> 4] + k + d
    }
    return c.join("")
  }

  function Sa(a) {
    var b = [];
    Ta(a, function (c) {
      b.push(c)
    });
    return b
  }

  function Ta(a, b) {
    function c(k) {
      for (; d < a.length;) {
        var l = a.charAt(d++),
          q = Oa[l];
        if (null != q) return q;
        if (!/^[\s\xa0]*$/.test(l)) throw Error("Unknown base64 encoding at char: " + l);
      }
      return k
    }
    Ra();
    for (var d = 0;;) {
      var e = c(-1),
        f = c(0),
        g = c(64),
        h = c(64);
      if (64 === h && -1 === e) break;
      b(e << 2 | f >> 4);
      64 != g && (b(f << 4 & 240 | g >> 2), 64 != h && b(g << 6 & 192 | h))
    }
  }

  function Ra() {
    if (!Oa) {
      Oa = {};
      for (var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), b = ["+/=", "+/", "-_=", "-_.", "-_"], c = 0; 5 > c; c++) {
        var d = a.concat(b[c].split(""));
        Na[c] = d;
        for (var e = 0; e < d.length; e++) {
          var f = d[e];
          void 0 === Oa[f] && (Oa[f] = e)
        }
      }
    }
  };
  var Ua = "undefined" !== typeof Uint8Array,
    Va = {};
  let Xa;
  var Ya = class {
    constructor(a) {
      if (Va !== Va) throw Error("illegal external caller");
      this.ta = a;
      if (null != a && 0 === a.length) throw Error("ByteString should be constructed with non-empty values");
    }
    isEmpty() {
      return null == this.ta
    }
  };
  const Za = Symbol(void 0);

  function $a(a, b) {
    Object.isFrozen(a) || (Za ? a[Za] |= b : void 0 !== a.P ? a.P |= b : Object.defineProperties(a, {
      P: {
        value: b,
        configurable: !0,
        writable: !0,
        enumerable: !1
      }
    }))
  }

  function ab(a) {
    let b;
    Za ? b = a[Za] : b = a.P;
    return null == b ? 0 : b
  }

  function bb(a) {
    $a(a, 1);
    return a
  }

  function p(a) {
    return Array.isArray(a) ? !!(ab(a) & 2) : !1
  }

  function cb(a) {
    if (!Array.isArray(a)) throw Error("cannot mark non-array as immutable");
    $a(a, 2)
  }

  function db(a, b) {
    if (!Array.isArray(a)) throw Error("cannot mark non-array as mutable");
    b ? $a(a, 8) : Object.isFrozen(a) || (Za ? a[Za] &= -9 : void 0 !== a.P && (a.P &= -9))
  };

  function eb(a) {
    return null !== a && "object" === typeof a && !Array.isArray(a) && a.constructor === Object
  }
  let fb;
  var gb = Object.freeze(bb([]));

  function hb(a) {
    if (p(a.u)) throw Error("Cannot mutate an immutable Message");
  }

  function ib(a) {
    return {
      value: a,
      configurable: !1,
      writable: !1,
      enumerable: !1
    }
  };

  function jb(a, b) {
    if (Array.isArray(a)) return new b(a)
  };

  function kb(a) {
    switch (typeof a) {
      case "number":
        return isFinite(a) ? a : String(a);
      case "object":
        if (a && !Array.isArray(a)) {
          if (Ua && null != a && a instanceof Uint8Array) return Qa(a);
          if (a instanceof Ya) {
            var b = a.ta;
            b = null == b || "string" === typeof b ? b : Ua && b instanceof Uint8Array ? Qa(b) : null;
            return null == b ? "" : a.ta = b
          }
        }
    }
    return a
  };

  function lb(a, b = mb) {
    return nb(a, b)
  }

  function ob(a, b) {
    if (null != a) {
      if (Array.isArray(a)) a = nb(a, b);
      else if (eb(a)) {
        const c = {};
        for (let d in a) Object.prototype.hasOwnProperty.call(a, d) && (c[d] = ob(a[d], b));
        a = c
      } else a = b(a);
      return a
    }
  }

  function nb(a, b) {
    const c = a.slice();
    for (let d = 0; d < c.length; d++) c[d] = ob(c[d], b);
    Array.isArray(a) && ab(a) & 1 && bb(c);
    return c
  }

  function pb(a) {
    if (a && "object" == typeof a && a.toJSON) return a.toJSON();
    a = kb(a);
    return Array.isArray(a) ? lb(a, pb) : a
  }

  function mb(a) {
    return Ua && null != a && a instanceof Uint8Array ? new Uint8Array(a) : a
  };

  function qb(a) {
    return a.i || (a.i = a.u[a.j + a.N] = {})
  }

  function r(a, b, c = !1) {
    return -1 === b ? null : b >= a.j ? a.i ? a.i[b] : void 0 : c && a.i && (c = a.i[b], null != c) ? c : a.u[b + a.N]
  }

  function t(a, b, c, d = !1, e = !1) {
    e || hb(a);
    b < a.j && !d ? (a.u[b + a.N] = c, void 0 !== a.i && b in a.i && delete a.i[b]) : qb(a)[b] = c;
    return a
  }

  function rb(a, b) {
    return Array.isArray(r(a, sb(a, tb, b)))
  }

  function ub(a, b, c = !0, d) {
    let e = r(a, b, d);
    Array.isArray(e) || (e = gb);
    if (p(a.u)) c && (cb(e), Object.freeze(e));
    else if (e === gb || p(e)) e = bb(e.slice()), t(a, b, e, d);
    return e
  }

  function vb(a, b) {
    a = r(a, b);
    return null == a ? a : !!a
  }

  function u(a, b, c) {
    a = r(a, b);
    return null == a ? c : a
  }

  function w(a, b, c = !1) {
    a = vb(a, b);
    return null == a ? c : a
  }

  function wb(a, b) {
    a = r(a, b);
    a = null == a ? a : +a;
    return null == a ? 0 : a
  }

  function xb(a, b, c) {
    null == c ? c = gb : bb(c);
    return t(a, b, c)
  }

  function yb(a, b, c) {
    hb(a);
    0 !== c ? t(a, b, c) : t(a, b, void 0, !1);
    return a
  }

  function zb(a, b, c, d) {
    hb(a);
    (c = Ab(a, c)) && c !== b && null != d && (a.h && c in a.h && (a.h[c] = void 0), t(a, c));
    return t(a, b, d)
  }

  function sb(a, b, c) {
    return Ab(a, b) === c ? c : -1
  }

  function Ab(a, b) {
    let c = 0;
    for (let d = 0; d < b.length; d++) {
      const e = b[d];
      null != r(a, e) && (0 !== c && t(a, c, void 0, !1, !0), c = e)
    }
    return c
  }

  function y(a, b, c) {
    {
      a.h || (a.h = {});
      const d = a.h[c];
      if (d) b = d;
      else if (b = jb(r(a, c, !1), b)) a.h[c] = b, p(a.u) && cb(b.u)
    }
    if (null == b) return b;
    p(b.u) && !p(a.u) && (b = b.sa(qa), t(a, c, b.u, !1), a.h[c] = b);
    return b
  }

  function Bb(a, b, c, d = !0) {
    a.h || (a.h = {});
    var e = p(a.u);
    let f = a.h[c];
    const g = ub(a, c, !0, !1),
      h = e || p(g);
    if (!f) {
      f = [];
      e = e || h;
      for (let l = 0; l < g.length; l++) {
        var k = g[l];
        e = e || p(k);
        k = jb(k, b);
        void 0 !== k && (f.push(k), h && cb(k.u))
      }
      a.h[c] = f;
      db(g, !e)
    }
    b = h || d;
    d = p(f);
    b && !d && (Object.isFrozen(f) && (a.h[c] = f = f.slice()), cb(f), Object.freeze(f));
    !b && d && (a.h[c] = f = f.slice());
    return f
  }

  function A(a, b, c) {
    const d = p(a.u);
    b = Bb(a, b, c, d);
    a = ub(a, c, !1);
    if (!(c = d) && (c = a)) {
      if (!Array.isArray(a)) throw Error("cannot check mutability state of non-array");
      c = !(ab(a) & 8)
    }
    if (c) {
      for (c = 0; c < b.length; c++) {
        const e = b[c];
        e && p(e.u) && !d && (b[c] = b[c].sa(qa), a[c] = b[c].u)
      }
      db(a, !0)
    }
    return b
  }

  function Cb(a, b, c) {
    hb(a);
    a.h || (a.h = {});
    let d;
    null == c ? d = c = void 0 : d = c.u;
    a.h[b] = c;
    return t(a, b, d)
  }

  function Db(a, b, c, d) {
    hb(a);
    a.h || (a.h = {});
    let e;
    null != d ? e = d.u : e = d = void 0;
    a.h[b] = d;
    return zb(a, b, c, e)
  }

  function Eb(a, b, c) {
    hb(a);
    let d;
    if (null != c) {
      d = bb([]);
      let e = !1;
      for (let f = 0; f < c.length; f++) d[f] = c[f].u, e = e || p(d[f]);
      a.h || (a.h = {});
      a.h[b] = c;
      db(d, !e)
    } else a.h && (a.h[b] = void 0), d = gb;
    return t(a, b, d)
  }

  function B(a, b) {
    return u(a, b, "")
  }

  function Fb(a, b, c) {
    return u(a, sb(a, c, b), 0)
  }

  function Gb(a, b, c, d) {
    return y(a, b, sb(a, d, c))
  };

  function Hb(a, b) {
    if (null == b || "" == b) return new a;
    b = JSON.parse(b);
    if (!Array.isArray(b)) throw Error("Expected to deserialize an Array but got " + ca(b) + ": " + b);
    Ib = b;
    a = new a(b);
    Ib = null;
    return a
  }
  var Jb = class {
    constructor(a, b, c) {
      a || (a = Ib);
      Ib = null;
      var d = this.constructor.messageId;
      a || (a = d ? [d] : []);
      this.N = (d ? 0 : -1) - (this.constructor.h || 0);
      this.h = void 0;
      this.u = a;
      a: {
        d = this.u.length;a = d - 1;
        if (d && (d = this.u[a], eb(d))) {
          this.j = a - this.N;
          this.i = d;
          break a
        }
        void 0 !== b && -1 < b ? (this.j = Math.max(b, a + 1 - this.N), this.i = void 0) : this.j = Number.MAX_VALUE
      }
      if (c)
        for (b = 0; b < c.length; b++)
          if (a = c[b], a < this.j) a += this.N, (d = this.u[a]) ? Array.isArray(d) && bb(d) : this.u[a] = gb;
          else {
            d = qb(this);
            let e = d[a];
            e ? Array.isArray(e) && bb(e) : d[a] = gb
          }
    }
    toJSON() {
      const a =
        this.u;
      return fb ? a : lb(a, pb)
    }
  };

  function Kb(a, b) {
    return kb(b)
  }
  let Ib;
  var Lb = class extends Jb {
    sa() {
      return this
    }
  };
  Object.defineProperties(Lb, {
    [Symbol.hasInstance]: ib(() => {
      throw Error("Cannot perform instanceof checks for MutableMessage");
    })
  });

  function Mb(a, b, c, d, e, f) {
    (a = a.h && a.h[c]) ? Array.isArray(a) ? (e = f.da ? bb(a.slice()) : a, Eb(b, c, e)) : Cb(b, c, a): (Ua && d instanceof Uint8Array ? e = d.length ? new Ya(new Uint8Array(d)) : Xa || (Xa = new Ya(null)) : (Array.isArray(d) && (e ? cb(d) : Array.isArray(d) && ab(d) & 1 && f.da && (d = d.slice())), e = d), t(b, c, e))
  };
  class D extends Lb {
    sa(a) {
      if (a !== qa) throw Error("requires a valid immutable API token");
      if (p(this.u)) {
        ({
          da: a
        } = {
          da: !0
        });
        a = {
          da: a
        };
        const c = p(this.u);
        if (c && !a.da) throw Error("copyRepeatedFields must be true for frozen messages");
        const d = new this.constructor;
        this.Ka && (d.Ka = this.Ka.slice());
        const e = this.u;
        for (let f = 0; f < e.length; f++) {
          const g = e[f];
          if (f === e.length - 1 && eb(g))
            for (b in g) {
              if (!Object.prototype.hasOwnProperty.call(g, b)) continue;
              const h = +b;
              Number.isNaN(h) ? qb(d)[b] = g[b] : Mb(this, d, h, g[b], c, a)
            } else Mb(this,
              d, f - this.N, g, c, a)
        }
        var b = d
      } else b = this;
      return b
    }
  }
  Object.defineProperties(D, {
    [Symbol.hasInstance]: ib(Object[Symbol.hasInstance])
  });
  var Ob = class extends D {
      constructor(a) {
        super(a, -1, Nb)
      }
    },
    Pb = class extends D {
      constructor(a) {
        super(a)
      }
    },
    Nb = [2, 3];

  function Qb(a, b) {
    this.i = a === Rb && b || "";
    this.h = Sb
  }
  var Sb = {},
    Rb = {};
  /* 
   
   SPDX-License-Identifier: Apache-2.0 
  */
  function Tb(a, b) {
    const c = {};
    for (const d in a) b.call(void 0, a[d], d, a) && (c[d] = a[d]);
    return c
  }

  function Ub(a, b) {
    for (const c in a)
      if (b.call(void 0, a[c], c, a)) return !0;
    return !1
  }

  function Vb(a) {
    const b = [];
    let c = 0;
    for (const d in a) b[c++] = a[d];
    return b
  }

  function Wb(a) {
    const b = {};
    for (const c in a) b[c] = a[c];
    return b
  };
  var Xb;

  function Yb() {
    if (void 0 === Xb) {
      var a = null,
        b = m.trustedTypes;
      if (b && b.createPolicy) {
        try {
          a = b.createPolicy("goog#html", {
            createHTML: oa,
            createScript: oa,
            createScriptURL: oa
          })
        } catch (c) {
          m.console && m.console.error(c.message)
        }
        Xb = a
      } else Xb = a
    }
    return Xb
  };
  const Zb = {};
  class $b {
    constructor(a, b) {
      this.h = b === Zb ? a : ""
    }
    toString() {
      return this.h.toString()
    }
  };
  var bc = class {
    constructor(a, b) {
      this.h = b === ac ? a : ""
    }
    toString() {
      return this.h + ""
    }
  };

  function cc(a, b) {
    a = dc.exec(ec(a).toString());
    var c = a[3] || "";
    return fc(a[1] + gc("?", a[2] || "", b) + gc("#", c))
  }

  function ec(a) {
    return a instanceof bc && a.constructor === bc ? a.h : "type_error:TrustedResourceUrl"
  }
  var dc = /^([^?#]*)(\?[^#]*)?(#[\s\S]*)?/,
    ac = {};

  function fc(a) {
    const b = Yb();
    a = b ? b.createScriptURL(a) : a;
    return new bc(a, ac)
  }

  function gc(a, b, c) {
    if (null == c) return b;
    if ("string" === typeof c) return c ? a + encodeURIComponent(c) : "";
    for (var d in c)
      if (Object.prototype.hasOwnProperty.call(c, d)) {
        var e = c[d];
        e = Array.isArray(e) ? e : [e];
        for (var f = 0; f < e.length; f++) {
          var g = e[f];
          null != g && (b || (b = a), b += (b.length > a.length ? "&" : "") + encodeURIComponent(d) + "=" + encodeURIComponent(String(g)))
        }
      } return b
  };
  var ic = class {
      constructor(a, b) {
        this.h = b === hc ? a : ""
      }
      toString() {
        return this.h.toString()
      }
    },
    hc = {};
  const jc = "alternate author bookmark canonical cite help icon license next prefetch dns-prefetch prerender preconnect preload prev search subresource".split(" ");

  function kc(a, b, c) {
    if (b instanceof bc) a.href = ec(b).toString();
    else {
      if (-1 === jc.indexOf(c)) throw Error(`TrustedResourceUrl href attribute required with rel="${c}"`);
      if (b instanceof ic) b = b instanceof ic && b.constructor === ic ? b.h : "type_error:SafeUrl";
      else a: {
        let d;
        try {
          d = new URL(b)
        } catch (e) {
          break a
        }
        b = "javascript:" === d.protocol ? "about:invalid" : b
      }
      a.href = b
    }
    a.rel = c
  };

  function lc(a) {
    return function () {
      return !a.apply(this, arguments)
    }
  }

  function mc(a) {
    let b = !1,
      c;
    return function () {
      b || (c = a(), b = !0);
      return c
    }
  }

  function nc(a) {
    let b = a;
    return function () {
      if (b) {
        const c = b;
        b = null;
        c()
      }
    }
  };

  function oc(a, b, c) {
    a.addEventListener && a.addEventListener(b, c, !1)
  }

  function pc(a, b, c) {
    a.removeEventListener && a.removeEventListener(b, c, !1)
  };

  function qc(a) {
    return String(a).replace(/\-([a-z])/g, function (b, c) {
      return c.toUpperCase()
    })
  };

  function rc(a, b, c) {
    function d(h) {
      h && b.appendChild("string" === typeof h ? a.createTextNode(h) : h)
    }
    for (var e = 1; e < c.length; e++) {
      var f = c[e];
      if (!da(f) || ea(f) && 0 < f.nodeType) d(f);
      else {
        a: {
          if (f && "number" == typeof f.length) {
            if (ea(f)) {
              var g = "function" == typeof f.item || "string" == typeof f.item;
              break a
            }
            if ("function" === typeof f) {
              g = "function" == typeof f.item;
              break a
            }
          }
          g = !1
        }
        Da(g ? Ka(f) : f, d)
      }
    }
  }

  function sc(a) {
    this.h = a || m.document || document
  }
  sc.prototype.getElementsByTagName = function (a, b) {
    return (b || this.h).getElementsByTagName(String(a))
  };
  sc.prototype.createElement = function (a) {
    var b = this.h;
    a = String(a);
    "application/xhtml+xml" === b.contentType && (a = a.toLowerCase());
    return b.createElement(a)
  };
  sc.prototype.createTextNode = function (a) {
    return this.h.createTextNode(String(a))
  };
  sc.prototype.append = function (a, b) {
    rc(9 == a.nodeType ? a : a.ownerDocument || a.document, a, arguments)
  };
  sc.prototype.contains = function (a, b) {
    if (!a || !b) return !1;
    if (a.contains && 1 == b.nodeType) return a == b || a.contains(b);
    if ("undefined" != typeof a.compareDocumentPosition) return a == b || !!(a.compareDocumentPosition(b) & 16);
    for (; b && a != b;) b = b.parentNode;
    return b == a
  };

  function vc() {
    return !wc() && (n("iPod") || n("iPhone") || n("Android") || n("IEMobile"))
  }

  function wc() {
    return n("iPad") || n("Android") && !n("Mobile") || n("Silk")
  };
  var xc = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$"),
    yc = /#|$/;

  function zc(a) {
    var b = a.search(yc),
      c;
    a: {
      for (c = 0; 0 <= (c = a.indexOf("client", c)) && c < b;) {
        var d = a.charCodeAt(c - 1);
        if (38 == d || 63 == d)
          if (d = a.charCodeAt(c + 6), !d || 61 == d || 38 == d || 35 == d) break a;
        c += 7
      }
      c = -1
    }
    if (0 > c) return null;
    d = a.indexOf("&", c);
    if (0 > d || d > b) d = b;
    return decodeURIComponent(a.slice(c + 7, -1 !== d ? d : 0).replace(/\+/g, " "))
  };

  function Ac(a) {
    try {
      var b;
      if (b = !!a && null != a.location.href) a: {
        try {
          La(a.foo);
          b = !0;
          break a
        } catch (c) {}
        b = !1
      }
      return b
    } catch {
      return !1
    }
  }

  function Bc(a) {
    return Ac(a.top) ? a.top : null
  }

  function Cc(a, b) {
    const c = Dc("SCRIPT", a);
    c.src = ec(b);
    (b = (b = (c.ownerDocument && c.ownerDocument.defaultView || window).document.querySelector ? .("script[nonce]")) ? b.nonce || b.getAttribute("nonce") || "" : "") && c.setAttribute("nonce", b);
    return (a = a.getElementsByTagName("script")[0]) && a.parentNode ? (a.parentNode.insertBefore(c, a), c) : null
  }

  function Ec(a, b) {
    return b.getComputedStyle ? b.getComputedStyle(a, null) : a.currentStyle
  }

  function Fc(a, b) {
    if (!Gc() && !Hc()) {
      let c = Math.random();
      if (c < b) return c = Ic(), a[Math.floor(c * a.length)]
    }
    return null
  }

  function Ic() {
    if (!globalThis.crypto) return Math.random();
    try {
      const a = new Uint32Array(1);
      globalThis.crypto.getRandomValues(a);
      return a[0] / 65536 / 65536
    } catch {
      return Math.random()
    }
  }

  function E(a, b) {
    if (a)
      for (const c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
  }

  function Jc(a) {
    const b = a.length;
    if (0 == b) return 0;
    let c = 305419896;
    for (let d = 0; d < b; d++) c ^= (c << 5) + (c >> 2) + a.charCodeAt(d) & 4294967295;
    return 0 < c ? c : 4294967296 + c
  }
  var Hc = mc(() => Ga(["Google Web Preview", "Mediapartners-Google", "Google-Read-Aloud", "Google-Adwords"], Kc) || 1E-4 > Math.random()),
    Gc = mc(() => -1 != ua().indexOf("MSIE"));
  const Kc = a => -1 != ua().indexOf(a);
  var Lc = /^([0-9.]+)px$/,
    Mc = /^(-?[0-9.]{1,30})$/;

  function Nc(a) {
    if (!Mc.test(a)) return null;
    a = Number(a);
    return isNaN(a) ? null : a
  }

  function G(a) {
    return (a = Lc.exec(a)) ? +a[1] : null
  }
  var Oc = (a, b) => {
      for (let e = 0; 50 > e; ++e) {
        try {
          var c = !(!a.frames || !a.frames[b])
        } catch {
          c = !1
        }
        if (c) return a;
        a: {
          try {
            const f = a.parent;
            if (f && f != a) {
              var d = f;
              break a
            }
          } catch {}
          d = null
        }
        if (!(a = d)) break
      }
      return null
    },
    Pc = mc(() => vc() ? 2 : wc() ? 1 : 0),
    Qc = a => {
      E({
        display: "none"
      }, (b, c) => {
        a.style.setProperty(c, b, "important")
      })
    };
  let Rc = [];
  const Sc = () => {
    const a = Rc;
    Rc = [];
    for (const b of a) try {
      b()
    } catch {}
  };
  var Tc = (a = "", b = window) => (b = (b = b.location.href.match(xc)[3] || null) ? decodeURI(b) : b) ? Jc(b + a) : null;

  function Uc(a, b) {
    if (a.length && b.head)
      for (const c of a) a: {
        a = c;
        if (!a || !b.head) break a;
        const d = Dc("META");b.head.appendChild(d);d.httpEquiv = "origin-trial";d.content = a
      }
  }
  var Vc = a => {
      if ("number" !== typeof a.goog_pvsid) try {
        Object.defineProperty(a, "goog_pvsid", {
          value: Math.floor(Math.random() * 2 ** 52),
          configurable: !1
        })
      } catch (b) {}
      return Number(a.goog_pvsid) || -1
    },
    Xc = a => {
      var b = Wc;
      "complete" === b.readyState || "interactive" === b.readyState ? (Rc.push(a), 1 == Rc.length && (window.Promise ? Promise.resolve().then(Sc) : window.setImmediate ? setImmediate(Sc) : setTimeout(Sc, 0))) : b.addEventListener("DOMContentLoaded", a)
    };

  function Dc(a, b = document) {
    return b.createElement(String(a).toLowerCase())
  };
  let Yc = null;
  var Wc = document,
    H = window;
  let Zc = null;
  var $c = (a, b = []) => {
    let c = !1;
    m.google_logging_queue || (c = !0, m.google_logging_queue = []);
    m.google_logging_queue.push([a, b]);
    if (a = c) {
      if (null == Zc) {
        Zc = !1;
        try {
          var d = Bc(m);
          d && -1 !== d.location.hash.indexOf("google_logging") && (Zc = !0);
          m.localStorage.getItem("google_logging") && (Zc = !0)
        } catch (e) {}
      }
      a = Zc
    }
    a && (d = m.document, a = new Qb(Rb, "https://pagead2.googlesyndication.com/pagead/js/logging_library.js"), a = fc(a instanceof Qb && a.constructor === Qb && a.h === Sb ? a.i : "type_error:Const"), Cc(d, a))
  };

  function ad(a = m) {
    let b = a.context || a.AMP_CONTEXT_DATA;
    if (!b) try {
      b = a.parent.context || a.parent.AMP_CONTEXT_DATA
    } catch (c) {}
    try {
      if (b && b.pageViewId && b.canonicalUrl) return b
    } catch (c) {}
    return null
  }

  function bd(a) {
    return (a = a || ad()) ? Ac(a.master) ? a.master : null : null
  };

  function cd(a, ...b) {
    if (0 === b.length) return fc(a[0]);
    const c = [a[0]];
    for (let d = 0; d < b.length; d++) c.push(encodeURIComponent(b[d])), c.push(a[d + 1]);
    return fc(c.join(""))
  };

  function dd(a) {
    a = a[0];
    const b = Yb();
    a = b ? b.createScript(a) : a;
    return new $b(a, Zb)
  };
  var ed = a => {
      a = bd(ad(a)) || a;
      a.google_unique_id = (a.google_unique_id || 0) + 1;
      return a.google_unique_id
    },
    fd = a => {
      a = a.google_unique_id;
      return "number" === typeof a ? a : 0
    },
    gd = () => {
      if (!H) return !1;
      try {
        return !(!H.navigator.standalone && !H.top.navigator.standalone)
      } catch (a) {
        return !1
      }
    },
    hd = a => {
      if (!a) return "";
      a = a.toLowerCase();
      "ca-" != a.substring(0, 3) && (a = "ca-" + a);
      return a
    };
  var id = {
    Eb: 0,
    Db: 1,
    Ab: 2,
    vb: 3,
    Bb: 4,
    wb: 5,
    Cb: 6,
    yb: 7,
    zb: 8,
    ub: 9,
    xb: 10
  };
  var jd = {
    Gb: 0,
    Hb: 1,
    Fb: 2
  };

  function kd(a) {
    if (0 != a.h) throw Error("Already resolved/rejected.");
  }
  var nd = class {
    constructor() {
      this.i = new ld(this);
      this.h = 0
    }
    resolve(a) {
      kd(this);
      this.h = 1;
      this.l = a;
      md(this.i)
    }
  };

  function md(a) {
    switch (a.h.h) {
      case 0:
        break;
      case 1:
        a.i && a.i(a.h.l);
        break;
      case 2:
        a.j && a.j(a.h.j);
        break;
      default:
        throw Error("Unhandled deferred state.");
    }
  }
  var ld = class {
    constructor(a) {
      this.h = a
    }
    then(a, b) {
      if (this.i) throw Error("Then functions already set.");
      this.i = a;
      this.j = b;
      md(this)
    }
  };

  function od() {
    this.A = this.A;
    this.G = this.G
  }
  od.prototype.A = !1;
  od.prototype.j = function () {
    if (this.G)
      for (; this.G.length;) this.G.shift()()
  };
  const pd = class {
    constructor(a) {
      this.h = a.slice(0)
    }
    forEach(a) {
      this.h.forEach((b, c) => void a(b, c, this))
    }
    filter(a) {
      return new pd(Ea(this.h, a))
    }
    apply(a) {
      return new pd(a(this.h.slice(0)))
    }
    sort(a) {
      return new pd(this.h.slice(0).sort(a))
    }
    get(a) {
      return this.h[a]
    }
    add(a) {
      const b = this.h.slice(0);
      b.push(a);
      return new pd(b)
    }
  };

  function qd(a, b) {
    for (var c = [], d = a.length, e = 0; e < d; e++) c.push(a[e]);
    c.forEach(b, void 0)
  };
  const sd = class {
    constructor() {
      this.h = {};
      this.i = {}
    }
    set(a, b) {
      const c = rd(a);
      this.h[c] = b;
      this.i[c] = a
    }
    get(a, b) {
      a = rd(a);
      return void 0 !== this.h[a] ? this.h[a] : b
    }
    clear() {
      this.h = {};
      this.i = {}
    }
  };

  function rd(a) {
    return a instanceof Object ? String(fa(a)) : a + ""
  };

  function td(a) {
    return new ud({
      value: a
    }, null)
  }

  function vd(a) {
    return new ud(null, a)
  }

  function wd(a) {
    try {
      return td(a())
    } catch (b) {
      return vd(b)
    }
  }

  function xd(a) {
    return null != a.h ? a.h.value : null
  }

  function yd(a, b) {
    null != a.h && b(a.h.value);
    return a
  }

  function zd(a, b) {
    null != a.h || b(a.i);
    return a
  }
  class ud {
    constructor(a, b) {
      this.h = a;
      this.i = b
    }
    map(a) {
      return null != this.h ? (a = a(this.h.value), a instanceof ud ? a : td(a)) : this
    }
  };
  const Ad = class {
    constructor(a) {
      this.h = new sd;
      if (a)
        for (var b = 0; b < a.length; ++b) this.add(a[b])
    }
    add(a) {
      this.h.set(a, !0)
    }
    contains(a) {
      return void 0 !== this.h.h[rd(a)]
    }
  };
  class Bd {
    constructor() {
      this.h = new sd
    }
    set(a, b) {
      let c = this.h.get(a);
      c || (c = new Ad, this.h.set(a, c));
      c.add(b)
    }
  };
  var Dd = class extends D {
      constructor(a) {
        super(a, -1, Cd)
      }
      getId() {
        return r(this, 3)
      }
    },
    Cd = [4];
  class Fd {
    constructor({
      Ya: a,
      Jb: b,
      Qb: c,
      kb: d
    }) {
      this.h = b;
      this.l = new pd(a || []);
      this.j = d;
      this.i = c
    }
  };
  const Hd = a => {
      const b = [],
        c = a.l;
      c && c.h.length && b.push({
        T: "a",
        ca: Gd(c)
      });
      null != a.h && b.push({
        T: "as",
        ca: a.h
      });
      null != a.i && b.push({
        T: "i",
        ca: String(a.i)
      });
      null != a.j && b.push({
        T: "rp",
        ca: String(a.j)
      });
      b.sort(function (d, e) {
        return d.T.localeCompare(e.T)
      });
      b.unshift({
        T: "t",
        ca: "aa"
      });
      return b
    },
    Gd = a => {
      a = a.h.slice(0).map(Id);
      a = JSON.stringify(a);
      return Jc(a)
    },
    Id = a => {
      const b = {};
      null != r(a, 7) && (b.q = r(a, 7));
      null != r(a, 2) && (b.o = r(a, 2));
      null != r(a, 5) && (b.p = r(a, 5));
      return b
    };
  var Jd = class extends D {
    constructor(a) {
      super(a)
    }
    setLocation(a) {
      return t(this, 1, a)
    }
  };

  function Kd(a) {
    const b = [].slice.call(arguments).filter(lc(e => null === e));
    if (!b.length) return null;
    let c = [],
      d = {};
    b.forEach(e => {
      c = c.concat(e.Ja || []);
      d = Object.assign(d, e.Pa)
    });
    return new Ld(c, d)
  }

  function Md(a) {
    switch (a) {
      case 1:
        return new Ld(null, {
          google_ad_semantic_area: "mc"
        });
      case 2:
        return new Ld(null, {
          google_ad_semantic_area: "h"
        });
      case 3:
        return new Ld(null, {
          google_ad_semantic_area: "f"
        });
      case 4:
        return new Ld(null, {
          google_ad_semantic_area: "s"
        });
      default:
        return null
    }
  }

  function Nd(a) {
    if (null == a) var b = null;
    else {
      var c = Hd(a);
      a = [];
      for (b of c) c = String(b.ca), a.push(b.T + "." + (20 >= c.length ? c : c.slice(0, 19) + "_"));
      b = new Ld(null, {
        google_placement_id: a.join("~")
      })
    }
    return b
  }
  class Ld {
    constructor(a, b) {
      this.Ja = a;
      this.Pa = b
    }
  };
  const Od = new Ld(["google-auto-placed"], {
    google_reactive_ad_format: 40,
    google_tag_origin: "qs"
  });
  var Pd = class extends D {
    constructor(a) {
      super(a)
    }
  };
  var Qd = class extends D {
      constructor(a) {
        super(a)
      }
      getName() {
        return r(this, 4)
      }
    },
    Rd = class extends D {
      constructor(a) {
        super(a)
      }
    },
    Sd = class extends D {
      constructor(a) {
        super(a)
      }
    },
    Td = class extends D {
      constructor(a) {
        super(a)
      }
    },
    Ud = [1, 2, 3];
  var Vd = class extends D {
    constructor(a) {
      super(a)
    }
  };
  var Xd = class extends D {
      constructor(a) {
        super(a, -1, Wd)
      }
    },
    Wd = [6, 7, 9, 10, 11];
  var $d = class extends D {
      constructor(a) {
        super(a, -1, Yd)
      }
      l() {
        return y(this, Zd, 3)
      }
    },
    Zd = class extends D {
      constructor(a) {
        super(a)
      }
      l() {
        return Gb(this, ae, 2, be)
      }
    },
    ae = class extends D {
      constructor(a) {
        super(a)
      }
    },
    Yd = [1],
    be = [1, 2];
  var de = class extends D {
      constructor(a) {
        super(a, -1, ce)
      }
    },
    ee = class extends D {
      constructor(a) {
        super(a)
      }
    },
    ge = class extends D {
      constructor(a) {
        super(a, -1, fe)
      }
    },
    he = class extends D {
      constructor(a) {
        super(a)
      }
    },
    ie = class extends D {
      constructor(a) {
        super(a)
      }
    },
    je = class extends D {
      constructor(a) {
        super(a)
      }
    },
    ke = class extends D {
      constructor(a) {
        super(a)
      }
      l() {
        return vb(this, 23)
      }
    },
    ce = [1, 2, 5, 7],
    fe = [2, 5, 6, 11];
  var le = class extends D {
    constructor(a) {
      super(a)
    }
  };

  function me(a) {
    if (1 != a.nodeType) var b = !1;
    else if (b = "INS" == a.tagName) a: {
      b = ["adsbygoogle-placeholder"];a = a.className ? a.className.split(/\s+/) : [];
      for (var c = {}, d = 0; d < a.length; ++d) c[a[d]] = !0;
      for (d = 0; d < b.length; ++d)
        if (!c[b[d]]) {
          b = !1;
          break a
        } b = !0
    }
    return b
  };

  function ne(a, b, c) {
    switch (c) {
      case 0:
        b.parentNode && b.parentNode.insertBefore(a, b);
        break;
      case 3:
        if (c = b.parentNode) {
          var d = b.nextSibling;
          if (d && d.parentNode != c)
            for (; d && 8 == d.nodeType;) d = d.nextSibling;
          c.insertBefore(a, d)
        }
        break;
      case 1:
        b.insertBefore(a, b.firstChild);
        break;
      case 2:
        b.appendChild(a)
    }
    me(b) && (b.setAttribute("data-init-display", b.style.display), b.style.display = "block")
  };
  var I = class {
      constructor(a, b = !1) {
        this.h = a;
        this.defaultValue = b
      }
    },
    J = class {
      constructor(a, b = 0) {
        this.h = a;
        this.defaultValue = b
      }
    },
    oe = class {
      constructor(a, b = []) {
        this.h = a;
        this.defaultValue = b
      }
    };
  var pe = new I(1084),
    qe = new I(1082, !0),
    re = new J(62, .001),
    se = new J(1130, 100),
    te = new class {
      constructor(a, b = "") {
        this.h = a;
        this.defaultValue = b
      }
    }(14),
    ue = new J(1114, 1),
    ve = new J(1110),
    we = new J(1111),
    xe = new J(1112),
    ye = new J(1113),
    ze = new J(1104),
    Ae = new J(1108),
    Be = new J(1106),
    Ce = new J(1107),
    De = new J(1105),
    Ee = new J(1115, 1),
    Fe = new I(1121),
    Ge = new I(1180),
    He = new I(1144),
    Ie = new I(1143),
    Je = new I(1186),
    Ke = new I(316),
    Le = new I(313),
    Me = new I(369),
    Ne = new I(1093),
    Oe = new J(1098),
    Pe = new I(1129, !0),
    Qe = new I(1128),
    Re = new I(1026),
    Se = new I(1090),
    Te = new I(1177),
    Ue = new I(1053, !0),
    Ve = new I(1162),
    We = new I(1175),
    Xe = new I(1120),
    Ye = new I(1100, !0),
    Ze = new I(1171),
    $e = new J(1046),
    af = new I(218),
    bf = new I(217),
    cf = new I(1179),
    df = new I(227),
    ef = new I(282),
    ff = new I(1086),
    gf = new J(1079, 5),
    hf = new I(1141),
    jf = new I(1190),
    kf = new oe(1934, ["AzoawhTRDevLR66Y6MROu167EDncFPBvcKOaQispTo9ouEt5LvcBjnRFqiAByRT+2cDHG1Yj4dXwpLeIhc98/gIAAACFeyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjYxMjk5MTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ==",
      "A6+nc62kbJgC46ypOwRsNW6RkDn2x7tgRh0wp7jb3DtFF7oEhu1hhm4rdZHZ6zXvnKZLlYcBlQUImC4d3kKihAcAAACLeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjYxMjk5MTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ==", "A/9La288e7MDEU2ifusFnMg1C2Ij6uoa/Z/ylwJIXSsWfK37oESIPbxbt4IU86OGqDEPnNVruUiMjfKo65H/CQwAAACLeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXRhZ3NlcnZpY2VzLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjYxMjk5MTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ=="
    ]),
    lf = new I(203),
    mf = new I(84),
    nf = new I(1928),
    of = new I(1941),
    pf = new I(370946349),
    qf = new I(392736476),
    rf = new J(406149835),
    sf = new oe(1932),
    tf = new J(1935);
  var K = a => {
    var b = "pa";
    if (a.pa && a.hasOwnProperty(b)) return a.pa;
    b = new a;
    return a.pa = b
  };
  var uf = class {
      constructor() {
        const a = {};
        this.j = (b, c) => null != a[b] ? a[b] : c;
        this.l = (b, c) => null != a[b] ? a[b] : c;
        this.h = (b, c) => null != a[b] ? a[b] : c;
        this.i = (b, c) => null != a[b] ? a[b] : c;
        this.m = () => {}
      }
    },
    L = a => K(uf).j(a.h, a.defaultValue),
    M = a => K(uf).l(a.h, a.defaultValue);

  function vf(a, b) {
    const c = e => {
        e = wf(e);
        return null == e ? !1 : 0 < e
      },
      d = e => {
        e = wf(e);
        return null == e ? !1 : 0 > e
      };
    switch (b) {
      case 0:
        return {
          init: xf(a.previousSibling, c), ia: e => xf(e.previousSibling, c), la: 0
        };
      case 2:
        return {
          init: xf(a.lastChild, c), ia: e => xf(e.previousSibling, c), la: 0
        };
      case 3:
        return {
          init: xf(a.nextSibling, d), ia: e => xf(e.nextSibling, d), la: 3
        };
      case 1:
        return {
          init: xf(a.firstChild, d), ia: e => xf(e.nextSibling, d), la: 3
        }
    }
    throw Error("Un-handled RelativePosition: " + b);
  }

  function wf(a) {
    return a.hasOwnProperty("google-ama-order-assurance") ? a["google-ama-order-assurance"] : null
  }

  function xf(a, b) {
    return a && b(a) ? a : null
  };
  var yf = {
    rectangle: 1,
    horizontal: 2,
    vertical: 4
  };

  function zf(a, b, c = null, d = !1) {
    Af(a, b, c, d)
  }

  function Af(a, b, c, d) {
    a.google_image_requests || (a.google_image_requests = []);
    const e = Dc("IMG", a.document);
    if (c || d) {
      const f = g => {
        c && c(g);
        if (d) {
          g = a.google_image_requests;
          const h = Ca(g, e);
          0 <= h && Array.prototype.splice.call(g, h, 1)
        }
        pc(e, "load", f);
        pc(e, "error", f)
      };
      oc(e, "load", f);
      oc(e, "error", f)
    }
    e.src = b;
    a.google_image_requests.push(e)
  }
  var Cf = a => {
      let b = "https://pagead2.googlesyndication.com/pagead/gen_204?id=dtt_err";
      E(a, (c, d) => {
        c && (b += `&${d}=${encodeURIComponent(c)}`)
      });
      Bf(b)
    },
    Bf = a => {
      var b = window;
      b.fetch ? b.fetch(a, {
        keepalive: !0,
        credentials: "include",
        redirect: "follow",
        method: "get",
        mode: "no-cors"
      }) : zf(b, a, void 0, !1)
    };

  function Df(a, b) {
    const c = {};
    c[a] = b;
    return [c]
  }

  function Ef(a, b, c, d, e) {
    const f = [];
    E(a, function (g, h) {
      (g = Ff(g, b, c, d, e)) && f.push(h + "=" + g)
    });
    return f.join(b)
  }

  function Ff(a, b, c, d, e) {
    if (null == a) return "";
    b = b || "&";
    c = c || ",$";
    "string" == typeof c && (c = c.split(""));
    if (a instanceof Array) {
      if (d = d || 0, d < c.length) {
        const f = [];
        for (let g = 0; g < a.length; g++) f.push(Ff(a[g], b, c, d + 1, e));
        return f.join(c[d])
      }
    } else if ("object" == typeof a) return e = e || 0, 2 > e ? encodeURIComponent(Ef(a, b, c, d, e + 1)) : "...";
    return encodeURIComponent(String(a))
  }

  function Gf(a) {
    let b = 1;
    for (const c in a.i) b = c.length > b ? c.length : b;
    return 3997 - b - a.j.length - 1
  }

  function Hf(a, b) {
    let c = "https://pagead2.googlesyndication.com" + b,
      d = Gf(a) - b.length;
    if (0 > d) return "";
    a.h.sort(function (f, g) {
      return f - g
    });
    b = null;
    let e = "";
    for (let f = 0; f < a.h.length; f++) {
      const g = a.h[f],
        h = a.i[g];
      for (let k = 0; k < h.length; k++) {
        if (!d) {
          b = null == b ? g : b;
          break
        }
        let l = Ef(h[k], a.j, ",$");
        if (l) {
          l = e + l;
          if (d >= l.length) {
            d -= l.length;
            c += l;
            e = a.j;
            break
          }
          b = null == b ? g : b
        }
      }
    }
    a = "";
    null != b && (a = e + "trn=" + b);
    return c + a
  }
  class If {
    constructor() {
      this.j = "&";
      this.i = {};
      this.l = 0;
      this.h = []
    }
  };

  function Jf() {
    var a = Kf,
      b = m.google_srt;
    0 <= b && 1 >= b && (a.h = b)
  }

  function Lf(a, b, c, d, e) {
    if ((d ? a.h : Math.random()) < (e || .01)) try {
      let f;
      c instanceof If ? f = c : (f = new If, E(c, (h, k) => {
        var l = f;
        const q = l.l++;
        h = Df(k, h);
        l.h.push(q);
        l.i[q] = h
      }));
      const g = Hf(f, "/pagead/gen_204?id=" + b + "&");
      g && zf(m, g)
    } catch (f) {}
  }
  class Mf {
    constructor() {
      this.h = Math.random()
    }
  };
  var Nf = {
    overlays: 1,
    interstitials: 2,
    vignettes: 2,
    inserts: 3,
    immersives: 4,
    list_view: 5
  };

  function Of(a) {
    a.google_reactive_ads_global_state ? (null == a.google_reactive_ads_global_state.sideRailProcessedFixedElements && (a.google_reactive_ads_global_state.sideRailProcessedFixedElements = new Set), null == a.google_reactive_ads_global_state.sideRailAvailableSpace && (a.google_reactive_ads_global_state.sideRailAvailableSpace = new Map)) : a.google_reactive_ads_global_state = new Pf;
    return a.google_reactive_ads_global_state
  }
  class Pf {
    constructor() {
      this.wasPlaTagProcessed = !1;
      this.wasReactiveAdConfigReceived = {};
      this.adCount = {};
      this.wasReactiveAdVisible = {};
      this.stateForType = {};
      this.reactiveTypeEnabledInAsfe = {};
      this.wasReactiveTagRequestSent = !1;
      this.reactiveTypeDisabledByPublisher = {};
      this.tagSpecificState = {};
      this.messageValidationEnabled = !1;
      this.floatingAdsStacking = new Qf;
      this.sideRailProcessedFixedElements = new Set;
      this.sideRailAvailableSpace = new Map
    }
  }
  var Qf = class {
    constructor() {
      this.maxZIndexRestrictions = {};
      this.nextRestrictionId = 0;
      this.maxZIndexListeners = []
    }
  };
  var N = a => {
    a = a.document;
    let b = {};
    a && (b = "CSS1Compat" == a.compatMode ? a.documentElement : a.body);
    return b || {}
  };
  const Rf = a => null !== a && void 0 !== a;
  let Sf = void 0;

  function Tf(a, b) {
    const c = Sf;
    Sf = void 0;
    if (!b(a)) throw b = c ? c() + "\n" : "", Error(b + String(a));
  };
  var Uf = a => "string" === typeof a,
    Vf = a => void 0 === a;
  var Xf = class extends D {
      constructor(a) {
        super(a, -1, Wf)
      }
    },
    Wf = [2, 8],
    Yf = [3, 4, 5],
    Zf = [6, 7];
  var $f;
  $f = {
    Ib: 0,
    Ua: 3,
    Va: 4,
    Wa: 5
  };
  var ag = $f.Ua,
    bg = $f.Va,
    cg = $f.Wa;
  const dg = a => null != a ? !a : a,
    eg = (a, b) => {
      let c = !1;
      for (let d = 0; d < a.length; d++) {
        const e = a[d]();
        if (e === b) return e;
        null == e && (c = !0)
      }
      if (!c) return !b
    },
    gg = (a, b) => {
      var c = A(a, Xf, 2);
      if (!c.length) return fg(a, b);
      a = u(a, 1, 0);
      if (1 === a) return dg(gg(c[0], b));
      c = Fa(c, d => () => gg(d, b));
      switch (a) {
        case 2:
          return eg(c, !1);
        case 3:
          return eg(c, !0)
      }
    },
    fg = (a, b) => {
      const c = Ab(a, Yf);
      a: {
        switch (c) {
          case ag:
            var d = Fb(a, 3, Yf);
            break a;
          case bg:
            d = Fb(a, 4, Yf);
            break a;
          case cg:
            d = Fb(a, 5, Yf);
            break a
        }
        d = void 0
      }
      if (d && (b = (b = b[c]) && b[d])) {
        try {
          var e = b(...ub(a,
            8))
        } catch (f) {
          return
        }
        b = u(a, 1, 0);
        if (4 === b) return !!e;
        d = null != e;
        if (5 === b) return d;
        if (12 === b) a = B(a, sb(a, Zf, 7));
        else a: {
          switch (c) {
            case bg:
              a = wb(a, sb(a, Zf, 6));
              break a;
            case cg:
              a = B(a, sb(a, Zf, 7));
              break a
          }
          a = void 0
        }
        if (null != a) {
          if (6 === b) return e === a;
          if (9 === b) return null != e && 0 === sa(String(e), a);
          if (d) switch (b) {
            case 7:
              return e < a;
            case 8:
              return e > a;
            case 12:
              return Uf(a) && Uf(e) && (new RegExp(a)).test(e);
            case 10:
              return null != e && -1 === sa(String(e), a);
            case 11:
              return null != e && 1 === sa(String(e), a)
          }
        }
      }
    };
  var hg = (a, b) => !a || !(!b || !gg(a, b));
  var jg = class extends D {
      constructor(a) {
        super(a, -1, ig)
      }
    },
    ig = [4];
  var kg = class extends D {
    constructor(a) {
      super(a)
    }
  };
  var mg = class extends D {
      constructor(a) {
        super(a, -1, lg)
      }
    },
    lg = [5],
    ng = [1, 2, 3, 6, 7];

  function og(a, ...b) {
    pg(a, ...b.map(c => ({
      Ta: 4,
      message: c
    })))
  }

  function rg(a, ...b) {
    pg(a, ...b.map(c => ({
      Ta: 7,
      message: c
    })))
  };

  function sg(a) {
    return function (...b) {
      try {
        return a.apply(this, b)
      } catch (c) {}
    }
  }
  var tg = sg(a => {
    const b = [];
    for (const c of a) sg(() => {
      b.push([{
        [c.Ta]: c.message.toJSON()
      }])
    })();
    return JSON.stringify([b])
  });
  var ug = (a, b) => {
    globalThis.fetch(a, {
      method: "POST",
      body: b,
      keepalive: 65536 > b.length,
      credentials: "omit",
      mode: "no-cors",
      redirect: "follow"
    }).catch(() => {})
  };

  function pg(a, ...b) {
    sg(() => {
      a.i.push(...b);
      const c = sg(() => {
        const d = tg(a.i);
        a.j("https://pagead2.googlesyndication.com/pagead/ping?e=1", d);
        a.i = [];
        a.h = null
      });
      100 <= a.i.length ? (null !== a.h && clearTimeout(a.h), a.h = setTimeout(c, 0)) : null === a.h && (a.h = setTimeout(c, a.l))
    })()
  }
  var vg = class {
    constructor(a = 1E3) {
      this.l = a;
      this.j = ug;
      this.i = [];
      this.h = null
    }
  };

  function wg(a, b) {
    return Cb(a, 1, b)
  }

  function xg(a, b) {
    return Eb(a, 2, b)
  }

  function yg(a, b) {
    return xb(a, 4, b)
  }

  function zg(a, b) {
    return Eb(a, 5, b)
  }

  function Ag(a, b) {
    return yb(a, 6, b)
  }
  var Cg = class extends D {
    constructor() {
      super(void 0, -1, Bg)
    }
  };

  function Dg(a, b) {
    return yb(a, 1, b)
  }

  function Eg(a, b) {
    return yb(a, 2, b)
  }
  var Fg = class extends D {
      constructor() {
        super(void 0)
      }
      O() {
        return u(this, 1, 0)
      }
    },
    Gg = class extends D {
      constructor() {
        super(void 0)
      }
    },
    Bg = [2, 4, 5],
    Hg = [1, 2];
  var Jg = class extends D {
      constructor() {
        super(void 0, -1, Ig)
      }
    },
    Lg = class extends D {
      constructor() {
        super(void 0, -1, Kg)
      }
    },
    Ig = [2, 3],
    Kg = [5],
    Mg = [1, 2, 3, 4];

  function Ng(a) {
    var b = Vc(window);
    return yb(a, 2, b)
  }

  function Og(a, b) {
    return yb(a, 6, b)
  }

  function Pg(a, b) {
    return Db(a, 4, Qg, b)
  }
  var Rg = class extends D {
      constructor() {
        super(void 0)
      }
      getTagSessionCorrelator() {
        return u(this, 2, 0)
      }
    },
    Qg = [4, 5, 7];

  function Sg(a, b, c, d) {
    if (a.A) {
      var e = new Jg;
      b = Eb(e, 2, b);
      c = Eb(b, 3, c);
      d && yb(c, 1, d);
      d = new Rg;
      c = Db(d, 7, Qg, c);
      a.m && (d = a.l, a = Og(Ng(yb(c, 1, Date.now())), a.i), og(d, a))
    }
  }
  var Tg = class {
    constructor(a, b, c, d = new vg(b)) {
      this.i = a;
      this.A = c;
      this.l = d;
      this.h = [];
      this.m = 0 < this.i && Ic() < 1 / this.i
    }
    j(a, b, c, d, e) {
      const f = Eg(Dg(new Fg, a), b);
      a = Ag(xg(wg(zg(yg(new Cg, c), d), f), this.h), e);
      a = Pg(new Rg, a);
      this.m && og(this.l, Og(Ng(yb(a, 1, Date.now())), this.i));
      if (1 === e || 3 === e || 4 === e && !this.h.some(g => g.O() === f.O() && u(g, 2, 0) === b)) this.h.push(f), 100 < this.h.length && this.h.shift()
    }
  };
  var Ug = class {
    constructor() {
      this.h = {
        [ag]: {},
        [bg]: {},
        [cg]: {}
      }
    }
  };
  var Vg = /^true$/.test("false"),
    Wg = (a, b) => {
      switch (b) {
        case 1:
          return Fb(a, 1, ng);
        case 2:
          return Fb(a, 2, ng);
        case 3:
          return Fb(a, 3, ng);
        case 6:
          return Fb(a, 6, ng);
        default:
          return null
      }
    },
    Xg = (a, b) => {
      if (!a) return null;
      switch (b) {
        case 1:
          return w(a, 1);
        case 7:
          return B(a, 3);
        case 2:
          return wb(a, 2);
        case 3:
          return B(a, 3);
        case 6:
          return ub(a, 4);
        default:
          return null
      }
    };
  const Yg = mc(() => {
    if (!Vg) return {};
    try {
      const a = window.sessionStorage && window.sessionStorage.getItem("GGDFSSK");
      if (a) return JSON.parse(a)
    } catch (a) {}
    return {}
  });
  var bh = (a, b, c, d = 0) => {
    K(Zg).j[d] = K(Zg).j[d] ? .add(b) ? ? (new Set).add(b);
    const e = Yg();
    if (null != e[b]) return e[b];
    b = $g(d)[b];
    if (!b) return c;
    b = new mg(b);
    b = ah(b);
    a = Xg(b, a);
    return null != a ? a : c
  };
  const ah = a => {
    const b = K(Ug).h;
    if (b) {
      const c = Ia(A(a, kg, 5), d => hg(y(d, Xf, 1), b));
      if (c) return y(c, jg, 2)
    }
    return y(a, jg, 4)
  };
  class Zg {
    constructor() {
      this.i = {};
      this.l = [];
      this.j = {};
      this.h = new Map
    }
  }
  var ch = (a, b = !1, c) => !!bh(1, a, b, c),
    dh = (a, b = 0, c) => {
      a = Number(bh(2, a, b, c));
      return isNaN(a) ? b : a
    },
    eh = (a, b = "", c) => bh(3, a, b, c),
    fh = (a, b = [], c) => bh(6, a, b, c),
    $g = a => K(Zg).i[a] || (K(Zg).i[a] = {});
  const gh = (a, b) => {
    const c = $g(b);
    E(a, (d, e) => c[e] = d)
  };
  var hh = (a, b, c, d, e = !1) => {
      const f = [],
        g = [];
      Da(b, h => {
        const k = $g(h);
        Da(a, l => {
          var q = Ab(l, ng);
          const v = Wg(l, q);
          if (v) {
            var C = K(Zg).h.get(h) ? .get(v) ? .slice(0) ? ? [];
            a: {
              const z = new Lg;
              switch (q) {
                case 1:
                  zb(z, 1, Mg, v);
                  break;
                case 2:
                  zb(z, 2, Mg, v);
                  break;
                case 3:
                  zb(z, 3, Mg, v);
                  break;
                case 6:
                  zb(z, 4, Mg, v);
                  break;
                default:
                  q = void 0;
                  break a
              }
              xb(z, 5, C);q = z
            }
            if (C = q) C = !!K(Zg).j[h] ? .has(v);
            C && f.push(q);
            if (C = q) C = !!K(Zg).h.get(h) ? .has(v);
            C && g.push(q);
            e || (q = K(Zg), q.h.has(h) || q.h.set(h, new Map), q.h.get(h).has(v) || q.h.get(h).set(v, []), d && q.h.get(h).get(v).push(d));
            k[v] = l.toJSON()
          }
        })
      });
      (f.length || g.length) && Sg(c, f, g, d ? ? void 0)
    },
    ih = (a, b) => {
      const c = $g(b);
      Da(a, d => {
        var e = new mg(d);
        const f = Ab(e, ng);
        (e = Wg(e, f)) && (c[e] || (c[e] = d))
      })
    },
    jh = () => Fa(Object.keys(K(Zg).i), a => Number(a)),
    kh = a => {
      Ja(K(Zg).l, a) || gh($g(4), a)
    };
  class O {
    constructor(a) {
      this.methodName = a
    }
  }
  var lh = new O(1),
    mh = new O(16),
    nh = new O(15),
    oh = new O(2),
    ph = new O(3),
    qh = new O(4),
    rh = new O(5),
    sh = new O(6),
    th = new O(7),
    uh = new O(8),
    vh = new O(9),
    wh = new O(10),
    xh = new O(11),
    yh = new O(12),
    zh = new O(13),
    Ah = new O(14),
    P = (a, b, c) => {
      c.hasOwnProperty(a.methodName) || Object.defineProperty(c, String(a.methodName), {
        value: b
      })
    },
    Bh = (a, b, c) => b[a.methodName] || c || (() => {}),
    Ch = a => {
      P(rh, ch, a);
      P(sh, dh, a);
      P(th, eh, a);
      P(uh, fh, a);
      P(zh, ih, a);
      P(nh, kh, a)
    },
    Dh = a => {
      P(qh, b => {
        K(Ug).h = b
      }, a);
      P(vh, (b, c) => {
          var d = K(Ug);
          d.h[ag][b] || (d.h[ag][b] = c)
        },
        a);
      P(wh, (b, c) => {
        var d = K(Ug);
        d.h[bg][b] || (d.h[bg][b] = c)
      }, a);
      P(xh, (b, c) => {
        var d = K(Ug);
        d.h[cg][b] || (d.h[cg][b] = c)
      }, a);
      P(Ah, b => {
        var c = K(Ug);
        for (const d of [ag, bg, cg]) Object.assign(c.h[d], b[d])
      }, a)
    },
    Eh = a => {
      a.hasOwnProperty("init-done") || Object.defineProperty(a, "init-done", {
        value: !0
      })
    };

  function Fh(a, b, c) {
    a.l = Bh(lh, b, () => {});
    a.i = d => {
      Bh(oh, b, () => [])(d, c)
    };
    a.h = () => Bh(ph, b, () => [])(c);
    a.j = d => {
      Bh(mh, b, () => {})(d, c)
    }
  }
  class Gh {
    constructor() {
      this.l = () => {};
      this.j = () => {};
      this.i = () => {};
      this.h = () => []
    }
  };
  class Hh {
    constructor(a, b) {
      this.error = a;
      this.context = b.context;
      this.msg = b.message || "";
      this.id = b.id || "jserror";
      this.meta = {}
    }
  }
  var Ih = a => !!(a.error && a.meta && a.id);
  let Jh = null;

  function Kh() {
    if (null === Jh) {
      Jh = "";
      try {
        let a = "";
        try {
          a = m.top.location.hash
        } catch (b) {
          a = m.location.hash
        }
        if (a) {
          const b = a.match(/\bdeid=([\d,]+)/);
          Jh = b ? b[1] : ""
        }
      } catch (a) {}
    }
    return Jh
  };
  var Lh = () => {
      const a = m.performance;
      return a && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : Date.now()
    },
    Mh = () => {
      const a = m.performance;
      return a && a.now ? a.now() : null
    };
  class Nh {
    constructor(a, b) {
      var c = Mh() || Lh();
      this.label = a;
      this.type = b;
      this.value = c;
      this.duration = 0;
      this.uniqueId = Math.random();
      this.taskId = this.slotId = void 0
    }
  };
  const Oh = m.performance,
    Ph = !!(Oh && Oh.mark && Oh.measure && Oh.clearMarks),
    Qh = mc(() => {
      var a;
      if (a = Ph) a = Kh(), a = !!a.indexOf && 0 <= a.indexOf("1337");
      return a
    });

  function Rh(a) {
    a && Oh && Qh() && (Oh.clearMarks(`goog_${a.label}_${a.uniqueId}_start`), Oh.clearMarks(`goog_${a.label}_${a.uniqueId}_end`))
  }
  class Sh {
    constructor() {
      this.i = [];
      this.j = m || m;
      let a = null;
      m && (m.google_js_reporting_queue = m.google_js_reporting_queue || [], this.i = m.google_js_reporting_queue, a = m.google_measure_js_timing);
      this.h = Qh() || (null != a ? a : 1 > Math.random())
    }
    start(a, b) {
      if (!this.h) return null;
      a = new Nh(a, b);
      b = `goog_${a.label}_${a.uniqueId}_start`;
      Oh && Qh() && Oh.mark(b);
      return a
    }
    end(a) {
      if (this.h && "number" === typeof a.value) {
        a.duration = (Mh() || Lh()) - a.value;
        var b = `goog_${a.label}_${a.uniqueId}_end`;
        Oh && Qh() && Oh.mark(b);
        !this.h || 2048 < this.i.length ||
          this.i.push(a)
      }
    }
  };
  cd `https://www.googletagservices.com/console/host/host.js`;
  cd `https://www.googletagservices.com/console/panel/index.html`;
  cd `https://www.googletagservices.com/console/overlay/index.html`;
  var Th = (a, b) => {
    do {
      const c = Ec(a, b);
      if (c && "fixed" == c.position) return !1
    } while (a = a.parentElement);
    return !0
  };

  function Uh(a, b) {
    var c = ["width", "height"];
    for (let e = 0; e < c.length; e++) {
      const f = "google_ad_" + c[e];
      if (!b.hasOwnProperty(f)) {
        var d = G(a[c[e]]);
        d = null === d ? null : Math.round(d);
        null != d && (b[f] = d)
      }
    }
  }
  var Vh = (a, b) => !((Mc.test(b.google_ad_width) || Lc.test(a.style.width)) && (Mc.test(b.google_ad_height) || Lc.test(a.style.height))),
    Xh = (a, b) => (a = Wh(a, b)) ? a.y : 0,
    Wh = (a, b) => {
      try {
        const c = b.document.documentElement.getBoundingClientRect(),
          d = a.getBoundingClientRect();
        return {
          x: d.left - c.left,
          y: d.top - c.top
        }
      } catch (c) {
        return null
      }
    },
    Yh = a => {
      let b = 0;
      for (let c in yf) - 1 != a.indexOf(c) && (b |= yf[c]);
      return b
    },
    Zh = (a, b, c, d, e) => {
      if (a !== a.top) return Bc(a) ? 3 : 16;
      if (!(488 > N(a).clientWidth)) return 4;
      if (!(a.innerHeight >= a.innerWidth)) return 5;
      const f = N(a).clientWidth;
      if (!f || (f - c) / f > d) a = 6;
      else {
        if (c = "true" != e.google_full_width_responsive) a: {
          c = b.parentElement;
          for (b = N(a).clientWidth; c; c = c.parentElement)
            if ((d = Ec(c, a)) && (e = G(d.width)) && !(e >= b) && "visible" != d.overflow) {
              c = !0;
              break a
            } c = !1
        }
        a = c ? 7 : !0
      }
      return a
    },
    $h = (a, b, c, d) => {
      const e = Zh(b, c, a, .3, d);
      !0 !== e ? a = e : "true" == d.google_full_width_responsive || Th(c, b) ? (b = N(b).clientWidth, a = b - a, a = b && 0 <= a ? !0 : b ? -10 > a ? 11 : 0 > a ? 14 : 12 : 10) : a = 9;
      return a
    },
    ai = (a, b, c) => {
      a = a.style;
      "rtl" == b ? a.marginRight = c : a.marginLeft = c
    };
  const bi = (a, b) => {
      if (3 == b.nodeType) return /\S/.test(b.data);
      if (1 == b.nodeType) {
        if (/^(script|style)$/i.test(b.nodeName)) return !1;
        let c;
        try {
          c = Ec(b, a)
        } catch (d) {}
        return !c || "none" != c.display && !("absolute" == c.position && ("hidden" == c.visibility || "collapse" == c.visibility))
      }
      return !1
    },
    ci = (a, b, c) => {
      a = Wh(b, a);
      return "rtl" == c ? -a.x : a.x
    };
  var di = (a, b) => {
    var c;
    c = (c = b.parentElement) ? (c = Ec(c, a)) ? c.direction : "" : "";
    if (c) {
      b.style.border = b.style.borderStyle = b.style.outline = b.style.outlineStyle = b.style.transition = "none";
      b.style.borderSpacing = b.style.padding = "0";
      ai(b, c, "0px");
      b.style.width = N(a).clientWidth + "px";
      if (0 !== ci(a, b, c)) {
        ai(b, c, "0px");
        var d = ci(a, b, c);
        ai(b, c, -1 * d + "px");
        a = ci(a, b, c);
        0 !== a && a !== d && ai(b, c, d / (a - d) * d + "px")
      }
      b.style.zIndex = 30
    }
  };
  var ei = class {
    constructor(a, b) {
      this.l = a;
      this.j = b
    }
    minWidth() {
      return this.l
    }
    height() {
      return this.j
    }
    h(a) {
      return 300 < a && 300 < this.j ? this.l : Math.min(1200, Math.round(a))
    }
    i() {}
  };
  var fi = (a, b, c, d = e => e) => {
      let e;
      return a.style && a.style[c] && d(a.style[c]) || (e = Ec(a, b)) && e[c] && d(e[c]) || null
    },
    gi = a => b => b.minWidth() <= a,
    ji = (a, b, c, d) => {
      const e = a && hi(c, b),
        f = ii(b, d);
      return g => !(e && g.height() >= f)
    },
    ki = a => b => b.height() <= a,
    hi = (a, b) => Xh(a, b) < N(b).clientHeight - 100,
    li = (a, b) => {
      var c = fi(b, a, "height", G);
      if (c) return c;
      var d = b.style.height;
      b.style.height = "inherit";
      c = fi(b, a, "height", G);
      b.style.height = d;
      if (c) return c;
      c = Infinity;
      do(d = b.style && G(b.style.height)) && (c = Math.min(c, d)), (d = fi(b, a, "maxHeight",
        G)) && (c = Math.min(c, d)); while ((b = b.parentElement) && "HTML" != b.tagName);
      return c
    };
  const ii = (a, b) => {
    const c = 0 == fd(a);
    return b && c ? Math.max(250, 2 * N(a).clientHeight / 3) : 250
  };
  var mi = {
    google_ad_channel: !0,
    google_ad_client: !0,
    google_ad_host: !0,
    google_ad_host_channel: !0,
    google_adtest: !0,
    google_tag_for_child_directed_treatment: !0,
    google_tag_for_under_age_of_consent: !0,
    google_tag_partner: !0,
    google_restrict_data_processing: !0,
    google_page_url: !0,
    google_debug_params: !0,
    google_adbreak_test: !0,
    google_ad_frequency_hint: !0,
    google_admob_interstitial_slot: !0,
    google_admob_rewarded_slot: !0,
    google_max_ad_content_rating: !0,
    google_traffic_source: !0
  };
  const ni = RegExp("(^| )adsbygoogle($| )");

  function oi(a, b) {
    for (var c = 0; c < b.length; c++) {
      var d = b[c];
      const e = qc(d.Sb);
      a[e] = d.value
    }
  };

  function pi(a) {
    var b = [];
    qd(a.getElementsByTagName("p"), function (c) {
      100 <= qi(c) && b.push(c)
    });
    return b
  }

  function qi(a) {
    if (3 == a.nodeType) return a.length;
    if (1 != a.nodeType || "SCRIPT" == a.tagName) return 0;
    var b = 0;
    qd(a.childNodes, function (c) {
      b += qi(c)
    });
    return b
  }

  function ri(a) {
    return 0 == a.length || isNaN(a[0]) ? a : "\\" + (30 + parseInt(a[0], 10)) + " " + a.substring(1)
  }

  function si(a, b) {
    if (null == a.h) return b;
    switch (a.h) {
      case 1:
        return b.slice(1);
      case 2:
        return b.slice(0, b.length - 1);
      case 3:
        return b.slice(1, b.length - 1);
      case 0:
        return b;
      default:
        throw Error("Unknown ignore mode: " + a.h);
    }
  }
  const ti = class {
    constructor(a, b, c, d) {
      this.l = a;
      this.i = b;
      this.j = c;
      this.h = d
    }
    query(a) {
      var b = [];
      try {
        b = a.querySelectorAll(this.l)
      } catch (f) {}
      if (!b.length) return [];
      a = Ka(b);
      a = si(this, a);
      "number" === typeof this.i && (b = this.i, 0 > b && (b += a.length), a = 0 <= b && b < a.length ? [a[b]] : []);
      if ("number" === typeof this.j) {
        b = [];
        for (var c = 0; c < a.length; c++) {
          var d = pi(a[c]),
            e = this.j;
          0 > e && (e += d.length);
          0 <= e && e < d.length && b.push(d[e])
        }
        a = b
      }
      return a
    }
    toString() {
      return JSON.stringify({
        nativeQuery: this.l,
        occurrenceIndex: this.i,
        paragraphIndex: this.j,
        ignoreMode: this.h
      })
    }
  };
  class ui {
    constructor() {
      var a = cd `https://pagead2.googlesyndication.com/pagead/js/err_rep.js`;
      this.h = null;
      this.j = !1;
      this.l = Math.random();
      this.i = this.F;
      this.m = a
    }
    Qa(a) {
      this.h = a
    }
    A(a) {
      this.j = a
    }
    Ra(a) {
      this.i = a
    }
    F(a, b, c = .01, d, e = "jserror") {
      if ((this.j ? this.l : Math.random()) > c) return !1;
      Ih(b) || (b = new Hh(b, {
        context: a,
        id: e
      }));
      if (d || this.h) b.meta = {}, this.h && this.h(b.meta), d && d(b.meta);
      m.google_js_errors = m.google_js_errors || [];
      m.google_js_errors.push(b);
      m.error_rep_loaded || (Cc(m.document, fc(ec(this.m).toString())),
        m.error_rep_loaded = !0);
      return !1
    }
    ea(a, b, c) {
      try {
        return b()
      } catch (d) {
        if (!this.i(a, d, .01, c, "jserror")) throw d;
      }
    }
    qa(a, b) {
      return (...c) => this.ea(a, () => b.apply(void 0, c))
    }
    fa(a, b) {
      b.catch(c => {
        c = c ? c : "unknown rejection";
        this.F(a, c instanceof Error ? c : Error(c))
      })
    }
  };
  const vi = (a, b) => {
    b = b.google_js_reporting_queue = b.google_js_reporting_queue || [];
    2048 > b.length && b.push(a)
  };
  var wi = (a, b, c, d, e = !1) => {
      const f = d || window,
        g = "undefined" !== typeof queueMicrotask;
      return function () {
        e && g && queueMicrotask(() => {
          f.google_rum_task_id_counter = f.google_rum_task_id_counter || 1;
          f.google_rum_task_id_counter += 1
        });
        const h = Mh();
        let k, l = 3;
        try {
          k = b.apply(this, arguments)
        } catch (q) {
          l = 13;
          if (!c) throw q;
          c(a, q)
        } finally {
          f.google_measure_js_timing && h && vi({
            label: a.toString(),
            value: h,
            duration: (Mh() || 0) - h,
            type: l,
            ...(e && g && {
              taskId: f.google_rum_task_id_counter = f.google_rum_task_id_counter || 1
            })
          }, f)
        }
        return k
      }
    },
    xi = (a, b) => wi(a, b, (c, d) => {
      (new ui).F(c, d)
    }, void 0, !1);

  function yi(a, b, c) {
    return wi(a, b, void 0, c, !0).apply()
  }

  function zi(a) {
    if (!a) return null;
    var b = r(a, 7);
    if (r(a, 1) || a.getId() || 0 < ub(a, 4).length) {
      var c = a.getId();
      b = ub(a, 4);
      var d = r(a, 1),
        e = "";
      d && (e += d);
      c && (e += "#" + ri(c));
      if (b)
        for (c = 0; c < b.length; c++) e += "." + ri(b[c]);
      a = (b = e) ? new ti(b, r(a, 2), r(a, 5), Ai(r(a, 6))) : null
    } else a = b ? new ti(b, r(a, 2), r(a, 5), Ai(r(a, 6))) : null;
    return a
  }
  var Bi = {
    1: 1,
    2: 2,
    3: 3,
    0: 0
  };

  function Ai(a) {
    return null == a ? a : Bi[a]
  }
  var Ci = {
    1: 0,
    2: 1,
    3: 2,
    4: 3
  };

  function Di(a) {
    return a.google_ama_state = a.google_ama_state || {}
  }

  function Ei(a) {
    a = Di(a);
    return a.optimization = a.optimization || {}
  };
  var Fi = a => {
    switch (r(a, 8)) {
      case 1:
      case 2:
        if (null == a) var b = null;
        else b = y(a, Dd, 1), null == b ? b = null : (a = r(a, 2), b = null == a ? null : new Fd({
          Ya: [b],
          kb: a
        }));
        return null != b ? td(b) : vd(Error("Missing dimension when creating placement id"));
      case 3:
        return vd(Error("Missing dimension when creating placement id"));
      default:
        return vd(Error("Invalid type: " + r(a, 8)))
    }
  };
  var Gi = (a, b) => {
    const c = [];
    let d = a;
    for (a = () => {
        c.push({
          anchor: d.anchor,
          position: d.position
        });
        return d.anchor == b.anchor && d.position == b.position
      }; d;) {
      switch (d.position) {
        case 1:
          if (a()) return c;
          d.position = 2;
        case 2:
          if (a()) return c;
          if (d.anchor.firstChild) {
            d = {
              anchor: d.anchor.firstChild,
              position: 1
            };
            continue
          } else d.position = 3;
        case 3:
          if (a()) return c;
          d.position = 4;
        case 4:
          if (a()) return c
      }
      for (; d && !d.anchor.nextSibling && d.anchor.parentNode != d.anchor.ownerDocument.body;) {
        d = {
          anchor: d.anchor.parentNode,
          position: 3
        };
        if (a()) return c;
        d.position = 4;
        if (a()) return c
      }
      d && d.anchor.nextSibling ? d = {
        anchor: d.anchor.nextSibling,
        position: 1
      } : d = null
    }
    return c
  };

  function Hi(a, b) {
    const c = new Bd,
      d = new Ad;
    b.forEach(e => {
      if (Gb(e, Rd, 1, Ud)) {
        e = Gb(e, Rd, 1, Ud);
        if (y(e, Pd, 1) && y(y(e, Pd, 1), Dd, 1) && y(e, Pd, 2) && y(y(e, Pd, 2), Dd, 1)) {
          const g = Ii(a, y(y(e, Pd, 1), Dd, 1)),
            h = Ii(a, y(y(e, Pd, 2), Dd, 1));
          if (g && h)
            for (var f of Gi({
                anchor: g,
                position: r(y(e, Pd, 1), 2)
              }, {
                anchor: h,
                position: r(y(e, Pd, 2), 2)
              })) c.set(fa(f.anchor), f.position)
        }
        y(e, Pd, 3) && y(y(e, Pd, 3), Dd, 1) && (f = Ii(a, y(y(e, Pd, 3), Dd, 1))) && c.set(fa(f), r(y(e, Pd, 3), 2))
      } else Gb(e, Sd, 2, Ud) ? Ji(a, Gb(e, Sd, 2, Ud), c) : Gb(e, Td, 3, Ud) && Ki(a, Gb(e, Td, 3, Ud), d)
    });
    return new Li(c, d)
  }
  class Li {
    constructor(a, b) {
      this.i = a;
      this.h = b
    }
  }
  const Ji = (a, b, c) => {
      y(b, Dd, 1) && (a = Mi(a, y(b, Dd, 1))) && a.forEach(d => {
        d = fa(d);
        c.set(d, 1);
        c.set(d, 4);
        c.set(d, 2);
        c.set(d, 3)
      })
    },
    Ki = (a, b, c) => {
      y(b, Dd, 1) && (a = Mi(a, y(b, Dd, 1))) && a.forEach(d => {
        c.add(fa(d))
      })
    },
    Ii = (a, b) => (a = Mi(a, b)) && 0 < a.length ? a[0] : null,
    Mi = (a, b) => (b = zi(b)) ? b.query(a) : null;

  function Ni(a, b, c) {
    switch (c) {
      case 2:
      case 3:
        break;
      case 1:
      case 4:
        b = b.parentElement;
        break;
      default:
        throw Error("Unknown RelativePosition: " + c);
    }
    for (c = []; b;) {
      if (Oi(b)) return !0;
      if (a.h.has(b)) break;
      c.push(b);
      b = b.parentElement
    }
    c.forEach(d => a.h.add(d));
    return !1
  }

  function Pi(a) {
    a = Qi(a);
    return a.has("all") || a.has("after")
  }

  function Ri(a) {
    a = Qi(a);
    return a.has("all") || a.has("before")
  }

  function Qi(a) {
    return (a = a && a.getAttribute("data-no-auto-ads")) ? new Set(a.split("|")) : new Set
  }

  function Oi(a) {
    const b = Qi(a);
    return a && ("AUTO-ADS-EXCLUSION-AREA" === a.tagName || b.has("inside") || b.has("all"))
  }
  var Si = class {
    constructor() {
      this.h = new Set
    }
  };

  function Ti(a, b) {
    if (!a) return !1;
    a = Ec(a, b);
    if (!a) return !1;
    a = a.cssFloat || a.styleFloat;
    return "left" == a || "right" == a
  }

  function Ui(a) {
    for (a = a.previousSibling; a && 1 != a.nodeType;) a = a.previousSibling;
    return a ? a : null
  }

  function Vi(a) {
    return !!a.nextSibling || !!a.parentNode && Vi(a.parentNode)
  };

  function Wi(a = window) {
    a = a.googletag;
    return a ? .apiReady ? a : void 0
  };
  const Xi = a => {
    const b = Wi(a);
    return b ? Ea(Fa(b.pubads().getSlots(), c => a.document.getElementById(c.getSlotElementId())), c => null != c) : null
  };
  var Yi = a => {
    const b = [];
    for (const c of a) {
      a = !0;
      for (let d = 0; d < b.length; d++) {
        const e = b[d];
        if (e.contains(c)) {
          a = !1;
          break
        }
        if (c.contains(e)) {
          a = !1;
          b[d] = c;
          break
        }
      }
      a && b.push(c)
    }
    return b
  };

  function Zi(a, b) {
    if (a.l) return !0;
    a.l = !0;
    const c = A(a.j, Xd, 1);
    a.i = 0;
    const d = $i(a.D);
    var e = a.h,
      f;
    try {
      var g = (f = e.localStorage.getItem("google_ama_settings")) ? Hb(le, f) : null
    } catch (C) {
      g = null
    }
    f = null !== g && w(g, 2, !1);
    g = Di(e);
    f && (g.eatf = !0, $c(7, [!0, 0, !1]));
    var h = L(Qe) || L(Pe),
      k = L(Pe);
    if (h) {
      b: {
        f = k;
        var l = {
          cb: !1,
          eb: !1
        };
        const C = Ka(e.document.querySelectorAll(".google-auto-placed")),
          z = Ka(e.document.querySelectorAll("ins.adsbygoogle[data-anchor-shown],ins.adsbygoogle[data-anchor-status]")),
          x = Ka(e.document.querySelectorAll("ins.adsbygoogle[data-ad-format=autorelaxed]"));
        var q = (Xi(e) || Ka(e.document.querySelectorAll("div[id^=div-gpt-ad]"))).concat(Ka(e.document.querySelectorAll("iframe[id^=google_ads_iframe]")));
        const F = Ka(e.document.querySelectorAll("div.trc_related_container,div.OUTBRAIN,div[id^=rcjsload],div[id^=ligatusframe],div[id^=crt-],iframe[id^=cto_iframe],div[id^=yandex_], div[id^=Ya_sync],iframe[src*=adnxs],div.advertisement--appnexus,div[id^=apn-ad],div[id^=amzn-native-ad],iframe[src*=amazon-adsystem],iframe[id^=ox_],iframe[src*=openx],img[src*=openx],div[class*=adtech],div[id^=adtech],iframe[src*=adtech],div[data-content-ad-placement=true],div.wpcnt div[id^=atatags-]")),
          ya = Ka(e.document.querySelectorAll("ins.adsbygoogle-ablated-ad-slot")),
          V = Ka(e.document.querySelectorAll("div.googlepublisherpluginad")),
          za = Ka(e.document.querySelectorAll("html > ins.adsbygoogle"));k = [].concat(Ka(e.document.querySelectorAll("iframe[id^=aswift_],iframe[id^=google_ads_frame]")), Ka(e.document.querySelectorAll("body ins.adsbygoogle")));h = [];
        for (const [va, tc] of [
            [l.Lb, C],
            [l.cb, z],
            [l.Ob, x],
            [l.Mb, q],
            [l.Pb, F],
            [l.Kb, ya],
            [l.Nb, V],
            [l.eb, za]
          ]) l = tc,
        !1 === va ? h = h.concat(l) : k = k.concat(l);k = Yi(k);h = Yi(h);
        k = k.slice(0);
        for (v of h)
          for (h = 0; h < k.length; h++)(v.contains(k[h]) || k[h].contains(v)) && k.splice(h, 1);
        var v = k;e = N(e).clientHeight;
        for (h = 0; h < v.length; h++)
          if (k = v[h].getBoundingClientRect(), !(0 === k.height && !f || k.top > e)) {
            e = !0;
            break b
          } e = !1
      }
      g = e ? g.eatfAbg = !0 : !1
    }
    else g = f;
    if (g) return !0;
    g = new Ad([2]);
    for (e = 0; e < c.length; e++) {
      v = a;
      h = c[e];
      f = e;
      k = b;
      l = d;
      q = g;
      if (!y(h, Jd, 4) || !q.contains(r(y(h, Jd, 4), 1)) || 1 !== r(h, 8) || h && Array.isArray(r(h, 4)) && l[r(y(h, Jd, 4), 2)]) v = null;
      else {
        v.i++;
        if (k = aj(v, h, k, l)) l = Di(v.h), l.numAutoAdsPlaced ||
          (l.numAutoAdsPlaced = 0), y(h, Dd, 1) && null != r(y(h, Dd, 1), 5) && (l.numPostPlacementsPlaced ? l.numPostPlacementsPlaced++ : l.numPostPlacementsPlaced = 1), null == l.placed && (l.placed = []), l.numAutoAdsPlaced++, l.placed.push({
            index: f,
            element: k.ha
          }), $c(7, [!1, v.i, !0]);
        v = k
      }
      if (v) return !0
    }
    $c(7, [!1, a.i, !1]);
    return !1
  }

  function aj(a, b, c, d) {
    if (b && Array.isArray(r(b, 4)) && d[r(y(b, Jd, 4), 2)] || 1 != r(b, 8)) return null;
    d = y(b, Dd, 1);
    if (!d) return null;
    d = zi(d);
    if (!d) return null;
    d = d.query(a.h.document);
    if (0 == d.length) return null;
    d = d[0];
    var e = Ci[r(b, 2)];
    e = void 0 === e ? null : e;
    var f;
    if (!(f = null == e)) {
      a: {
        f = a.h;
        switch (e) {
          case 0:
            f = Ti(Ui(d), f);
            break a;
          case 3:
            f = Ti(d, f);
            break a;
          case 2:
            var g = d.lastChild;
            f = Ti(g ? 1 == g.nodeType ? g : Ui(g) : null, f);
            break a
        }
        f = !1
      }
      if (c = !f && !(!c && 2 == e && !Vi(d))) c = 1 == e || 2 == e ? d : d.parentNode,
      c = !(c && !me(c) && 0 >= c.offsetWidth);
      f = !c
    }
    if (!(c = f)) {
      c = a.A;
      f = r(b, 2);
      g = fa(d);
      g = c.i.h.get(g);
      if (!(g = g ? g.contains(f) : !1)) a: {
        if (c.h.contains(fa(d))) switch (f) {
          case 2:
          case 3:
            g = !0;
            break a;
          default:
            g = !1;
            break a
        }
        for (f = d.parentElement; f;) {
          if (c.h.contains(fa(f))) {
            g = !0;
            break a
          }
          f = f.parentElement
        }
        g = !1
      }
      c = g
    }
    if (!c) {
      c = a.G;
      f = r(b, 2);
      a: switch (f) {
        case 1:
          g = Pi(d.previousElementSibling) || Ri(d);
          break a;
        case 4:
          g = Pi(d) || Ri(d.nextElementSibling);
          break a;
        case 2:
          g = Ri(d.firstElementChild);
          break a;
        case 3:
          g = Pi(d.lastElementChild);
          break a;
        default:
          throw Error("Unknown RelativePosition: " +
            f);
      }
      c = g || Ni(c, d, f)
    }
    if (c) return null;
    f = y(b, Vd, 3);
    c = {};
    f && (c.Sa = r(f, 1), c.Ha = r(f, 2), c.Za = !!vb(f, 3));
    f = y(b, Jd, 4) && r(y(b, Jd, 4), 2) ? r(y(b, Jd, 4), 2) : null;
    f = Md(f);
    g = null != r(b, 12) ? r(b, 12) : null;
    g = null == g ? null : new Ld(null, {
      google_ml_rank: g
    });
    b = bj(a, b);
    b = Kd(a.m, f, g, b);
    f = a.h;
    a = a.H;
    var h = f.document,
      k = c.Za || !1;
    g = (new sc(h)).createElement("DIV");
    const l = g.style;
    l.width = "100%";
    l.height = "auto";
    l.clear = k ? "both" : "none";
    k = g.style;
    k.textAlign = "center";
    c.jb && oi(k, c.jb);
    h = (new sc(h)).createElement("INS");
    k = h.style;
    k.display =
      "block";
    k.margin = "auto";
    k.backgroundColor = "transparent";
    c.Sa && (k.marginTop = c.Sa);
    c.Ha && (k.marginBottom = c.Ha);
    c.Xa && oi(k, c.Xa);
    g.appendChild(h);
    c = {
      oa: g,
      ha: h
    };
    c.ha.setAttribute("data-ad-format", "auto");
    g = [];
    if (h = b && b.Ja) c.oa.className = h.join(" ");
    h = c.ha;
    h.className = "adsbygoogle";
    h.setAttribute("data-ad-client", a);
    g.length && h.setAttribute("data-ad-channel", g.join("+"));
    a: {
      try {
        var q = c.oa;
        if (L(Le)) {
          {
            const F = vf(d, e);
            if (F.init) {
              var v = F.init;
              for (d = v; d = F.ia(d);) v = d;
              var C = {
                anchor: v,
                position: F.la
              }
            } else C = {
              anchor: d,
              position: e
            }
          }
          q["google-ama-order-assurance"] = 0;
          ne(q, C.anchor, C.position)
        } else ne(q, d, e);
        b: {
          var z = c.ha;z.dataset.adsbygoogleStatus = "reserved";z.className += " adsbygoogle-noablate";q = {
            element: z
          };
          var x = b && b.Pa;
          if (z.hasAttribute("data-pub-vars")) {
            try {
              x = JSON.parse(z.getAttribute("data-pub-vars"))
            } catch (F) {
              break b
            }
            z.removeAttribute("data-pub-vars")
          }
          x && (q.params = x);
          (f.adsbygoogle = f.adsbygoogle || []).push(q)
        }
      } catch (F) {
        (z = c.oa) && z.parentNode && (x = z.parentNode, x.removeChild(z), me(x) && (x.style.display = x.getAttribute("data-init-display") ||
          "none"));
        z = !1;
        break a
      }
      z = !0
    }
    return z ? c : null
  }

  function bj(a, b) {
    return xd(zd(Fi(b).map(Nd), c => {
      Di(a.h).exception = c
    }))
  }
  const cj = class {
    constructor(a, b, c, d, e) {
      this.h = a;
      this.H = b;
      this.j = c;
      this.m = e || null;
      this.A = (this.D = d) ? Hi(a.document, A(d, Qd, 5)) : Hi(a.document, []);
      this.G = new Si;
      this.i = 0;
      this.l = !1
    }
  };

  function $i(a) {
    const b = {};
    a && ub(a, 6).forEach(c => {
      b[c] = !0
    });
    return b
  };
  var dj = class extends D {
    constructor(a) {
      super(a)
    }
  };
  const ej = RegExp("^https?://(\\w|-)+\\.cdn\\.ampproject\\.(net|org)(\\?|/|$)");
  var fj = class {
      constructor(a, b) {
        this.h = a;
        this.i = b
      }
    },
    gj = class {
      constructor(a, b, c) {
        this.url = a;
        this.v = b;
        this.La = !!c;
        this.depth = null
      }
    };

  function hj(a) {
    let b = a.toString();
    a.name && -1 == b.indexOf(a.name) && (b += ": " + a.name);
    a.message && -1 == b.indexOf(a.message) && (b += ": " + a.message);
    if (a.stack) {
      a = a.stack;
      var c = b;
      try {
        -1 == a.indexOf(c) && (a = c + "\n" + a);
        let d;
        for (; a != d;) d = a, a = a.replace(RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"), "$1");
        b = a.replace(RegExp("\n *", "g"), "\n")
      } catch (d) {
        b = c
      }
    }
    return b
  }
  class ij {
    constructor(a = null) {
      this.m = Kf;
      this.i = null;
      this.l = this.F;
      this.h = a;
      this.j = !1
    }
    Ra(a) {
      this.l = a
    }
    Qa(a) {
      this.i = a
    }
    A(a) {
      this.j = a
    }
    ea(a, b, c) {
      let d, e;
      try {
        this.h && this.h.h ? (e = this.h.start(a.toString(), 3), d = b(), this.h.end(e)) : d = b()
      } catch (f) {
        b = !0;
        try {
          Rh(e), b = this.l(a, new Hh(f, {
            message: hj(f)
          }), void 0, c)
        } catch (g) {
          this.F(217, g)
        }
        if (b) window.console ? .error ? .(f);
        else throw f;
      }
      return d
    }
    qa(a, b) {
      return (...c) => this.ea(a, () => b.apply(void 0, c))
    }
    F(a, b, c, d, e) {
      e = e || "jserror";
      let f;
      try {
        const Pa = new If;
        var g = Pa;
        g.h.push(1);
        g.i[1] = Df("context", a);
        Ih(b) || (b = new Hh(b, {
          message: hj(b)
        }));
        if (b.msg) {
          g = Pa;
          var h = b.msg.substring(0, 512);
          g.h.push(2);
          g.i[2] = Df("msg", h)
        }
        var k = b.meta || {};
        b = k;
        if (this.i) try {
          this.i(b)
        } catch (Wa) {}
        if (d) try {
          d(b)
        } catch (Wa) {}
        d = Pa;
        k = [k];
        d.h.push(3);
        d.i[3] = k;
        d = m;
        k = [];
        b = null;
        do {
          var l = d;
          if (Ac(l)) {
            var q = l.location.href;
            b = l.document && l.document.referrer || null
          } else q = b, b = null;
          k.push(new gj(q || "", l));
          try {
            d = l.parent
          } catch (Wa) {
            d = null
          }
        } while (d && l != d);
        for (let Wa = 0, qg = k.length - 1; Wa <= qg; ++Wa) k[Wa].depth = qg - Wa;
        l = m;
        if (l.location &&
          l.location.ancestorOrigins && l.location.ancestorOrigins.length == k.length - 1)
          for (q = 1; q < k.length; ++q) {
            var v = k[q];
            v.url || (v.url = l.location.ancestorOrigins[q - 1] || "", v.La = !0)
          }
        var C = k;
        let uc = new gj(m.location.href, m, !1);
        l = null;
        const Ed = C.length - 1;
        for (v = Ed; 0 <= v; --v) {
          var z = C[v];
          !l && ej.test(z.url) && (l = z);
          if (z.url && !z.La) {
            uc = z;
            break
          }
        }
        z = null;
        const Nl = C.length && C[Ed].url;
        0 != uc.depth && Nl && (z = C[Ed]);
        f = new fj(uc, z);
        if (f.i) {
          C = Pa;
          var x = f.i.url || "";
          C.h.push(4);
          C.i[4] = Df("top", x)
        }
        var F = {
          url: f.h.url || ""
        };
        if (f.h.url) {
          var ya =
            f.h.url.match(xc),
            V = ya[1],
            za = ya[3],
            va = ya[4];
          x = "";
          V && (x += V + ":");
          za && (x += "//", x += za, va && (x += ":" + va));
          var tc = x
        } else tc = "";
        V = Pa;
        F = [F, {
          url: tc
        }];
        V.h.push(5);
        V.i[5] = F;
        Lf(this.m, e, Pa, this.j, c)
      } catch (Pa) {
        try {
          Lf(this.m, e, {
            context: "ecmserr",
            rctx: a,
            msg: hj(Pa),
            url: f && f.h.url
          }, this.j, c)
        } catch (uc) {}
      }
      return !0
    }
    fa(a, b) {
      b.catch(c => {
        c = c ? c : "unknown rejection";
        this.F(a, c instanceof Error ? c : Error(c))
      })
    }
  };
  class Q extends Error {
    constructor(a = "") {
      super();
      this.name = "TagError";
      this.message = a ? "adsbygoogle.push() error: " + a : "";
      Error.captureStackTrace ? Error.captureStackTrace(this, Q) : this.stack = Error().stack || ""
    }
  };
  let Kf, R;
  const jj = new Sh;
  var kj = a => {
    null != a && (m.google_measure_js_timing = a);
    m.google_measure_js_timing || (jj.h = !1, jj.i != jj.j.google_js_reporting_queue && (Qh() && Da(jj.i, Rh), jj.i.length = 0))
  };
  (a => {
    Kf = a || new Mf;
    "number" !== typeof m.google_srt && (m.google_srt = Math.random());
    Jf();
    R = new ij(jj);
    R.A(!0);
    "complete" == m.document.readyState ? kj() : jj.h && oc(m, "load", () => {
      kj()
    })
  })();
  var lj = (a, b, c) => R.ea(a, b, c),
    mj = (a, b) => R.qa(a, b),
    nj = (a, b, c) => {
      const d = K(Gh).h();
      !b.eid && d.length && (b.eid = d.toString());
      Lf(Kf, a, b, !0, c)
    },
    oj = (a, b, c, d) => {
      let e;
      Ih(b) ? e = b.msg || hj(b.error) : e = hj(b);
      return 0 == e.indexOf("TagError") ? (c = b instanceof Hh ? b.error : b, c.pbr || (c.pbr = !0, R.F(a, b, .1, d, "puberror")), !1) : R.F(a, b, c, d)
    };

  function pj(a) {
    try {
      var b = a.localStorage.getItem("google_auto_fc_cmp_setting") || null
    } catch (d) {
      b = null
    }
    const c = b;
    return c ? wd(() => Hb(dj, c)) : td(null)
  };

  function qj() {
    if (rj) return rj;
    const a = bd() || window,
      b = a.google_persistent_state_async;
    return null != b && "object" == typeof b && null != b.S && "object" == typeof b.S ? rj = b : a.google_persistent_state_async = rj = new sj
  }

  function tj(a) {
    return uj[a] || "google_ps_" + a
  }

  function vj(a, b, c) {
    b = tj(b);
    a = a.S;
    const d = a[b];
    return void 0 === d ? a[b] = c : d
  }
  class sj {
    constructor() {
      this.S = {}
    }
  }
  var rj = null;
  const uj = {
    [8]: "google_prev_ad_formats_by_region",
    [9]: "google_prev_ad_slotnames_by_region"
  };

  function wj(a) {
    this.h = a || {
      cookie: ""
    }
  }
  wj.prototype.set = function (a, b, c) {
    let d, e, f, g = !1,
      h;
    "object" === typeof c && (h = c.Tb, g = c.Ub || !1, f = c.domain || void 0, e = c.path || void 0, d = c.ib);
    if (/[;=\s]/.test(a)) throw Error('Invalid cookie name "' + a + '"');
    if (/[;\r\n]/.test(b)) throw Error('Invalid cookie value "' + b + '"');
    void 0 === d && (d = -1);
    this.h.cookie = a + "=" + b + (f ? ";domain=" + f : "") + (e ? ";path=" + e : "") + (0 > d ? "" : 0 == d ? ";expires=" + (new Date(1970, 1, 1)).toUTCString() : ";expires=" + (new Date(Date.now() + 1E3 * d)).toUTCString()) + (g ? ";secure" : "") + (null != h ? ";samesite=" + h : "")
  };
  wj.prototype.get = function (a, b) {
    const c = a + "=",
      d = (this.h.cookie || "").split(";");
    for (let e = 0, f; e < d.length; e++) {
      f = ra(d[e]);
      if (0 == f.lastIndexOf(c, 0)) return f.slice(c.length);
      if (f == a) return ""
    }
    return b
  };
  wj.prototype.isEmpty = function () {
    return !this.h.cookie
  };
  wj.prototype.clear = function () {
    var a = (this.h.cookie || "").split(";");
    const b = [];
    var c = [];
    let d, e;
    for (let f = 0; f < a.length; f++) e = ra(a[f]), d = e.indexOf("="), -1 == d ? (b.push(""), c.push(e)) : (b.push(e.substring(0, d)), c.push(e.substring(d + 1)));
    for (c = b.length - 1; 0 <= c; c--) a = b[c], this.get(a), this.set(a, "", {
      ib: 0,
      path: void 0,
      domain: void 0
    })
  };

  function xj(a, b = window) {
    if (vb(a, 5)) try {
      return b.localStorage
    } catch {}
    return null
  };

  function yj(a) {
    var b = new zj;
    return t(b, 5, a)
  }
  var zj = class extends D {
    constructor() {
      super(void 0)
    }
  };
  const Aj = a => {
    void 0 !== a.addtlConsent && "string" !== typeof a.addtlConsent && (a.addtlConsent = void 0);
    void 0 !== a.gdprApplies && "boolean" !== typeof a.gdprApplies && (a.gdprApplies = void 0);
    return void 0 !== a.tcString && "string" !== typeof a.tcString || void 0 !== a.listenerId && "number" !== typeof a.listenerId ? 2 : a.cmpStatus && "error" !== a.cmpStatus ? 0 : 3
  };

  function Bj(a) {
    if (a.i) return a.i;
    a.i = Oc(a.h, "__tcfapiLocator");
    return a.i
  }

  function Cj(a) {
    return "function" === typeof a.h.__tcfapi || null != Bj(a)
  }

  function Dj(a, b, c, d) {
    c || (c = () => {});
    if ("function" === typeof a.h.__tcfapi) a = a.h.__tcfapi, a(b, 2, c, d);
    else if (Bj(a)) {
      Ej(a);
      const e = ++a.H;
      a.m[e] = c;
      a.i && a.i.postMessage({
        __tcfapiCall: {
          command: b,
          version: 2,
          callId: e,
          parameter: d
        }
      }, "*")
    } else c({}, !1)
  }

  function Ej(a) {
    a.l || (a.l = b => {
      try {
        var c = ("string" === typeof b.data ? JSON.parse(b.data) : b.data).__tcfapiReturn;
        a.m[c.callId](c.returnValue, c.success)
      } catch (d) {}
    }, oc(a.h, "message", a.l))
  }
  class Fj extends od {
    constructor(a) {
      super();
      this.h = a;
      this.i = null;
      this.m = {};
      this.H = 0;
      this.D = !1;
      this.l = null
    }
    j() {
      this.m = {};
      this.l && (pc(this.h, "message", this.l), delete this.l);
      delete this.m;
      delete this.h;
      delete this.i;
      super.j()
    }
    addEventListener(a) {
      let b = {
        internalBlockOnErrors: this.D
      };
      const c = nc(() => a(b));
      let d = 0;
      d = setTimeout(() => {
        b.tcString = "tcunavailable";
        b.internalErrorState = 1;
        c()
      }, 500);
      const e = (f, g) => {
        clearTimeout(d);
        f ? (b = f, b.internalErrorState = Aj(b), b.internalBlockOnErrors = this.D, g && 0 === b.internalErrorState ||
          (b.tcString = "tcunavailable", g || (b.internalErrorState = 3))) : (b.tcString = "tcunavailable", b.internalErrorState = 3);
        a(b)
      };
      try {
        Dj(this, "addEventListener", e)
      } catch (f) {
        b.tcString = "tcunavailable", b.internalErrorState = 3, d && (clearTimeout(d), d = 0), c()
      }
    }
    removeEventListener(a) {
      a && a.listenerId && Dj(this, "removeEventListener", null, a.listenerId)
    }
  };
  var Kj = ({
      v: a,
      L: b,
      ra: c,
      Ia: d,
      ja: e = !1,
      ka: f = !1
    }) => {
      b = Gj({
        v: a,
        L: b,
        ja: e,
        ka: f
      });
      null != b.h || "tcunav" != b.i.message ? d(b) : Hj(a, c).then(g => g.map(Ij)).then(g => g.map(h => Jj(a, h))).then(d)
    },
    Gj = ({
      v: a,
      L: b,
      ja: c = !1,
      ka: d = !1
    }) => {
      if (!Lj({
          v: a,
          L: b,
          ja: c,
          ka: d
        })) return Jj(a, yj(!0));
      b = qj();
      return (b = vj(b, 24)) ? Jj(a, Ij(b)) : vd(Error("tcunav"))
    };

  function Lj({
    v: a,
    L: b,
    ja: c,
    ka: d
  }) {
    if (!(d = !d && Cj(new Fj(a)))) {
      if (c = !c) {
        if (b) {
          a = pj(a);
          if (null != a.h)
            if ((a = a.h.value) && null != r(a, 1)) b: switch (a = r(a, 1), a) {
              case 1:
                a = !0;
                break b;
              default:
                throw Error("Unhandled AutoGdprFeatureStatus: " + a);
            } else a = !1;
            else R.F(806, a.i, void 0, void 0), a = !1;
          b = !a
        }
        c = b
      }
      d = c
    }
    return d ? !0 : !1
  }

  function Hj(a, b) {
    return Promise.race([Mj(), Nj(a, b)])
  }

  function Mj() {
    return (new Promise(a => {
      var b = qj();
      a = {
        resolve: a
      };
      const c = vj(b, 25, []);
      c.push(a);
      b.S[tj(25)] = c
    })).then(Oj)
  }

  function Nj(a, b) {
    return new Promise(c => {
      a.setTimeout(c, b, vd(Error("tcto")))
    })
  }

  function Oj(a) {
    return a ? td(a) : vd(Error("tcnull"))
  }

  function Ij(a) {
    if (!1 === a.gdprApplies) var b = !0;
    else void 0 === a.internalErrorState && (a.internalErrorState = Aj(a)), b = "error" === a.cmpStatus || 0 !== a.internalErrorState ? !a.internalBlockOnErrors : "loaded" !== a.cmpStatus || "tcloaded" !== a.eventStatus && "useractioncomplete" !== a.eventStatus ? !1 : !0;
    if (b)
      if (!1 !== a.gdprApplies && "tcunavailable" !== a.tcString && void 0 !== a.gdprApplies && "string" === typeof a.tcString && a.tcString.length) {
        b: {
          if (a.publisher && a.publisher.restrictions && (b = a.publisher.restrictions["1"], void 0 !== b)) {
            b =
              b["755"];
            break b
          }
          b = void 0
        }
        0 === b ? a = !1 : a.purpose && a.vendor ? (b = a.vendor.consents, (b = !(!b || !b["755"])) && a.purposeOneTreatment && "CH" === a.publisherCC ? a = !0 : (b && (a = a.purpose.consents, b = !(!a || !a["1"])), a = b)) : a = !0
      }
    else a = !0;
    else a = !1;
    return yj(a)
  }

  function Jj(a, b) {
    return (a = xj(b, a)) ? td(a) : vd(Error("unav"))
  };
  var Pj = class extends D {
      constructor(a) {
        super(a)
      }
    },
    Rj = class extends D {
      constructor(a) {
        super(a, -1, Qj)
      }
    },
    Qj = [1, 2];
  const Sj = class {
    constructor(a) {
      this.exception = a
    }
  };

  function Tj(a, b) {
    try {
      var c = a.i,
        d = c.resolve,
        e = a.h;
      Di(e.h);
      A(e.j, Xd, 1);
      d.call(c, new Sj(b))
    } catch (f) {
      a = a.i, b = f, kd(a), a.h = 2, a.j = b, md(a.i)
    }
  }
  var Uj = class {
    constructor(a, b, c) {
      this.j = a;
      this.h = b;
      this.i = c
    }
    start() {
      this.l()
    }
    l() {
      try {
        switch (this.j.document.readyState) {
          case "complete":
          case "interactive":
            Zi(this.h, !0);
            Tj(this);
            break;
          default:
            Zi(this.h, !1) ? Tj(this) : this.j.setTimeout(la(this.l, this), 100)
        }
      } catch (a) {
        Tj(this, a)
      }
    }
  };
  var Vj = "a".charCodeAt(),
    Wj = Vb(id),
    Xj = Vb(jd);

  function S(a, b) {
    if (a.h + b > a.i.length) throw Error("Requested length " + b + " is past end of string.");
    const c = a.i.substring(a.h, a.h + b);
    a.h += b;
    return parseInt(c, 2)
  }

  function Yj(a) {
    return String.fromCharCode(Vj + S(a, 6)) + String.fromCharCode(Vj + S(a, 6))
  }

  function Zj(a) {
    let b = S(a, 12);
    const c = [];
    for (; b--;) {
      var d = !0 === !!S(a, 1),
        e = S(a, 16);
      if (d)
        for (d = S(a, 16); e <= d; e++) c.push(e);
      else c.push(e)
    }
    c.sort((f, g) => f - g);
    return c
  }

  function ak(a, b, c) {
    const d = [];
    for (let e = 0; e < b; e++)
      if (S(a, 1)) {
        const f = e + 1;
        if (c && -1 === c.indexOf(f)) throw Error(`ID: ${f} is outside of allowed values!`);
        d.push(f)
      } return d
  }

  function bk(a) {
    const b = S(a, 16);
    return !0 === !!S(a, 1) ? (a = Zj(a), a.forEach(c => {
      if (c > b) throw Error(`ID ${c} is past MaxVendorId ${b}!`);
    }), a) : ak(a, b)
  }
  class ck {
    constructor(a) {
      if (/[^01]/.test(a)) throw Error(`Input bitstring ${a} is malformed!`);
      this.i = a;
      this.h = 0
    }
  };
  var ek = (a, b) => {
    try {
      var c = Sa(a.split(".")[0]).map(e => e.toString(2).padStart(8, "0")).join("");
      const d = new ck(c);
      c = {};
      c.tcString = a;
      c.gdprApplies = !0;
      d.h += 78;
      c.cmpId = S(d, 12);
      c.cmpVersion = S(d, 12);
      d.h += 30;
      c.tcfPolicyVersion = S(d, 6);
      c.isServiceSpecific = !!S(d, 1);
      c.useNonStandardStacks = !!S(d, 1);
      c.specialFeatureOptins = dk(ak(d, 12, Xj), Xj);
      c.purpose = {
        consents: dk(ak(d, 24, Wj), Wj),
        legitimateInterests: dk(ak(d, 24, Wj), Wj)
      };
      c.purposeOneTreatment = !!S(d, 1);
      c.publisherCC = Yj(d);
      c.vendor = {
        consents: dk(bk(d), b),
        legitimateInterests: dk(bk(d),
          b)
      };
      return c
    } catch (d) {
      return null
    }
  };
  const dk = (a, b) => {
    const c = {};
    if (Array.isArray(b) && 0 !== b.length)
      for (const d of b) c[d] = -1 !== a.indexOf(d);
    else
      for (const d of a) c[d] = !0;
    delete c[0];
    return c
  };
  var fk = class {
    constructor(a) {
      this.key = a;
      this.defaultValue = !1;
      this.valueType = "boolean"
    }
  };

  function gk(a) {
    hk || (hk = new ik);
    const b = hk.h[a.key];
    if ("proto" === a.valueType) {
      try {
        const c = JSON.parse(b);
        if (Array.isArray(c)) return c
      } catch (c) {}
      return a.defaultValue
    }
    return typeof b === typeof a.defaultValue ? b : a.defaultValue
  }
  var jk = class {
    constructor() {
      this.h = {}
    }
  };
  var kk = class extends D {
      constructor() {
        super(void 0)
      }
    },
    lk = class extends D {
      constructor() {
        super(void 0)
      }
    };
  var mk = class extends D {
      constructor() {
        super(void 0)
      }
    },
    nk = [11, 8, 12, 13, 15, 17, 19, 18, 20, 21, 22, 24, 25];
  var ok = class {};
  var qk = class extends D {
      constructor(a) {
        super(a, -1, pk)
      }
    },
    rk = class extends D {
      constructor(a) {
        super(a)
      }
    },
    sk = class extends D {
      constructor(a) {
        super(a)
      }
    },
    pk = [7];
  var tk = new fk("45368529"),
    uk = new fk("45369554");
  var ik = class extends jk {
      constructor() {
        super();
        var a = m.__fcexpdef || "";
        try {
          const b = JSON.parse(a)[0];
          a = "";
          for (let c = 0; c < b.length; c++) a += String.fromCharCode(b.charCodeAt(c) ^ "\u0003\u0007\u0003\u0007\b\u0004\u0004\u0006\u0005\u0003".charCodeAt(c % 10));
          this.h = JSON.parse(a)
        } catch (b) {}
      }
    },
    hk;

  function vk(a) {
    return (a = wk(a)) ? y(a, rk, 4) : null
  }

  function wk(a) {
    if (a = (new wj(a)).get("FCCDCF", ""))
      if (gk(tk))
        if (a.startsWith("%")) try {
          var b = decodeURIComponent(a)
        } catch (c) {
          xk(1), b = null
        } else b = a;
        else b = a;
    else b = null;
    try {
      return b ? Hb(qk, b) : null
    } catch (c) {
      return xk(2), null
    }
  }

  function xk(a) {
    new ok;
    var b = new lk;
    a = t(b, 7, a);
    b = new kk;
    a = Cb(b, 1, a);
    b = new mk;
    Db(b, 22, nk, a);
    gk(uk)
  };
  Vb(id).map(a => Number(a));
  Vb(jd).map(a => Number(a));

  function yk(a) {
    a.__tcfapiPostMessageReady || zk(new Ak(a))
  }

  function zk(a) {
    a.i = b => {
      const c = "string" == typeof b.data;
      let d;
      try {
        d = c ? JSON.parse(b.data) : b.data
      } catch (f) {
        return
      }
      const e = d.__tcfapiCall;
      !e || "ping" !== e.command && "getTCData" !== e.command && "addEventListener" !== e.command && "removeEventListener" !== e.command || a.h.__tcfapi(e.command, e.version, (f, g) => {
        const h = {};
        h.__tcfapiReturn = "removeEventListener" === e.command ? {
          success: f,
          callId: e.callId
        } : {
          returnValue: f,
          success: g,
          callId: e.callId
        };
        f = c ? JSON.stringify(h) : h;
        b.source && "function" === typeof b.source.postMessage && b.source.postMessage(f,
          b.origin);
        return f
      }, e.parameter)
    };
    a.h.addEventListener("message", a.i);
    a.h.__tcfapiPostMessageReady = !0
  }
  var Ak = class {
    constructor(a) {
      this.h = a;
      this.i = null
    }
  };
  var Bk = (a, b) => {
    const c = a.document,
      d = () => {
        if (!a.frames[b])
          if (c.body) {
            const e = Dc("IFRAME", c);
            e.style.display = "none";
            e.style.width = "0px";
            e.style.height = "0px";
            e.style.border = "none";
            e.style.zIndex = "-1000";
            e.style.left = "-1000px";
            e.style.top = "-1000px";
            e.name = b;
            c.body.appendChild(e)
          } else a.setTimeout(d, 5)
      };
    d()
  };

  function Ck() {
    var a = window,
      b = L(Ze);
    a.__uspapi || a.frames.__uspapiLocator || (a = new Dk(a), Ek(a), b && Fk(a))
  }

  function Ek(a) {
    !a.m || a.h.__uspapi || a.h.frames.__uspapiLocator || (a.h.__uspapiManager = "fc", Bk(a.h, "__uspapiLocator"), na("__uspapi", (...b) => Gk(a, ...b)))
  }

  function Fk(a) {
    !a.j || a.h.__tcfapi || a.h.frames.__tcfapiLocator || (a.h.__tcfapiManager = "fc", Bk(a.h, "__tcfapiLocator"), a.h.__tcfapiEventListeners = a.h.__tcfapiEventListeners || [], na("__tcfapi", (...b) => Hk(a, ...b)), yk(a.h))
  }

  function Gk(a, b, c, d) {
    "function" === typeof d && "getUSPData" === b && d({
      version: 1,
      uspString: a.m
    }, !0)
  }

  function Hk(a, b, c, d, e = null) {
    if ("function" === typeof d)
      if (c && 2 !== c) d(null, !1);
      else switch (c = a.h.__tcfapiEventListeners, b) {
        case "getTCData":
          !e || Array.isArray(e) && e.every(f => "number" === typeof f) ? d(Ik(a, e, null), !0) : d(null, !1);
          break;
        case "ping":
          d({
            gdprApplies: !0,
            cmpLoaded: !0,
            cmpStatus: "loaded",
            displayStatus: "disabled",
            apiVersion: "2.0",
            cmpVersion: 1,
            cmpId: 300
          });
          break;
        case "addEventListener":
          b = c.push(d);
          d(Ik(a, null, b - 1), !0);
          break;
        case "removeEventListener":
          c[e] ? (c[e] = null, d(!0)) : d(!1);
          break;
        case "getInAppTCData":
        case "getVendorList":
          d(null,
            !1)
      }
  }

  function Ik(a, b, c) {
    if (!a.j) return null;
    b = ek(a.j, b);
    b.addtlConsent = null != a.l ? a.l : void 0;
    b.cmpStatus = "loaded";
    b.eventStatus = "tcloaded";
    null != c && (b.listenerId = c);
    return b
  }
  class Dk {
    constructor(a) {
      this.h = a;
      this.i = a.document;
      this.m = (a = (a = wk(this.i)) ? y(a, sk, 5) || null : null) ? r(a, 2) : null;
      this.j = (a = vk(this.i)) && null != r(a, 1) ? r(a, 1) : null;
      this.l = (a = vk(this.i)) && null != r(a, 2) ? r(a, 2) : null
    }
  };
  var Jk = class extends D {
    constructor() {
      super(void 0)
    }
    getWidth() {
      return u(this, 1, 0)
    }
    getHeight() {
      return u(this, 2, 0)
    }
  };
  var Kk = class extends D {
    constructor() {
      super(void 0)
    }
  };
  var Lk = class extends D {
      constructor() {
        super(void 0)
      }
    },
    Mk = [4, 5];
  const Nk = a => {
      const b = /[a-zA-Z0-9._~-]/,
        c = /%[89a-zA-Z]./;
      return a.replace(/(%[a-zA-Z0-9]{2})/g, function (d) {
        if (!d.match(c)) {
          const e = decodeURIComponent(d);
          if (e.match(b)) return e
        }
        return d.toUpperCase()
      })
    },
    Ok = a => {
      let b = "";
      const c = /[/%?&=]/;
      for (let d = 0; d < a.length; ++d) {
        const e = a[d];
        b = e.match(c) ? b + e : b + encodeURIComponent(e)
      }
      return b
    };
  var Pk = a => {
    a = ub(a, 2);
    if (!a) return !1;
    for (let b = 0; b < a.length; b++)
      if (1 == a[b]) return !0;
    return !1
  };
  const Rk = (a, b) => {
      a = Ok(Nk(a.location.pathname)).replace(/(^\/)|(\/$)/g, "");
      const c = Jc(a),
        d = Qk(a);
      return b.find(e => {
        const f = Array.isArray(r(e, 7)) ? r(y(e, he, 7), 1) : r(e, 1);
        e = Array.isArray(r(e, 7)) ? r(y(e, he, 7), 2) : 2;
        if ("number" !== typeof f) return !1;
        switch (e) {
          case 1:
            return f == c;
          case 2:
            return d[f] || !1
        }
        return !1
      }) || null
    },
    Qk = a => {
      const b = {};
      for (;;) {
        b[Jc(a)] = !0;
        if (!a) return b;
        a = a.substring(0, a.lastIndexOf("/"))
      }
    };
  const Sk = {
    google_ad_channel: !0,
    google_ad_host: !0
  };
  var Tk = (a, b) => {
      a.location.href && a.location.href.substring && (b.url = a.location.href.substring(0, 200));
      nj("ama", b, .01)
    },
    Uk = a => {
      const b = {};
      E(Sk, (c, d) => {
        d in a && (b[d] = a[d])
      });
      return b
    };
  var Vk = a => {
      a = y(a, ee, 3);
      return !a || r(a, 1) <= Date.now() ? !1 : !0
    },
    Yk = a => (a = Wk(Xk(a))) ? Vk(a) ? a : null : null,
    Zk = (a, b) => {
      try {
        b.removeItem("google_ama_config")
      } catch (c) {
        Tk(a, {
          lserr: 1
        })
      }
    };

  function Wk(a) {
    try {
      return a ? Hb(de, a) : null
    } catch (b) {
      return null
    }
  }

  function Xk(a) {
    if (L(Ke)) return null;
    try {
      return a.getItem("google_ama_config")
    } catch (b) {
      return null
    }
  };
  var $k = class extends D {
    constructor(a) {
      super(a)
    }
    l() {
      return w(this, 3)
    }
  };
  var bl = class extends D {
      constructor(a) {
        super(a, -1, al)
      }
    },
    al = [1];
  var dl = class extends D {
      constructor(a) {
        super(a, -1, cl)
      }
      getId() {
        return u(this, 1, 0)
      }
      O() {
        return u(this, 7, 0)
      }
    },
    cl = [2];
  var fl = class extends D {
      constructor(a) {
        super(a, -1, el)
      }
      O() {
        return u(this, 5, 0)
      }
    },
    el = [2];
  var hl = class extends D {
      constructor(a) {
        super(a, -1, gl)
      }
    },
    jl = class extends D {
      constructor(a) {
        super(a, -1, il)
      }
      O() {
        return u(this, 1, 0)
      }
    },
    kl = class extends D {
      constructor(a) {
        super(a)
      }
      l() {
        return u(this, 2, 0)
      }
      m() {
        return u(this, 4, 0)
      }
      A() {
        return w(this, 3)
      }
    },
    gl = [1, 4, 2, 3],
    il = [2];

  function ll(a) {
    return Gb(a, bl, 14, tb)
  }
  var nl = class extends D {
      constructor(a) {
        super(a, -1, ml)
      }
    },
    ml = [19],
    tb = [13, 14];
  let ol = void 0;

  function pl() {
    Tf(ol, Rf);
    return ol
  };
  var sl = (a, b, c = "", d = null) => 1 === b && ql(c, d) ? !0 : rl(a, c, e => Ga(A(e, Pb, 2), f => r(f, 1) === b)),
    ql = (a, b) => b ? rb(b, 13) ? w(Gb(b, $k, 13, tb), 1) : rb(b, 14) && "" !== a && 1 === ub(ll(b), 1).length && ub(ll(b), 1)[0] === a ? w(y(ll(b), $k, 2), 1) : !1 : !1,
    tl = (a, b) => {
      b = u(b, 18, 0); - 1 !== b && (a.tmod = b)
    },
    vl = a => {
      const b = Bc(H) || H;
      return ul(b, a) ? !0 : rl(H, "", c => Ga(ub(c, 3), d => d === a))
    },
    wl = (a = "") => rl(m, a, () => !0);

  function ul(a, b) {
    a = (a = (a = a.location && a.location.hash) && a.match(/forced_clientside_labs=([\d,]+)/)) && a[1];
    return !!a && Ja(a.split(","), b.toString())
  }

  function rl(a, b, c) {
    a = Bc(a) || a;
    const d = xl(a);
    b && (b = hd(String(b)));
    return Ub(d, (e, f) => Object.prototype.hasOwnProperty.call(d, f) && (!b || b === f) && c(e))
  }

  function xl(a) {
    a = yl(a);
    const b = {};
    E(a, (c, d) => {
      try {
        const e = new Ob(c);
        b[d] = e
      } catch (e) {}
    });
    return b
  }
  var yl = a => L(qe) ? (a = Gj({
    v: a,
    L: pl()
  }), null != a.h ? (zl("ok"), a = Al(a.h.value)) : (zl(a.i.message), a = {}), a) : Al(a.localStorage);

  function Al(a) {
    try {
      const b = a.getItem("google_adsense_settings");
      if (!b) return {};
      const c = JSON.parse(b);
      return c !== Object(c) ? {} : Tb(c, (d, e) => Object.prototype.hasOwnProperty.call(c, e) && "string" === typeof e && Array.isArray(d))
    } catch (b) {
      return {}
    }
  }

  function zl(a) {
    L(pe) && nj("abg_adsensesettings_lserr", {
      s: a,
      g: L(qe),
      c: pl(),
      r: .01
    }, .01)
  };

  function T(a) {
    a.google_ad_modifications || (a.google_ad_modifications = {});
    return a.google_ad_modifications
  }

  function Bl(a) {
    a = T(a);
    const b = a.space_collapsing || "none";
    return a.remove_ads_by_default ? {
      Ga: !0,
      rb: b,
      na: a.ablation_viewport_offset
    } : null
  }

  function Cl(a, b) {
    a = T(a);
    a.had_ads_ablation = !0;
    a.remove_ads_by_default = !0;
    a.space_collapsing = "slot";
    a.ablation_viewport_offset = b
  }

  function Dl(a) {
    T(H).allow_second_reactive_tag = a
  }

  function El() {
    const a = T(window);
    a.afg_slotcar_vars || (a.afg_slotcar_vars = {});
    return a.afg_slotcar_vars
  };

  function Fl(a) {
    return T(a) ? .head_tag_slot_vars ? .google_ad_host ? ? Gl(a)
  }

  function Gl(a) {
    return a.document.querySelector('meta[name="google-adsense-platform-account"]') ? .getAttribute("content") ? ? null
  };

  function Hl(a, b, c, d) {
    Il(new Jl(a, b, c, d))
  }

  function Il(a) {
    zd(yd(Gj({
      v: a.v,
      L: w(a.i, 6)
    }), b => {
      Kl(a, b, !0)
    }), () => {
      Ll(a)
    })
  }

  function Kl(a, b, c) {
    zd(yd(Ml(b), d => {
      Ol("ok");
      a.h(d)
    }), () => {
      Zk(a.v, b);
      c ? Ll(a) : a.h(null)
    })
  }

  function Ll(a) {
    zd(yd(Pl(a), a.h), () => {
      Ql(a)
    })
  }

  function Ml(a) {
    return (a = Yk(a)) ? td(a) : vd(Error("invlocst"))
  }

  function Pl(a) {
    if (Fl(a.v)) return vd(Error("invtag"));
    a: {
      var b = a.v;
      var c = a.j;a = a.i;
      if (rb(a, 13)) b = (b = y(y(Gb(a, $k, 13, tb), Pj, 2), Rj, 2)) && 0 < A(b, Xd, 1).length ? b : null;
      else {
        if (rb(a, 14)) {
          const d = ub(ll(a), 1),
            e = y(y(y(ll(a), $k, 2), Pj, 2), Rj, 2);
          if (1 === d.length && d[0] === c && e && 0 < A(e, Xd, 1).length && B(a, 17) === b.location.host) {
            b = e;
            break a
          }
        }
        b = null
      }
    }
    b ? (c = new de, a = A(b, Xd, 1), c = Eb(c, 1, a), b = A(b, ge, 2), b = Eb(c, 7, b), b = td(b)) : b = vd(Error("invtag"));
    return b
  }

  function Ql(a) {
    Kj({
      v: a.v,
      L: w(a.i, 6),
      ra: 50,
      Ia: b => {
        Rl(a, b)
      }
    })
  }

  function Rl(a, b) {
    zd(yd(b, c => {
      Kl(a, c, !1)
    }), c => {
      Ol(c.message);
      a.h(null)
    })
  }

  function Ol(a) {
    nj("abg::amalserr", {
      status: a,
      guarding: "true",
      timeout: 50,
      rate: .01
    }, .01)
  }
  class Jl {
    constructor(a, b, c, d) {
      this.v = a;
      this.i = b;
      this.j = c;
      this.h = d
    }
  };
  var Ul = (a, b, c, d) => {
    try {
      const e = Rk(a, A(c, ge, 7));
      if (e && Pk(e)) {
        r(e, 4) && (d = Kd(d, new Ld(null, {
          google_package: r(e, 4)
        })));
        const f = new cj(a, b, c, e, d);
        yi(1E3, () => {
          var g = new nd;
          (new Uj(a, f, g)).start();
          return g.i
        }, a).then(ma(Sl, a), ma(Tl, a))
      }
    } catch (e) {
      Tk(a, {
        atf: -1
      })
    }
  };
  const Sl = a => {
      Tk(a, {
        atf: 1
      })
    },
    Tl = (a, b) => {
      (a.google_ama_state = a.google_ama_state || {}).exception = b;
      Tk(a, {
        atf: 0
      })
    };

  function Vl(a, b) {
    if (!a) return !1;
    a = a.hash;
    if (!a || !a.indexOf) return !1;
    if (-1 != a.indexOf(b)) return !0;
    b = Wl(b);
    return "go" != b && -1 != a.indexOf(b) ? !0 : !1
  }

  function Wl(a) {
    let b = "";
    E(a.split("_"), c => {
      b += c.substr(0, 2)
    });
    return b
  };
  Ma || !n("Safari") || xa();
  class Xl {
    constructor() {
      this.promise = new Promise(a => {
        this.resolve = a
      })
    }
  };

  function Yl() {
    const {
      promise: a,
      resolve: b
    } = new Xl;
    return {
      promise: a,
      resolve: b
    }
  };

  function Zl(a = () => {}) {
    m.google_llp || (m.google_llp = {});
    const b = m.google_llp;
    let c = b[7];
    if (c) return c;
    c = Yl();
    b[7] = c;
    a();
    return c
  }

  function $l(a) {
    return Zl(() => {
      Cc(m.document, a)
    }).promise
  };
  var am = a => {
    if (m.google_apltlad || m !== m.top || !a.google_ad_client) return null;
    m.google_apltlad = !0;
    const b = {
        enable_page_level_ads: {
          pltais: !0
        },
        google_ad_client: a.google_ad_client
      },
      c = b.enable_page_level_ads;
    E(a, (d, e) => {
      mi[e] && "google_ad_client" !== e && (c[e] = d)
    });
    c.google_pgb_reactive = 7;
    L(Je) && (c.easpf = !0, c.easpi = L(Xe), L(Ve) && (c.easpa = !0));
    if ("google_ad_section" in a || "google_ad_region" in a) c.google_ad_section = a.google_ad_section || a.google_ad_region;
    return b
  };

  function bm(a) {
    return ea(a.enable_page_level_ads) && 7 === a.enable_page_level_ads.google_pgb_reactive
  };
  var em = (a, b) => {
    T(H).ama_ran_on_page || yi(1001, () => cm(new dm(a, b)), m)
  };

  function cm(a) {
    L(hf) ? Hl(a.h, a.j, a.i.google_ad_client || "", b => {
      var c = a.h,
        d = a.i;
      T(H).ama_ran_on_page || b && fm(c, d, b)
    }) : Kj({
      v: a.h,
      L: w(a.j, 6),
      ra: 50,
      Ia: b => gm(a, b)
    })
  }

  function gm(a, b) {
    zd(yd(b, c => {
      hm("ok");
      var d = a.h,
        e = a.i;
      if (!T(H).ama_ran_on_page) {
        var f = Yk(c);
        f ? fm(d, e, f) : Zk(d, c)
      }
    }), c => hm(c.message))
  }

  function hm(a) {
    nj("abg::amalserr", {
      status: a,
      guarding: !0,
      timeout: 50,
      rate: .01
    }, .01)
  }
  class dm {
    constructor(a, b) {
      this.h = m;
      this.i = a;
      this.j = b
    }
  }

  function fm(a, b, c) {
    if (Array.isArray(r(c, 24))) {
      var d = Ei(a);
      d.availableAbg = !0;
      d.ablationFromStorage = !!y(c, $d, 24) ? .l() ? .l()
    }
    if (bm(b) && (d = Rk(a, A(c, ge, 7)), !d || !vb(d, 8))) return;
    T(H).ama_ran_on_page = !0;
    y(c, ke, 15) ? .l() && (T(a).enable_overlap_observer = !0);
    var e = y(c, ie, 13);
    e && 1 === r(e, 1) ? (d = 0, (e = y(e, je, 6)) && r(e, 3) && (d = r(e, 3) || 0), Cl(a, d)) : y(c, $d, 24) ? .l() ? .l() && (Ei(a).ablatingThisPageview = !0, Cl(a, 1));
    $c(3, [c.toJSON()]);
    const f = b.google_ad_client || "";
    b = Uk(ea(b.enable_page_level_ads) ? b.enable_page_level_ads : {});
    const g = Kd(Od, new Ld(null, b));
    lj(782, () => {
      Ul(a, f, c, g)
    })
  };
  /* 
   Copyright The Closure Library Authors. 
   SPDX-License-Identifier: Apache-2.0 
  */
  function im() {
    var a = H.document;
    for (const b of [cd `https://fonts.googleapis.com`, cd `https://fonts.gstatic.com`]) {
      const c = a.createElement("LINK");
      c.crossOrigin = "";
      kc(c, b, "preconnect");
      a.head.appendChild(c)
    }
  };

  function jm(a, b) {
    return a instanceof HTMLScriptElement && b.test(a.src) ? 0 : 1
  }

  function km(a) {
    var b = H.document;
    if (b.currentScript) return jm(b.currentScript, a);
    for (const c of b.scripts)
      if (0 === jm(c, a)) return 0;
    return 1
  };

  function lm(a, b = 0) {
    b = 0 !== b ? `${"google_experiment_mod"}${b}` : "google_experiment_mod";
    a: {
      var c = -1;
      try {
        a && (c = parseInt(a.getItem(b), 10))
      } catch {
        c = null;
        break a
      }
      c = 0 <= c && 1E3 > c ? c : null
    }
    if (null === c) {
      c = Hc() ? null : Math.floor(1E3 * Ic());
      var d;
      if (d = null != c && a) a: {
        var e = String(c);
        try {
          if (a) {
            a.setItem(b, e);
            d = e;
            break a
          }
        } catch {}
        d = null
      }
      a = d ? c : null
    } else a = c;
    return a
  };

  function mm(a, b) {
    return {
      [ag]: {
        [55]: () => 0 === a,
        [23]: c => sl(H, Number(c)),
        [24]: c => vl(Number(c)),
        [61]: () => w(b, 6),
        [63]: () => w(b, 6) || ".google.ch" === B(b, 8)
      },
      [bg]: {
        [7]: c => {
          try {
            var d = window.localStorage
          } catch (e) {
            d = null
          }
          return lm(d, Number(c)) ? ? void 0
        }
      },
      [cg]: {
        [6]: () => B(b, 15)
      }
    }
  };
  var nm = (a = m) => a.ggeac || (a.ggeac = {});

  function om(a, b = window.document) {
    Uc(a, b)
  }

  function pm(a, b = document) {
    return !!b.featurePolicy ? .features().includes(a)
  }

  function qm(a, b = document) {
    return !!b.featurePolicy ? .allowedFeatures().includes(a)
  };
  const rm = (a, b) => {
    try {
      const d = a.split(".");
      a = m;
      let e = 0,
        f;
      for (; null != a && e < d.length; e++) f = a, a = a[d[e]], "function" === typeof a && (a = f[d[e]]());
      var c = a;
      if (typeof c === b) return c
    } catch (d) {}
  };
  class sm {
    constructor() {
      this[ag] = {
        [8]: a => {
          try {
            return null != ba(a)
          } catch (b) {}
        },
        [9]: a => {
          try {
            var b = ba(a)
          } catch (c) {
            return
          }
          if (a = "function" === typeof b) b = b && b.toString && b.toString(), a = "string" === typeof b && -1 != b.indexOf("[native code]");
          return a
        },
        [10]: () => window == window.top,
        [6]: a => Ja(K(Gh).h(), parseInt(a, 10)),
        [27]: a => {
          a = rm(a, "boolean");
          return void 0 !== a ? a : void 0
        },
        [60]: a => {
          try {
            return !!m.document.querySelector(a)
          } catch (b) {}
        },
        [69]: a => pm(a, m.document),
        [70]: a => qm(a, m.document)
      };
      this[bg] = {
        [3]: () => Pc(),
        [6]: a => {
          a =
            rm(a, "number");
          return void 0 !== a ? a : void 0
        },
        [11]: (a = "") => {
          a = Tc(a, m);
          return null == a ? void 0 : a % 1E3
        }
      };
      this[cg] = {
        [2]: () => window.location.href,
        [3]: () => {
          try {
            return window.top.location.hash
          } catch (a) {
            return ""
          }
        },
        [4]: a => {
          a = rm(a, "string");
          return void 0 !== a ? a : void 0
        },
        [10]: () => {
          try {
            const a = m.document;
            return a.visibilityState || a.webkitVisibilityState || a.mozVisibilityState || ""
          } catch (a) {
            return ""
          }
        },
        [11]: () => {
          try {
            return ba("google_tag_data") ? .uach ? .fullVersionList ? .find(a => "Google Chrome" === a.brand) ? .version ? ? ""
          } catch (a) {
            return ""
          }
        }
      }
    }
  };
  const tm = [12, 13, 20];

  function um(a, b, c, d) {
    const e = K(Ug).h;
    if (!hg(y(b, Xf, 3), e)) return null;
    var f = A(b, dl, 2),
      g = u(b, 6, 0);
    if (g) {
      zb(d, 1, Hg, g);
      f = e[bg];
      switch (c) {
        case 2:
          var h = f[8];
          break;
        case 1:
          h = f[7]
      }
      c = void 0;
      if (h) try {
        c = h(g), yb(d, 3, c)
      } catch (k) {}
      return (b = vm(b, c)) ? wm(a, [b], 1) : null
    }
    if (g = u(b, 10, 0)) {
      zb(d, 2, Hg, g);
      h = null;
      switch (c) {
        case 1:
          h = e[bg][9];
          break;
        case 2:
          h = e[bg][10];
          break;
        default:
          return null
      }
      c = h ? h(String(g)) : void 0;
      if (void 0 === c && 1 === u(b, 11, 0)) return null;
      void 0 !== c && yb(d, 3, c);
      return (b = vm(b, c)) ? wm(a, [b], 1) : null
    }
    d = e ? Ea(f, k => hg(y(k,
      Xf, 3), e)) : f;
    if (!d.length) return null;
    c = d.length * u(b, 1, 0);
    return (b = u(b, 4, 0)) ? xm(a, b, c, d) : wm(a, d, c / 1E3)
  }

  function ym(a, b, c) {
    a.i[c] || (a.i[c] = []);
    a = a.i[c];
    Ja(a, b) || a.push(b)
  }

  function zm(a, b, c) {
    const d = [],
      e = Am(a.m, b);
    var f;
    if (f = 9 !== b) a.A[b] ? f = !0 : (a.A[b] = !0, f = !1);
    if (f) return a.h ? .j(b, c, d, [], 4), d;
    if (!e.length) return a.h ? .j(b, c, d, [], 3), d;
    const g = Ja(tm, b),
      h = [];
    Da(e, k => {
      var l = new Gg;
      if (k = um(a, k, c, l)) 0 !== Ab(l, Hg) && h.push(l), l = k.getId(), d.push(l), ym(a, l, g ? 4 : c), (k = A(k, mg, 2)) && (g ? hh(k, jh(), a.h, l) : hh(k, [c], a.h, l))
    });
    a.h ? .j(b, c, d, h, 1);
    return d
  }

  function Bm(a, b) {
    a.m.push(...Ea(Fa(b, c => new jl(c)), c => !Ja(tm, c.O())))
  }

  function wm(a, b, c) {
    const d = a.j,
      e = Ha(b, f => !!d[f.getId()]);
    return e ? e : a.G ? null : Fc(b, c)
  }

  function xm(a, b, c, d) {
    const e = null != a.l[b] ? a.l[b] : 1E3;
    if (0 >= e) return null;
    d = wm(a, d, c / e);
    a.l[b] = d ? 0 : e - c;
    return d
  }

  function Cm(a, b) {
    P(lh, c => {
      a.j[c] = !0
    }, b);
    P(oh, (c, d) => zm(a, c, d), b);
    P(ph, c => (a.i[c] || []).concat(a.i[4]), b);
    P(yh, c => void Bm(a, c), b);
    P(mh, (c, d) => void ym(a, c, d), b)
  }
  class Dm {
    init(a, b, c, {
      bb: d = !1,
      Rb: e = {},
      Vb: f = []
    } = {}) {
      this.m = a;
      this.A = {};
      this.G = d;
      this.l = e;
      this.i = {
        [b]: [],
        [4]: []
      };
      this.j = {};
      (a = Kh()) && Da(a.split(",") || [], g => {
        (g = parseInt(g, 10)) && (this.j[g] = !0)
      });
      Da(f, g => {
        this.j[g] = !0
      });
      this.h = c;
      return this
    }
  }
  const Am = (a, b) => (a = Ha(a, c => c.O() == b)) && A(a, fl, 2) || [],
    vm = (a, b) => {
      var c = A(a, dl, 2),
        d = c.length,
        e = u(a, 8, 0);
      a = d * u(a, 1, 0) - 1;
      b = void 0 !== b ? b : Math.floor(1E3 * Ic());
      d = (b - e) % d;
      if (b < e || b - e - d >= a) return null;
      c = c[d];
      e = K(Ug).h;
      return !c || e && !hg(y(c, Xf, 3), e) ? null : c
    };
  class Em {
    constructor() {
      this.h = () => {}
    }
  }
  var Fm = a => {
    K(Em).h(a)
  };
  var Hm = (a, b, c, d = nm(), e = 0, f = new Tg(y(a, kl, 5) ? .l() ? ? 0, y(a, kl, 5) ? .m() ? ? 0, y(a, kl, 5) ? .A() ? ? !1)) => {
      d.hasOwnProperty("init-done") ? (Bh(yh, d)(Fa(A(a, jl, 2), g => g.toJSON())), Bh(zh, d)(Fa(A(a, mg, 1), g => g.toJSON()), e), b && Bh(Ah, d)(b), Gm(e, d)) : (Cm(K(Dm).init(A(a, jl, 2), e, f, c), d), Ch(d), Dh(d), Eh(d), Gm(e, d), hh(A(a, mg, 1), [e], f, void 0, !0), Vg = Vg || !(!c || !c.gb), Fm(K(sm)), b && Fm(b))
    },
    Gm = (a, b = nm()) => {
      Fh(K(Gh), b, a);
      Im(b, a);
      K(Em).h = Bh(Ah, b);
      K(uf).m()
    },
    Im = (a, b) => {
      const c = K(uf);
      c.j = (d, e) => Bh(rh, a, () => !1)(d, e, b);
      c.l = (d, e) => Bh(sh, a,
        () => 0)(d, e, b);
      c.h = (d, e) => Bh(th, a, () => "")(d, e, b);
      c.i = (d, e) => Bh(uh, a, () => [])(d, e, b);
      c.m = () => {
        Bh(nh, a)(b)
      }
    };
  var Jm = (a, b, c) => {
    var d = T(a);
    if (d.plle) Gm(1, nm(a));
    else {
      d.plle = !0;
      d = y(b, hl, 12);
      var e = w(b, 9);
      Hm(d, mm(c, b), {
        bb: e && !!a.google_disable_experiments,
        gb: e
      }, nm(a), 1);
      if (c = B(b, 15)) c = Number(c), K(Gh).l(c);
      for (const f of ub(b, 19)) b = f, K(Gh).j(b);
      K(Gh).i(12);
      K(Gh).i(10);
      a = Bc(a) || a;
      Vl(a.location, "google_mc_lab") && K(Gh).j(44738307)
    }
  };

  function Km(a, b, c) {
    a = a.style;
    a.border = "none";
    a.height = `${c}px`;
    a.width = `${b}px`;
    a.margin = 0;
    a.padding = 0;
    a.position = "relative";
    a.visibility = "visible";
    a.backgroundColor = "transparent"
  };
  var Lm = {
      "120x90": !0,
      "160x90": !0,
      "180x90": !0,
      "200x90": !0,
      "468x15": !0,
      "728x15": !0
    },
    Mm = (a, b) => {
      if (15 == b) {
        if (728 <= a) return 728;
        if (468 <= a) return 468
      } else if (90 == b) {
        if (200 <= a) return 200;
        if (180 <= a) return 180;
        if (160 <= a) return 160;
        if (120 <= a) return 120
      }
      return null
    };

  function Nm(a) {
    return b => !!(b.ga & a)
  }
  class U extends ei {
    constructor(a, b, c, d = !1) {
      super(a, b);
      this.ga = c;
      this.hb = d
    }
    ma() {
      return this.ga
    }
    i(a, b, c) {
      b.google_ad_resize || (c.style.height = this.height() + "px", b.rpe = !0)
    }
  };
  const Om = {
      image_stacked: 1 / 1.91,
      image_sidebyside: 1 / 3.82,
      mobile_banner_image_sidebyside: 1 / 3.82,
      pub_control_image_stacked: 1 / 1.91,
      pub_control_image_sidebyside: 1 / 3.82,
      pub_control_image_card_stacked: 1 / 1.91,
      pub_control_image_card_sidebyside: 1 / 3.74,
      pub_control_text: 0,
      pub_control_text_card: 0
    },
    Pm = {
      image_stacked: 80,
      image_sidebyside: 0,
      mobile_banner_image_sidebyside: 0,
      pub_control_image_stacked: 80,
      pub_control_image_sidebyside: 0,
      pub_control_image_card_stacked: 85,
      pub_control_image_card_sidebyside: 0,
      pub_control_text: 80,
      pub_control_text_card: 80
    },
    Qm = {
      pub_control_image_stacked: 100,
      pub_control_image_sidebyside: 200,
      pub_control_image_card_stacked: 150,
      pub_control_image_card_sidebyside: 250,
      pub_control_text: 100,
      pub_control_text_card: 150
    };

  function Rm(a) {
    var b = 0;
    a.M && b++;
    a.I && b++;
    a.J && b++;
    if (3 > b) return {
      K: "Tags data-matched-content-ui-type, data-matched-content-columns-num and data-matched-content-rows-num should be set together."
    };
    b = a.M.split(",");
    const c = a.J.split(",");
    a = a.I.split(",");
    if (b.length !== c.length || b.length !== a.length) return {
      K: 'Lengths of parameters data-matched-content-ui-type, data-matched-content-columns-num and data-matched-content-rows-num must match. Example: \n data-matched-content-rows-num="4,2"\ndata-matched-content-columns-num="1,6"\ndata-matched-content-ui-type="image_stacked,image_card_sidebyside"'
    };
    if (2 < b.length) return {
      K: "The parameter length of attribute data-matched-content-ui-type, data-matched-content-columns-num and data-matched-content-rows-num is too long. At most 2 parameters for each attribute are needed: one for mobile and one for desktop, while " + `you are providing ${b.length} parameters. Example: ${'\n data-matched-content-rows-num="4,2"\ndata-matched-content-columns-num="1,6"\ndata-matched-content-ui-type="image_stacked,image_card_sidebyside"'}.`
    };
    const d = [],
      e = [];
    for (let g = 0; g <
      b.length; g++) {
      var f = Number(c[g]);
      if (Number.isNaN(f) || 0 === f) return {
        K: `Wrong value '${c[g]}' for ${"data-matched-content-rows-num"}.`
      };
      d.push(f);
      f = Number(a[g]);
      if (Number.isNaN(f) || 0 === f) return {
        K: `Wrong value '${a[g]}' for ${"data-matched-content-columns-num"}.`
      };
      e.push(f)
    }
    return {
      J: d,
      I: e,
      Na: b
    }
  }

  function Sm(a) {
    return 1200 <= a ? {
      width: 1200,
      height: 600
    } : 850 <= a ? {
      width: a,
      height: Math.floor(.5 * a)
    } : 550 <= a ? {
      width: a,
      height: Math.floor(.6 * a)
    } : 468 <= a ? {
      width: a,
      height: Math.floor(.7 * a)
    } : {
      width: a,
      height: Math.floor(3.44 * a)
    }
  };
  const Tm = La("script");

  function Um(a, b, c) {
    null != a.ga && (c.google_responsive_formats = a.ga);
    null != a.X && (c.google_safe_for_responsive_override = a.X);
    null != a.i && (!0 === a.i ? c.google_full_width_responsive_allowed = !0 : (c.google_full_width_responsive_allowed = !1, c.gfwrnwer = a.i));
    null != a.j && !0 !== a.j && (c.gfwrnher = a.j);
    var d = a.m || c.google_ad_width;
    null != d && (c.google_resizing_width = d);
    d = a.l || c.google_ad_height;
    null != d && (c.google_resizing_height = d);
    d = a.size().h(b);
    const e = a.size().height();
    if (!c.google_ad_resize) {
      c.google_ad_width = d;
      c.google_ad_height =
        e;
      var f = a.size();
      b = f.h(b) + "x" + f.height();
      c.google_ad_format = b;
      c.google_responsive_auto_format = a.A;
      null != a.h && (c.armr = a.h);
      c.google_ad_resizable = !0;
      c.google_override_format = 1;
      c.google_loader_features_used = 128;
      !0 === a.i && (c.gfwrnh = a.size().height() + "px")
    }
    null != a.H && (c.gfwroml = a.H);
    null != a.V && (c.gfwromr = a.V);
    null != a.l && (c.gfwroh = a.l);
    null != a.m && (c.gfwrow = a.m);
    null != a.W && (c.gfwroz = a.W);
    null != a.G && (c.gml = a.G);
    null != a.D && (c.gmr = a.D);
    null != a.Y && (c.gzi = a.Y);
    b = Bc(window) || window;
    Vl(b.location, "google_responsive_dummy_ad") &&
      (Ja([1, 2, 3, 4, 5, 6, 7, 8], a.A) || 1 === a.h) && 2 !== a.h && (a = JSON.stringify({
        googMsgType: "adpnt",
        key_value: [{
          key: "qid",
          value: "DUMMY_AD"
        }]
      }), c.dash = `<${Tm}>window.top.postMessage('${a}', '*'); 
          </${Tm}> 
          <div id="dummyAd" style="width:${d}px;height:${e}px; 
            background:#ddd;border:3px solid #f00;box-sizing:border-box; 
            color:#000;"> 
            <p>Requested size:${d}x${e}</p> 
            <p>Rendered size:${d}x${e}</p> 
          </div>`)
  }
  class Vm {
    constructor(a, b, c = null, d = null, e = null, f = null, g = null, h = null, k = null, l = null, q = null, v = null) {
      this.A = a;
      this.ba = b;
      this.ga = c;
      this.h = d;
      this.X = e;
      this.i = f;
      this.j = g;
      this.H = h;
      this.V = k;
      this.l = l;
      this.m = q;
      this.W = v;
      this.Y = this.D = this.G = null
    }
    size() {
      return this.ba
    }
  };
  const Wm = ["google_content_recommendation_ui_type", "google_content_recommendation_columns_num", "google_content_recommendation_rows_num"];
  var Xm = class extends ei {
      h(a) {
        return Math.min(1200, Math.max(this.minWidth(), Math.round(a)))
      }
    },
    $m = (a, b) => {
      Ym(a, b);
      if ("pedestal" == b.google_content_recommendation_ui_type) return new Vm(9, new Xm(a, Math.floor(a * b.google_phwr)));
      var c = vc();
      468 > a ? c ? (c = a - 8 - 8, c = Math.floor(c / 1.91 + 70) + Math.floor(11 * (c * Om.mobile_banner_image_sidebyside + Pm.mobile_banner_image_sidebyside) + 96), a = {
        aa: a,
        Z: c,
        I: 1,
        J: 12,
        M: "mobile_banner_image_sidebyside"
      }) : (a = Sm(a), a = {
        aa: a.width,
        Z: a.height,
        I: 1,
        J: 13,
        M: "image_sidebyside"
      }) : (a = Sm(a), a = {
        aa: a.width,
        Z: a.height,
        I: 4,
        J: 2,
        M: "image_stacked"
      });
      Zm(b, a);
      return new Vm(9, new Xm(a.aa, a.Z))
    },
    an = (a, b) => {
      Ym(a, b);
      var c = Rm({
        J: b.google_content_recommendation_rows_num,
        I: b.google_content_recommendation_columns_num,
        M: b.google_content_recommendation_ui_type
      });
      if (c.K) a = {
        aa: 0,
        Z: 0,
        I: 0,
        J: 0,
        M: "image_stacked",
        K: c.K
      };
      else {
        var d = 2 === c.Na.length && 468 <= a ? 1 : 0;
        var e = c.Na[d];
        e = 0 === e.indexOf("pub_control_") ? e : "pub_control_" + e;
        var f = Qm[e];
        let g = c.I[d];
        for (; a / g < f && 1 < g;) g--;
        f = g;
        d = c.J[d];
        c = Math.floor(((a - 8 * f - 8) / f * Om[e] + Pm[e]) * d + 8 *
          d + 8);
        a = 1500 < a ? {
          width: 0,
          height: 0,
          pb: "Calculated slot width is too large: " + a
        } : 1500 < c ? {
          width: 0,
          height: 0,
          pb: "Calculated slot height is too large: " + c
        } : {
          width: a,
          height: c
        };
        a = {
          aa: a.width,
          Z: a.height,
          I: f,
          J: d,
          M: e
        }
      }
      if (a.K) throw new Q(a.K);
      Zm(b, a);
      return new Vm(9, new Xm(a.aa, a.Z))
    };

  function Ym(a, b) {
    if (0 >= a) throw new Q("Invalid responsive width from Matched Content slot " + b.google_ad_slot + ": " + a + ". Please ensure to put this Matched Content slot into a non-zero width div container.");
  }

  function Zm(a, b) {
    a.google_content_recommendation_ui_type = b.M;
    a.google_content_recommendation_columns_num = b.I;
    a.google_content_recommendation_rows_num = b.J
  };
  class bn extends ei {
    h() {
      return this.minWidth()
    }
    i(a, b, c) {
      di(a, c);
      b.google_ad_resize || (c.style.height = this.height() + "px", b.rpe = !0)
    }
  };
  const cn = {
    "image-top": a => 600 >= a ? 284 + .414 * (a - 250) : 429,
    "image-middle": a => 500 >= a ? 196 - .13 * (a - 250) : 164 + .2 * (a - 500),
    "image-side": a => 500 >= a ? 205 - .28 * (a - 250) : 134 + .21 * (a - 500),
    "text-only": a => 500 >= a ? 187 - .228 * (a - 250) : 130,
    "in-article": a => 420 >= a ? a / 1.2 : 460 >= a ? a / 1.91 + 130 : 800 >= a ? a / 4 : 200
  };
  var dn = class extends ei {
      h() {
        return Math.min(1200, this.minWidth())
      }
    },
    en = (a, b, c, d, e) => {
      var f = e.google_ad_layout || "image-top";
      if ("in-article" == f) {
        var g = a;
        if ("false" == e.google_full_width_responsive) a = g;
        else if (a = Zh(b, c, g, .2, e), !0 !== a) e.gfwrnwer = a, a = g;
        else if (a = N(b).clientWidth)
          if (e.google_full_width_responsive_allowed = !0, c.parentElement) {
            b: {
              g = c;
              for (let h = 0; 100 > h && g.parentElement; ++h) {
                const k = g.parentElement.childNodes;
                for (let l = 0; l < k.length; ++l) {
                  const q = k[l];
                  if (q != g && bi(b, q)) break b
                }
                g = g.parentElement;
                g.style.width = "100%";
                g.style.height = "auto"
              }
            }
            di(b, c)
          }
        else a = g;
        else a = g
      }
      if (250 > a) throw new Q("Fluid responsive ads must be at least 250px wide: availableWidth=" + a);
      a = Math.min(1200, Math.floor(a));
      if (d && "in-article" != f) {
        f = Math.ceil(d);
        if (50 > f) throw new Q("Fluid responsive ads must be at least 50px tall: height=" + f);
        return new Vm(11, new ei(a, f))
      }
      if ("in-article" != f && (d = e.google_ad_layout_key)) {
        f = "" + d;
        c = Math.pow(10, 3);
        if (e = (d = f.match(/([+-][0-9a-z]+)/g)) && d.length)
          for (b = [], g = 0; g < e; g++) b.push(parseInt(d[g],
            36) / c);
        else b = null;
        if (!b) throw new Q("Invalid data-ad-layout-key value: " + f);
        f = (a + -725) / 1E3;
        c = 0;
        d = 1;
        e = b.length;
        for (g = 0; g < e; g++) c += b[g] * d, d *= f;
        f = Math.ceil(1E3 * c - -725 + 10);
        if (isNaN(f)) throw new Q("Invalid height: height=" + f);
        if (50 > f) throw new Q("Fluid responsive ads must be at least 50px tall: height=" + f);
        if (1200 < f) throw new Q("Fluid responsive ads must be at most 1200px tall: height=" + f);
        return new Vm(11, new ei(a, f))
      }
      d = cn[f];
      if (!d) throw new Q("Invalid data-ad-layout value: " + f);
      c = hi(c, b);
      b = N(b).clientWidth;
      b = "in-article" !== f || c || a !== b ? Math.ceil(d(a)) : Math.ceil(1.25 * d(a));
      return new Vm(11, "in-article" == f ? new dn(a, b) : new ei(a, b))
    };
  var fn = a => b => {
      for (let c = a.length - 1; 0 <= c; --c)
        if (!a[c](b)) return !1;
      return !0
    },
    hn = (a, b) => {
      var c = gn.slice(0);
      const d = c.length;
      let e = null;
      for (let f = 0; f < d; ++f) {
        const g = c[f];
        if (a(g)) {
          if (!b || b(g)) return g;
          null === e && (e = g)
        }
      }
      return e
    };
  var W = [new U(970, 90, 2), new U(728, 90, 2), new U(468, 60, 2), new U(336, 280, 1), new U(320, 100, 2), new U(320, 50, 2), new U(300, 600, 4), new U(300, 250, 1), new U(250, 250, 1), new U(234, 60, 2), new U(200, 200, 1), new U(180, 150, 1), new U(160, 600, 4), new U(125, 125, 1), new U(120, 600, 4), new U(120, 240, 4), new U(120, 120, 1, !0)],
    gn = [W[6], W[12], W[3], W[0], W[7], W[14], W[1], W[8], W[10], W[4], W[15], W[2], W[11], W[5], W[13], W[9], W[16]];
  var kn = (a, b, c, d, e) => {
      "false" == e.google_full_width_responsive ? c = {
        B: a,
        C: 1
      } : "autorelaxed" == b && e.google_full_width_responsive || jn(b) || e.google_ad_resize ? (b = $h(a, c, d, e), c = !0 !== b ? {
        B: a,
        C: b
      } : {
        B: N(c).clientWidth || a,
        C: !0
      }) : c = {
        B: a,
        C: 2
      };
      const {
        B: f,
        C: g
      } = c;
      return !0 !== g ? {
        B: a,
        C: g
      } : d.parentElement ? {
        B: f,
        C: g
      } : {
        B: a,
        C: g
      }
    },
    nn = (a, b, c, d, e) => {
      const {
        B: f,
        C: g
      } = lj(247, () => kn(a, b, c, d, e));
      var h = !0 === g;
      const k = G(d.style.width),
        l = G(d.style.height),
        {
          U: q,
          R: v,
          ma: C,
          Ma: z
        } = ln(f, b, c, d, e, h);
      h = mn(b, C);
      var x;
      const F = (x = fi(d, c, "marginLeft",
          G)) ? x + "px" : "",
        ya = (x = fi(d, c, "marginRight", G)) ? x + "px" : "";
      x = fi(d, c, "zIndex") || "";
      return new Vm(h, q, C, null, z, g, v, F, ya, l, k, x)
    },
    jn = a => "auto" == a || /^((^|,) *(horizontal|vertical|rectangle) *)+$/.test(a),
    ln = (a, b, c, d, e, f) => {
      b = "auto" == b ? .25 >= a / Math.min(1200, N(c).clientWidth) ? 4 : 3 : Yh(b);
      let g;
      var h = !1;
      let k = !1;
      if (488 > N(c).clientWidth) {
        g = Th(d, c);
        var l = hi(d, c);
        h = !l && g;
        k = l && g
      }
      l = [gi(a), Nm(b)];
      l.push(ji(488 > N(c).clientWidth, c, d, k));
      null != e.google_max_responsive_height && l.push(ki(e.google_max_responsive_height));
      const q = [x => !x.hb];
      if (h || k) h = li(c, d), q.push(ki(h));
      let v = hn(fn(l), fn(q));
      if (!v) throw new Q("No slot size for availableWidth=" + a);
      const {
        U: C,
        R: z
      } = lj(248, () => {
        var x;
        a: if (f) {
          if (e.gfwrnh && (x = G(e.gfwrnh))) {
            x = {
              U: new bn(a, x),
              R: !0
            };
            break a
          }
          x = a / 1.2;
          var F = Math;
          var ya = F.min;
          if (e.google_resizing_allowed || "true" == e.google_full_width_responsive) var V = Infinity;
          else {
            V = d;
            let va = Infinity;
            do {
              var za = fi(V, c, "height", G);
              za && (va = Math.min(va, za));
              (za = fi(V, c, "maxHeight", G)) && (va = Math.min(va, za))
            } while ((V = V.parentElement) && "HTML" !=
              V.tagName);
            V = va
          }
          F = ya.call(F, x, V);
          if (F < .5 * x || 100 > F) F = x;
          L(ef) && !hi(d, c) && (F = Math.max(F, .5 * N(c).clientHeight));
          x = {
            U: new bn(a, Math.floor(F)),
            R: F < x ? 102 : !0
          }
        } else x = {
          U: v,
          R: 100
        };
        return x
      });
      return "in-article" === e.google_ad_layout && on(c) ? {
        U: pn(a, c, d, C, e),
        R: !1,
        ma: b,
        Ma: g
      } : {
        U: C,
        R: z,
        ma: b,
        Ma: g
      }
    };
  const mn = (a, b) => {
      if ("auto" == a) return 1;
      switch (b) {
        case 2:
          return 2;
        case 1:
          return 3;
        case 4:
          return 4;
        case 3:
          return 5;
        case 6:
          return 6;
        case 5:
          return 7;
        case 7:
          return 8
      }
      throw Error("bad mask");
    },
    pn = (a, b, c, d, e) => {
      const f = e.google_ad_height || fi(c, b, "height", G);
      b = en(a, b, c, f, e).size();
      return b.minWidth() * b.height() > a * d.height() ? new U(b.minWidth(), b.height(), 1) : d
    },
    on = a => L(df) || a.location && "#hffwroe2etoq" == a.location.hash;
  var qn = (a, b, c, d, e) => {
    var f;
    (f = N(b).clientWidth) ? 488 > N(b).clientWidth ? b.innerHeight >= b.innerWidth ? (e.google_full_width_responsive_allowed = !0, di(b, c), f = {
      B: f,
      C: !0
    }) : f = {
      B: a,
      C: 5
    } : f = {
      B: a,
      C: 4
    }: f = {
      B: a,
      C: 10
    };
    const {
      B: g,
      C: h
    } = f;
    if (!0 !== h || a == g) return new Vm(12, new ei(a, d), null, null, !0, h, 100);
    const {
      U: k,
      R: l,
      ma: q
    } = ln(g, "auto", b, c, e, !0);
    return new Vm(1, k, q, 2, !0, h, l)
  };
  var sn = (a, b) => {
      var c = b.google_ad_format;
      if ("autorelaxed" == c) {
        a: {
          if ("pedestal" != b.google_content_recommendation_ui_type)
            for (const d of Wm)
              if (null != b[d]) {
                a = !0;
                break a
              } a = !1
        }
        return a ? 9 : 5
      }
      if (jn(c)) return 1;
      if ("link" === c) return 4;
      if ("fluid" == c) {
        if (c = "in-article" === b.google_ad_layout) c = L(df) || a.location && ("#hffwroe2etop" == a.location.hash || "#hffwroe2etoq" == a.location.hash);
        return c ? (rn(b), 1) : 8
      }
      if (27 === b.google_reactive_ad_format) return rn(b), 1
    },
    un = (a, b, c, d, e = !1) => {
      e = b.offsetWidth || (c.google_ad_resize || e) &&
        fi(b, d, "width", G) || c.google_ad_width || 0;
      4 === a && (c.google_ad_format = "auto", a = 1);
      var f = (f = tn(a, e, b, c, d)) ? f : nn(e, c.google_ad_format, d, b, c);
      f.size().i(d, c, b);
      Um(f, e, c);
      1 != a && (a = f.size().height(), b.style.height = a + "px")
    };
  const tn = (a, b, c, d, e) => {
      const f = d.google_ad_height || fi(c, e, "height", G);
      switch (a) {
        case 5:
          const {
            B: g, C: h
          } = lj(247, () => kn(b, d.google_ad_format, e, c, d));
          !0 === h && b != g && di(e, c);
          !0 === h ? d.google_full_width_responsive_allowed = !0 : (d.google_full_width_responsive_allowed = !1, d.gfwrnwer = h);
          return $m(g, d);
        case 9:
          return an(b, d);
        case 8:
          return en(b, e, c, f, d);
        case 10:
          return qn(b, e, c, f, d)
      }
    },
    rn = a => {
      a.google_ad_format = "auto";
      a.armr = 3
    };

  function vn(a, b) {
    var c = Bc(b);
    if (c) {
      c = N(c).clientWidth;
      const d = Ec(a, b) || {},
        e = d.direction;
      if ("0px" === d.width && "none" !== d.cssFloat) return -1;
      if ("ltr" === e && c) return Math.floor(Math.min(1200, c - a.getBoundingClientRect().left));
      if ("rtl" === e && c) return a = b.document.body.getBoundingClientRect().right - a.getBoundingClientRect().right, Math.floor(Math.min(1200, c - a - Math.floor((c - b.document.body.clientWidth) / 2)))
    }
    return -1
  };

  function wn(a) {
    R.Qa(b => {
      b.shv = String(a);
      b.mjsv = "m202207130101";
      const c = K(Gh).h(),
        d = T(m);
      d.eids || (d.eids = []);
      b.eid = c.concat(d.eids).join(",")
    })
  }

  function xn(a) {
    wn(B(a, 2));
    a = w(a, 6);
    Tf(ol, Vf);
    ol = a
  };

  function yn({
    ab: a,
    lb: b
  }) {
    return a || ("dev" === b ? "dev" : "")
  };
  var zn = {
      google_ad_modifications: !0,
      google_analytics_domain_name: !0,
      google_analytics_uacct: !0,
      google_pause_ad_requests: !0,
      google_user_agent_client_hint: !0
    },
    An = a => (a = a.innerText || a.innerHTML) && (a = a.replace(/^\s+/, "").split(/\r?\n/, 1)[0].match(/^\x3c!--+(.*?)(?:--+>)?\s*$/)) && RegExp("google_ad_client").test(a[1]) ? a[1] : null,
    Bn = a => {
      if (a = a.innerText || a.innerHTML)
        if (a = a.replace(/^\s+|\s+$/g, "").replace(/\s*(\r?\n)+\s*/g, ";"), (a = a.match(/^\x3c!--+(.*?)(?:--+>)?$/) || a.match(/^\/*\s*<!\[CDATA\[(.*?)(?:\/*\s*\]\]>)?$/i)) &&
          RegExp("google_ad_client").test(a[1])) return a[1];
      return null
    },
    Cn = a => {
      switch (a) {
        case "true":
          return !0;
        case "false":
          return !1;
        case "null":
          return null;
        case "undefined":
          break;
        default:
          try {
            const b = a.match(/^(?:'(.*)'|"(.*)")$/);
            if (b) return b[1] || b[2] || "";
            if (/^[-+]?\d*(\.\d+)?$/.test(a)) {
              const c = parseFloat(a);
              return c === c ? c : void 0
            }
          } catch (b) {}
      }
    };
  const Dn = new WeakMap;

  function En() {
    var a = Fn,
      b = Gn;
    const c = fa(a),
      d = ([, ...f]) => b(c, f),
      e = ([f, ...g]) => a.apply(f, g);
    return function (...f) {
      var g = this || m,
        h = Dn.get(g);
      h || (h = {}, Dn.set(g, h));
      g = h;
      f = [this, ...f];
      h = d ? d(f) : f;
      return Object.prototype.hasOwnProperty.call(g, h) ? g[h] : g[h] = e(f)
    }
  }

  function Gn(a, b) {
    a = [a];
    for (let c = b.length - 1; 0 <= c; --c) a.push(typeof b[c], b[c]);
    return a.join("\v")
  };

  function Hn(a) {
    return L(cf) ? En()(a) : Fn(a)
  }

  function Fn(a) {
    if (a.google_ad_client) var b = String(a.google_ad_client);
    else {
      if (null == (b = T(a).head_tag_slot_vars ? .google_ad_client ? ? a.document.querySelector(".adsbygoogle[data-ad-client]") ? .getAttribute("data-ad-client"))) {
        b: {
          b = a.document.getElementsByTagName("script");a = a.navigator && a.navigator.userAgent || "";a = RegExp("appbankapppuzdradb|daumapps|fban|fbios|fbav|fb_iab|gsa/|messengerforios|naver|niftyappmobile|nonavigation|pinterest|twitter|ucbrowser|yjnewsapp|youtube", "i").test(a) || /i(phone|pad|pod)/i.test(a) &&
          /applewebkit/i.test(a) && !/version|safari/i.test(a) && !gd() ? An : Bn;
          for (var c = b.length - 1; 0 <= c; c--) {
            var d = b[c];
            if (!d.google_parsed_script_for_pub_code && (d.google_parsed_script_for_pub_code = !0, d = a(d))) {
              b = d;
              break b
            }
          }
          b = null
        }
        if (b) {
          a = /(google_\w+) *= *(['"]?[\w.-]+['"]?) *(?:;|$)/gm;
          for (c = {}; d = a.exec(b);) c[d[1]] = Cn(d[2]);
          b = c;
          b = b.google_ad_client ? b.google_ad_client : ""
        } else b = ""
      }
      b = b ? ? ""
    }
    return b
  };

  function In(a) {
    var b = R;
    try {
      return Tf(a, Uf), new nl(JSON.parse(a))
    } catch (c) {
      b.F(838, c instanceof Error ? c : Error(String(c)), void 0, d => {
        d.jspb = String(a)
      })
    }
    return new nl
  };

  function Jn(a, b) {
    return null == b ? `&${a}=null` : `&${a}=${Math.floor(b)}`
  }

  function Kn(a, b) {
    return `&${a}=${b.toFixed(3)}`
  }

  function Ln() {
    const a = new Set,
      b = Wi();
    try {
      if (!b) return a;
      const c = b.pubads();
      for (const d of c.getSlots()) a.add(d.getSlotId().getDomId())
    } catch (c) {}
    return a
  }

  function Mn(a) {
    a = a.id;
    return null != a && (Ln().has(a) || a.startsWith("google_ads_iframe_") || a.startsWith("aswift"))
  }

  function Nn(a, b, c) {
    if (!a.sources) return !1;
    switch (On(a)) {
      case 2:
        const d = Pn(a);
        if (d) return c.some(f => Qn(d, f));
      case 1:
        const e = Rn(a);
        if (e) return b.some(f => Qn(e, f))
    }
    return !1
  }

  function On(a) {
    if (!a.sources) return 0;
    a = a.sources.filter(b => b.previousRect && b.currentRect);
    if (1 <= a.length) {
      a = a[0];
      if (a.previousRect.top < a.currentRect.top) return 2;
      if (a.previousRect.top > a.currentRect.top) return 1
    }
    return 0
  }

  function Rn(a) {
    return Sn(a, b => b.currentRect)
  }

  function Pn(a) {
    return Sn(a, b => b.previousRect)
  }

  function Sn(a, b) {
    return a.sources.reduce((c, d) => {
      d = b(d);
      return c ? d && 0 !== d.width * d.height ? d.top < c.top ? d : c : c : d
    }, null)
  }

  function Qn(a, b) {
    const c = Math.min(a.right, b.right) - Math.max(a.left, b.left);
    a = Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top);
    return 0 >= c || 0 >= a ? !1 : 50 <= 100 * c * a / ((b.right - b.left) * (b.bottom - b.top))
  }

  function Tn() {
    const a = [...document.getElementsByTagName("iframe")].filter(Mn),
      b = [...Ln()].map(c => document.getElementById(c)).filter(c => null !== c);
    Un = window.scrollX;
    Vn = window.scrollY;
    return Wn = [...a, ...b].map(c => c.getBoundingClientRect())
  }

  function Xn() {
    var a = new Yn;
    if (L(lf)) {
      var b = window;
      if (!b.google_plmetrics && window.PerformanceObserver) {
        b.google_plmetrics = !0;
        b = ["layout-shift", "largest-contentful-paint", "first-input", "longtask"];
        for (const c of b) Zn(a).observe({
          type: c,
          buffered: !0
        });
        $n(a)
      }
    }
  }

  function Zn(a) {
    a.l || (a.l = new PerformanceObserver(xi(640, b => {
      const c = Un !== window.scrollX || Vn !== window.scrollY ? [] : Wn,
        d = Tn();
      for (const h of b.getEntries()) switch (h.entryType) {
        case "layout-shift":
          b = a;
          var e = h,
            f = c,
            g = d;
          if (!e.hadRecentInput) {
            b.H += Number(e.value);
            Number(e.value) > b.W && (b.W = Number(e.value));
            b.X += 1;
            if (f = Nn(e, f, g)) b.m += e.value, b.Aa++;
            if (5E3 < e.startTime - b.za || 1E3 < e.startTime - b.Ca) b.za = e.startTime, b.h = 0, b.i = 0;
            b.Ca = e.startTime;
            b.h += e.value;
            f && (b.i += e.value);
            b.h > b.ba && (b.ba = b.h, b.Fa = b.i, b.Ea = e.startTime +
              e.duration)
          }
          break;
        case "largest-contentful-paint":
          b = h;
          a.ya = Math.floor(b.renderTime || b.loadTime);
          a.xa = b.size;
          break;
        case "first-input":
          b = h;
          a.va = Number((b.processingStart - b.startTime).toFixed(3));
          a.wa = !0;
          break;
        case "longtask":
          b = Math.max(0, h.duration - 50), a.D += b, a.V = Math.max(a.V, b), a.Y += 1
      }
    })));
    return a.l
  }

  function $n(a) {
    const b = xi(641, () => {
        var d = document;
        2 == (d.prerendering ? 3 : {
          visible: 1,
          hidden: 2,
          prerender: 3,
          preview: 4,
          unloaded: 5
        } [d.visibilityState || d.webkitVisibilityState || d.mozVisibilityState || ""] || 0) && ao(a)
      }),
      c = xi(641, () => void ao(a));
    document.addEventListener("visibilitychange", b);
    document.addEventListener("unload", c);
    a.ua = () => {
      document.removeEventListener("visibilitychange", b);
      document.removeEventListener("unload", c);
      Zn(a).disconnect()
    }
  }

  function ao(a) {
    if (!a.Ba) {
      a.Ba = !0;
      Zn(a).takeRecords();
      var b = "https://pagead2.googlesyndication.com/pagead/gen_204?id=plmetrics";
      window.LayoutShift && (b += Kn("cls", a.H), b += Kn("mls", a.W), b += Jn("nls", a.X), window.LayoutShiftAttribution && (b += Kn("cas", a.m), b += Jn("nas", a.Aa)), b += Kn("wls", a.ba), b += Kn("tls", a.Ea), window.LayoutShiftAttribution && (b += Kn("was", a.Fa)));
      window.LargestContentfulPaint && (b += Jn("lcp", a.ya), b += Jn("lcps", a.xa));
      window.PerformanceEventTiming && a.wa && (b += Jn("fid", a.va));
      window.PerformanceLongTaskTiming &&
        (b += Jn("cbt", a.D), b += Jn("mbt", a.V), b += Jn("nlt", a.Y));
      let d = 0;
      for (var c of document.getElementsByTagName("iframe")) Mn(c) && d++;
      b += Jn("nif", d);
      b += Jn("ifi", fd(window));
      c = K(Gh).h();
      b += `&${"eid"}=${encodeURIComponent(c.join())}`;
      b += `&${"top"}=${m===m.top?1:0}`;
      b += a.Da ? `&${"qqid"}=${encodeURIComponent(a.Da)}` : Jn("pvsid", Vc(m));
      window.googletag && (b += "&gpt=1");
      window.fetch(b, {
        keepalive: !0,
        credentials: "include",
        redirect: "follow",
        method: "get",
        mode: "no-cors"
      });
      a.A || (a.A = !0, a.j())
    }
  }
  class Yn extends od {
    constructor() {
      super();
      this.i = this.h = this.X = this.W = this.H = 0;
      this.Ca = this.za = Number.NEGATIVE_INFINITY;
      this.va = this.xa = this.ya = this.Aa = this.Fa = this.m = this.Ea = this.ba = 0;
      this.wa = !1;
      this.Y = this.V = this.D = 0;
      const a = document.querySelector("[data-google-query-id]");
      this.Da = a ? a.getAttribute("data-google-query-id") : null;
      this.l = null;
      this.Ba = !1;
      this.ua = () => {}
    }
    j() {
      super.j();
      this.ua()
    }
  }
  var Un = void 0,
    Vn = void 0,
    Wn = [];
  var X = {
      issuerOrigin: "https://attestation.android.com",
      issuancePath: "/att/i",
      redemptionPath: "/att/r"
    },
    Y = {
      issuerOrigin: "https://pagead2.googlesyndication.com",
      issuancePath: "/dtt/i",
      redemptionPath: "/dtt/r",
      getStatePath: "/dtt/s"
    };

  function bo() {
    const a = window.navigator.userAgent,
      b = /Chrome/.test(a);
    return /Android/.test(a) && b
  }

  function co(a = window) {
    return !a.PeriodicSyncManager
  }

  function eo() {
    var a = window.document;
    const b = K(uf).i(sf.h, sf.defaultValue);
    Uc(b, a)
  }

  function fo(a, b) {
    return a || ".google.ch" === b || "function" === typeof H.__tcfapi
  }

  function Z(a, b, c) {
    if (a = window.goog_tt_state_map ? .get(a)) a.state = b, void 0 != c && (a.hasRedemptionRecord = c)
  }

  function go() {
    const a = `${X.issuerOrigin}${X.redemptionPath}`,
      b = {
        keepalive: !0,
        trustToken: {
          type: "token-redemption",
          issuer: X.issuerOrigin,
          refreshPolicy: "none"
        }
      };
    Z(X.issuerOrigin, 2);
    return window.fetch(a, b).then(c => {
      if (!c.ok) throw Error(`${c.status}: Network response was not ok!`);
      Z(X.issuerOrigin, 6, !0)
    }).catch(c => {
      c && "NoModificationAllowedError" === c.name ? Z(X.issuerOrigin, 6, !0) : Z(X.issuerOrigin, 5)
    })
  }

  function ho() {
    const a = `${X.issuerOrigin}${X.issuancePath}`;
    Z(X.issuerOrigin, 8);
    return window.fetch(a, {
      keepalive: !0,
      trustToken: {
        type: "token-request"
      }
    }).then(b => {
      if (!b.ok) throw Error(`${b.status}: Network response was not ok!`);
      Z(X.issuerOrigin, 10);
      return go()
    }).catch(b => {
      if (b && "NoModificationAllowedError" === b.name) return Z(X.issuerOrigin, 10), go();
      Z(X.issuerOrigin, 9)
    })
  }

  function io() {
    Z(X.issuerOrigin, 13);
    return document.hasTrustToken(X.issuerOrigin).then(a => a ? go() : ho())
  }

  function jo() {
    Z(Y.issuerOrigin, 13);
    if (window.Promise) {
      var a = document.hasTrustToken(Y.issuerOrigin).then(e => e).catch(e => window.Promise.reject({
        state: 19,
        error: e
      }));
      const b = `${Y.issuerOrigin}${Y.redemptionPath}`,
        c = {
          keepalive: !0,
          trustToken: {
            type: "token-redemption",
            refreshPolicy: "none"
          }
        };
      Z(Y.issuerOrigin, 16);
      a = a.then(e => window.fetch(b, c).then(f => {
        if (!f.ok) throw Error(`${f.status}: Network response was not ok!`);
        Z(Y.issuerOrigin, 18, !0)
      }).catch(f => {
        if (f && "NoModificationAllowedError" === f.name) Z(Y.issuerOrigin,
          18, !0);
        else {
          if (e) return window.Promise.reject({
            state: 17,
            error: f
          });
          Z(Y.issuerOrigin, 17)
        }
      })).then(() => document.hasTrustToken(Y.issuerOrigin).then(e => e).catch(e => window.Promise.reject({
        state: 19,
        error: e
      }))).then(e => {
        const f = `${Y.issuerOrigin}${Y.getStatePath}`;
        Z(Y.issuerOrigin, 20);
        return window.fetch(`${f}?ht=${e}`, {
          trustToken: {
            type: "send-redemption-record",
            issuers: [Y.issuerOrigin]
          }
        }).then(g => {
          if (!g.ok) throw Error(`${g.status}: Network response was not ok!`);
          Z(Y.issuerOrigin, 22);
          return g.text().then(h =>
            JSON.parse(h))
        }).catch(g => window.Promise.reject({
          state: 21,
          error: g
        }))
      });
      const d = Vc(window);
      return a.then(e => {
        const f = `${Y.issuerOrigin}${Y.issuancePath}`;
        return e && e.srqt && e.cs ? (Z(Y.issuerOrigin, 23), window.fetch(`${f}?cs=${e.cs}&correlator=${d}`, {
          keepalive: !0,
          trustToken: {
            type: "token-request"
          }
        }).then(g => {
          if (!g.ok) throw Error(`${g.status}: Network response was not ok!`);
          Z(Y.issuerOrigin, 25);
          return e
        }).catch(g => window.Promise.reject({
          state: 24,
          error: g
        }))) : e
      }).then(e => {
        if (e && e.srdt && e.cs) return Z(Y.issuerOrigin,
          26), window.fetch(`${b}?cs=${e.cs}&correlator=${d}`, {
          keepalive: !0,
          trustToken: {
            type: "token-redemption",
            refreshPolicy: "refresh"
          }
        }).then(f => {
          if (!f.ok) throw Error(`${f.status}: Network response was not ok!`);
          Z(Y.issuerOrigin, 28, !0)
        }).catch(f => window.Promise.reject({
          state: 27,
          error: f
        }))
      }).then(() => {
        Z(Y.issuerOrigin, 29)
      }).catch(e => {
        if (e instanceof Object && e.hasOwnProperty("state") && e.hasOwnProperty("error"))
          if ("number" === typeof e.state && e.error instanceof Error) {
            Z(Y.issuerOrigin, e.state);
            const f = M(rf);
            Math.random() <=
              f && Cf({
                state: e.state,
                err: e.error.toString()
              })
          } else throw Error(e);
        else throw e;
      })
    }
  }

  function ko(a) {
    if (document.hasTrustToken && !L(pf)) {
      var b = window.goog_tt_promise_map;
      if (b && b instanceof Map) {
        var c = [];
        if (a.h.some(d => d.issuerOrigin === X.issuerOrigin)) {
          let d = b.get(X.issuerOrigin);
          d || (d = io(), b.set(X.issuerOrigin, d));
          c.push(d)
        }
        a.h.some(d => d.issuerOrigin === Y.issuerOrigin) && (a = b.get(Y.issuerOrigin), a || (a = jo(), b.set(Y.issuerOrigin, a)), c.push(a));
        if (0 < c.length && window.Promise && window.Promise.all) return window.Promise.all(c)
      }
    }
  }
  var lo = class extends od {
    constructor(a, b) {
      super();
      this.h = [];
      a && bo() && this.h.push(X);
      b && this.h.push(Y);
      if (document.hasTrustToken && !L(pf)) {
        const c = new Map;
        this.h.forEach(d => {
          c.set(d.issuerOrigin, {
            issuerOrigin: d.issuerOrigin,
            state: 1,
            hasRedemptionRecord: !1
          })
        });
        window.goog_tt_state_map = window.goog_tt_state_map && window.goog_tt_state_map instanceof Map ? new Map([...c, ...window.goog_tt_state_map]) : c;
        window.goog_tt_promise_map && window.goog_tt_promise_map instanceof Map || (window.goog_tt_promise_map = new Map)
      }
    }
  };

  function mo(a, b) {
    return t(a, 2, b)
  }

  function no(a, b) {
    return t(a, 3, b)
  }

  function oo(a, b) {
    return t(a, 4, b)
  }

  function po(a, b) {
    return t(a, 5, b)
  }

  function qo(a, b) {
    return t(a, 9, b)
  }

  function ro(a, b) {
    return Eb(a, 10, b)
  }

  function so(a, b) {
    return t(a, 11, b)
  }

  function to(a, b) {
    return t(a, 1, b)
  }
  var vo = class extends D {
      constructor() {
        super(void 0, -1, uo)
      }
    },
    wo = class extends D {
      constructor() {
        super(void 0)
      }
      getVersion() {
        return B(this, 2)
      }
    },
    uo = [10, 6];
  const xo = "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(" ");

  function yo() {
    if ("function" !== typeof H.navigator ? .userAgentData ? .getHighEntropyValues) return null;
    const a = H.google_tag_data ? ? (H.google_tag_data = {});
    if (a.uach_promise) return a.uach_promise;
    const b = H.navigator.userAgentData.getHighEntropyValues(xo).then(c => {
      a.uach ? ? (a.uach = c);
      return c
    });
    return a.uach_promise = b
  }

  function zo(a) {
    return so(ro(qo(po(oo(no(mo(to(new vo, a.platform || ""), a.platformVersion || ""), a.architecture || ""), a.model || ""), a.uaFullVersion || ""), a.bitness || ""), a.fullVersionList ? .map(b => {
      var c = new wo;
      c = t(c, 1, b.brand);
      return t(c, 2, b.version)
    }) || []), a.wow64 || !1)
  }

  function Ao() {
    return yo() ? .then(a => zo(a)) ? ? null
  };
  var Bo = (a, b) => {
      b.google_ad_host || (a = Gl(a)) && (b.google_ad_host = a)
    },
    Eo = (a, b, c = "") => {
      H.google_sa_impl && !H.document.getElementById("google_shimpl") && (delete H.google_sa_queue, delete H.google_sa_impl);
      H.google_sa_queue || (H.google_sa_queue = [], H.google_process_slots = mj(215, () => Co(H.google_sa_queue)), a = Do(c, a, b), Cc(H.document, a).id = "google_shimpl")
    };

  function Co(a) {
    const b = a.shift();
    "function" === typeof b && R.ea(216, b);
    a.length && m.setTimeout(mj(215, () => Co(a)), 0)
  }
  var Fo = (a, b, c) => {
      a.google_sa_queue = a.google_sa_queue || [];
      a.google_sa_impl ? c(b) : a.google_sa_queue.push(b)
    },
    Do = (a, b, c) => {
      var d = Math.random() < M($e) ? fc(ec(b.nb).toString()) : null;
      b = w(c, 4) ? b.mb : b.ob;
      d = d ? d : fc(ec(b).toString());
      b = {};
      a: {
        if (w(c, 4)) {
          if (c = a || Hn(H)) {
            c = {
              client: c,
              plah: H.location.host
            };
            break a
          }
          throw Error("PublisherCodeNotFoundForAma");
        }
        c = {}
      }
      Go(c, b);
      a: {
        if (!L(Je) && (L(Xe) || L(Ie)) && (a = a || Hn(H), c = Fl(H), a)) {
          a = {
            client: a,
            plah: H.location.host,
            ama_t: "adsense",
            asntp: M(ze),
            asntpv: M(De),
            asntpl: M(Be),
            asntpm: M(Ce),
            asntpc: M(Ae),
            asna: M(ve),
            asnd: M(we),
            asnp: M(xe),
            asns: M(ye),
            asmat: M(ue),
            asptt: M(Ee),
            easpi: L(Xe),
            asro: L(Fe),
            host: c,
            easai: L(Ve)
          };
          break a
        }
        a = {}
      }
      Go(a, b);
      Go(K(uf).h(te.h, te.defaultValue) ? {
        bust: K(uf).h(te.h, te.defaultValue)
      } : {}, b);
      return cc(d, b)
    };

  function Go(a, b) {
    E(a, (c, d) => {
      void 0 === b[d] && (b[d] = c)
    })
  }
  var Ho = a => {
      a: {
        var b = [m.top];
        var c = [];
        let e = 0,
          f;
        for (; f = b[e++];) {
          c.push(f);
          try {
            if (f.frames)
              for (let g = 0; g < f.frames.length && 1024 > b.length; ++g) b.push(f.frames[g])
          } catch {}
        }
        b = c;
        for (c = 0; c < b.length; c++) try {
          var d = b[c].frames.google_esf;
          if (d) {
            Yc = d;
            break a
          }
        } catch (g) {}
        Yc = null
      }
      if (Yc) return null;d = Dc("IFRAME");d.id = "google_esf";d.name = "google_esf";d.src = ec(a.tb).toString();d.style.display = "none";
      return d
    },
    Jo = (a, b, c, d) => {
      Io(a, b, c, d, (e, f) => {
        e = e.document;
        for (var g = void 0, h = 0; !g || e.getElementById(g + (L(jf) ? "_host" : "_anchor"));) g =
          "aswift_" + h++;
        e = g;
        g = Number(f.google_ad_width || 0);
        f = Number(f.google_ad_height || 0);
        if (L(jf)) h = Dc("DIV"), h.id = e + "_host", Km(h, g, f), h.style.display = "block", f = {
          fb: h,
          Oa: h
        };
        else {
          h = Dc("INS");
          h.id = e + "_anchor";
          Km(h, g, f);
          h.style.display = "block";
          var k = Dc("INS");
          k.id = e + "_expand";
          Km(k, g, f);
          k.style.display = "inline-table";
          k.appendChild(h);
          f = {
            fb: h,
            Oa: k
          }
        }({
          Oa: f
        } = f);
        c.appendChild(f);
        return e
      })
    },
    Io = (a, b, c, d, e) => {
      e = e(a, b);
      Ko(a, c, b);
      c = pa;
      const f = (new Date).getTime();
      b.google_lrv = B(d, 2);
      b.google_async_iframe_id = e;
      b.google_start_time =
        c;
      b.google_bpp = f > c ? f - c : 1;
      a.google_sv_map = a.google_sv_map || {};
      a.google_sv_map[e] = b;
      d = a.document.getElementById(e + (L(jf) ? "_host" : "_anchor")) ? h => h() : h => window.setTimeout(h, 0);
      const g = {
        pubWin: a,
        vars: b
      };
      Fo(a, () => {
        const h = a.google_sa_impl(g);
        h && h.catch && R.fa(911, h)
      }, d)
    },
    Ko = (a, b, c) => {
      var d = c.google_ad_output,
        e = c.google_ad_format,
        f = c.google_ad_width || 0,
        g = c.google_ad_height || 0;
      e || "html" != d && null != d || (e = f + "x" + g);
      d = !c.google_ad_slot || c.google_override_format || !Lm[c.google_ad_width + "x" + c.google_ad_height] && "aa" ==
        c.google_loader_used;
      e && d ? e = e.toLowerCase() : e = "";
      c.google_ad_format = e;
      if ("number" !== typeof c.google_reactive_sra_index || !c.google_ad_unit_key) {
        e = [c.google_ad_slot, c.google_orig_ad_format || c.google_ad_format, c.google_ad_type, c.google_orig_ad_width || c.google_ad_width, c.google_orig_ad_height || c.google_ad_height];
        d = [];
        f = 0;
        for (g = b; g && 25 > f; g = g.parentNode, ++f) 9 === g.nodeType ? d.push("") : d.push(g.id);
        (d = d.join()) && e.push(d);
        c.google_ad_unit_key = Jc(e.join(":")).toString();
        e = [];
        for (d = 0; b && 25 > d; ++d) {
          f = (f = 9 !==
            b.nodeType && b.id) ? "/" + f : "";
          a: {
            if (b && b.nodeName && b.parentElement) {
              g = b.nodeName.toString().toLowerCase();
              const h = b.parentElement.childNodes;
              let k = 0;
              for (let l = 0; l < h.length; ++l) {
                const q = h[l];
                if (q.nodeName && q.nodeName.toString().toLowerCase() === g) {
                  if (b === q) {
                    g = "." + k;
                    break a
                  }++k
                }
              }
            }
            g = ""
          }
          e.push((b.nodeName && b.nodeName.toString().toLowerCase()) + f + g);
          b = b.parentElement
        }
        b = e.join() + ":";
        e = [];
        if (a) try {
          let h = a.parent;
          for (d = 0; h && h !== a && 25 > d; ++d) {
            const k = h.frames;
            for (f = 0; f < k.length; ++f)
              if (a === k[f]) {
                e.push(f);
                break
              } a =
              h;
            h = a.parent
          }
        } catch (h) {}
        c.google_ad_dom_fingerprint = Jc(b + e.join()).toString()
      }
    },
    Lo = () => {
      var a = Bc(m);
      a && (a = Of(a), a.tagSpecificState[1] || (a.tagSpecificState[1] = {
        debugCard: null,
        debugCardRequested: !1
      }))
    },
    Mo = a => {
      eo();
      fo(pl(), B(a, 8)) || mj(779, () => {
        var b = L(co(window) ? of : nf);
        const c = L(qf);
        b = new lo(b, c);
        0 < M(tf) ? H.google_trust_token_operation_promise = ko(b) : ko(b)
      })();
      a = Ao();
      null != a && a.then(b => {
        a: {
          fb = !0;
          try {
            var c = JSON.stringify(b.toJSON(), Kb);
            break a
          } finally {
            fb = !1
          }
          c = void 0
        }
        H.google_user_agent_client_hint = c
      });
      om(K(uf).i(kf.h, kf.defaultValue), H.document)
    };

  function No(a, b) {
    switch (a) {
      case "google_reactive_ad_format":
        return a = parseInt(b, 10), isNaN(a) ? 0 : a;
      case "google_allow_expandable_ads":
        return /^true$/.test(b);
      default:
        return b
    }
  }

  function Oo(a, b) {
    if (a.getAttribute("src")) {
      var c = a.getAttribute("src") || "";
      (c = zc(c)) && (b.google_ad_client = No("google_ad_client", c))
    }
    a = a.attributes;
    c = a.length;
    for (let e = 0; e < c; e++) {
      var d = a[e];
      if (/data-/.test(d.name)) {
        const f = ra(d.name.replace("data-matched-content", "google_content_recommendation").replace("data", "google").replace(/-/g, "_"));
        b.hasOwnProperty(f) || (d = No(f, d.value), null !== d && (b[f] = d))
      }
    }
  }

  function Po(a) {
    if (a = ad(a)) switch (a.data && a.data.autoFormat) {
      case "rspv":
        return 13;
      case "mcrspv":
        return 15;
      default:
        return 14
    } else return 12
  }

  function Qo(a, b, c, d) {
    Oo(a, b);
    if (c.document && c.document.body && !sn(c, b) && !b.google_reactive_ad_format) {
      var e = parseInt(a.style.width, 10),
        f = vn(a, c);
      if (0 < f && e > f) {
        var g = parseInt(a.style.height, 10);
        e = !!Lm[e + "x" + g];
        var h = f;
        if (e) {
          const k = Mm(f, g);
          if (k) h = k, b.google_ad_format = k + "x" + g + "_0ads_al";
          else throw new Q("No slot size for availableWidth=" + f);
        }
        b.google_ad_resize = !0;
        b.google_ad_width = h;
        e || (b.google_ad_format = null, b.google_override_format = !0);
        f = h;
        a.style.width = f + "px";
        g = nn(f, "auto", c, a, b);
        h = f;
        g.size().i(c,
          b, a);
        Um(g, h, b);
        g = g.size();
        b.google_responsive_formats = null;
        g.minWidth() > f && !e && (b.google_ad_width = g.minWidth(), a.style.width = g.minWidth() + "px")
      }
    }(e = a.offsetWidth) || (e = fi(a, c, "width", G));
    e = e || b.google_ad_width || 0;
    f = ma(nn, e, "auto", c, a, b, !1, !0);
    if (!L(Se) && 488 > N(c).clientWidth) {
      g = Bc(c) || c;
      h = b.google_ad_client;
      d = g.location && "#ftptohbh" === g.location.hash ? 2 : Vl(g.location, "google_responsive_slot_preview") || L(bf) ? 1 : L(af) ? 2 : sl(g, 1, h, d) ? 1 : 0;
      if (g = 0 !== d) b: if (b.google_reactive_ad_format || L(Te) && b.google_ad_resize ||
          sn(c, b) || Vh(a, b)) g = !1;
        else {
          for (g = a; g; g = g.parentElement) {
            h = Ec(g, c);
            if (!h) {
              b.gfwrnwer = 18;
              g = !1;
              break b
            }
            if (!Ja(["static", "relative"], h.position)) {
              b.gfwrnwer = 17;
              g = !1;
              break b
            }
          }
          g = Zh(c, a, e, .3, b);
          !0 !== g ? (b.gfwrnwer = g, g = !1) : g = c === c.top ? !0 : !1
        } g ? (b.google_resizing_allowed = !0, b.ovlp = !0, 2 === d ? (d = {}, Um(f(), e, d), b.google_resizing_width = d.google_ad_width, b.google_resizing_height = d.google_ad_height, b.iaaso = !1) : (b.google_ad_format = "auto", b.iaaso = !0, b.armr = 1), d = !0) : d = !1
    } else d = !1;
    if (e = sn(c, b)) un(e, a, b, c, d);
    else {
      if (Vh(a,
          b)) {
        if (d = Ec(a, c)) a.style.width = d.width, a.style.height = d.height, Uh(d, b);
        b.google_ad_width || (b.google_ad_width = a.offsetWidth);
        b.google_ad_height || (b.google_ad_height = a.offsetHeight);
        b.google_loader_features_used = 256;
        b.google_responsive_auto_format = Po(c)
      } else Uh(a.style, b);
      c.location && "#gfwmrp" == c.location.hash || 12 == b.google_responsive_auto_format && "true" == b.google_full_width_responsive ? un(10, a, b, c, !1) : .01 > Math.random() && 12 === b.google_responsive_auto_format && (a = $h(a.offsetWidth || parseInt(a.style.width,
        10) || b.google_ad_width, c, a, b), !0 !== a ? (b.efwr = !1, b.gfwrnwer = a) : b.efwr = !0)
    }
  };

  function Ro() {
    var a = K(So);
    var b = new Jk;
    b = t(b, 1, N(a.v).scrollWidth);
    b = t(b, 2, N(a.v).scrollHeight);
    var c = new Jk;
    c = t(c, 1, N(a.v).clientWidth);
    c = t(c, 2, N(a.v).clientHeight);
    var d = new Lk;
    d = t(d, 1, a.A);
    d = t(d, 2, a.m);
    d = t(d, 3, a.h);
    var e = new Kk;
    b = Cb(e, 2, b);
    b = Cb(b, 1, c);
    b = Db(d, 4, Mk, b);
    a.i && !a.j.has(1) && (a.j.add(1), rg(a.l, b))
  }
  var So = class {
    constructor(a) {
      this.j = new Set;
      this.v = bd() || window;
      this.h = M(se);
      var b = 0 < this.h && Ic() < 1 / this.h;
      this.A = (this.i = !!vj(qj(), 30, b)) ? Vc(this.v) : 0;
      this.m = this.i ? Hn(this.v) : "";
      this.l = a ? ? new vg(100)
    }
  };

  function To() {
    const a = dd `(a=0)=>{let b;const c=class{};}`;
    try {
      var b = window;
      const c = a instanceof $b && a.constructor === $b ? a.h : "type_error:SafeScript";
      b.eval(c) === c && b.eval(c.toString());
      return [!0, ""]
    } catch (c) {
      return [!1, String(c)]
    }
  };
  var Uo = a => {
    oc(window, "message", b => {
      let c;
      try {
        c = JSON.parse(b.data)
      } catch (d) {
        return
      }!c || "sc-cnf" !== c.googMsgType || a(c, b)
    })
  };
  var Vo = class extends od {
    constructor() {
      super();
      this.i = H;
      this.ra = 500;
      this.h = null;
      this.m = {};
      this.l = null
    }
    j() {
      this.m = {};
      this.l && (pc(this.i, "message", this.l), delete this.l);
      delete this.m;
      delete this.i;
      delete this.h;
      super.j()
    }
  };
  var Wo = class extends od {
    constructor() {
      super();
      this.l = H;
      this.h = null;
      this.i = !1
    }
  };
  let Xo = null;
  const Yo = [],
    Zo = new Map;
  let $o = -1;
  var ap = a => ni.test(a.className) && "done" != a.dataset.adsbygoogleStatus,
    cp = (a, b, c) => {
      a.dataset.adsbygoogleStatus = "done";
      bp(a, b, c)
    },
    bp = (a, b, c) => {
      var d = window;
      d.google_spfd || (d.google_spfd = Qo);
      var e = b.google_reactive_ads_config;
      e || Qo(a, b, d, c);
      Bo(d, b);
      if (!dp(a, b, d)) {
        e || (d.google_lpabyc = Xh(a, d) + fi(a, d, "height", G));
        if (e) {
          e = e.page_level_pubvars || {};
          if (T(H).page_contains_reactive_tag && !T(H).allow_second_reactive_tag) {
            if (e.pltais) {
              Dl(!1);
              return
            }
            throw new Q("Only one 'enable_page_level_ads' allowed per page.");
          }
          T(H).page_contains_reactive_tag = !0;
          Dl(7 === e.google_pgb_reactive)
        }
        b.google_unique_id = ed(d);
        E(zn, (f, g) => {
          b[g] = b[g] || d[g]
        });
        b.google_loader_used = "aa";
        b.google_reactive_tag_first = 1 === (T(H).first_tag_on_page || 0);
        lj(164, () => {
          Jo(d, b, a, c)
        })
      }
    },
    dp = (a, b, c) => {
      var d = b.google_reactive_ads_config,
        e = "string" === typeof a.className && RegExp("(\\W|^)adsbygoogle-noablate(\\W|$)").test(a.className),
        f = Bl(c);
      if (f && f.Ga && "on" != b.google_adtest && !e) {
        e = Xh(a, c);
        const g = N(c).clientHeight;
        e = 0 == g ? null : e / g;
        if (!f.na || f.na && (e || 0) >= f.na) return a.className += " adsbygoogle-ablated-ad-slot",
          c = c.google_sv_map = c.google_sv_map || {}, d = fa(a), b.google_element_uid = d, c[b.google_element_uid] = b, a.setAttribute("google_element_uid", d), "slot" == f.rb && (null !== Nc(a.getAttribute("width")) && a.setAttribute("width", 0), null !== Nc(a.getAttribute("height")) && a.setAttribute("height", 0), a.style.width = "0px", a.style.height = "0px"), !0
      }
      if ((f = Ec(a, c)) && "none" == f.display && !("on" == b.google_adtest || 0 < b.google_reactive_ad_format || d)) return c.document.createComment && a.appendChild(c.document.createComment("No ad requested because of display:none on the adsbygoogle tag")),
        !0;
      a = null == b.google_pgb_reactive || 3 === b.google_pgb_reactive;
      return 1 !== b.google_reactive_ad_format && 8 !== b.google_reactive_ad_format || !a ? !1 : (m.console && m.console.warn("Adsbygoogle tag with data-reactive-ad-format=" + b.google_reactive_ad_format + " is deprecated. Check out page-level ads at https://www.google.com/adsense"), !0)
    },
    ep = a => {
      var b = document.getElementsByTagName("INS");
      for (let d = 0, e = b[d]; d < b.length; e = b[++d]) {
        var c = e;
        if (ap(c) && "reserved" != c.dataset.adsbygoogleStatus && (!a || e.id == a)) return e
      }
      return null
    },
    gp = (a, b, c) => {
      if (a && a.shift) {
        let d = 20;
        for (; 0 < a.length && 0 < d;) {
          try {
            fp(a.shift(), b, c)
          } catch (e) {
            setTimeout(() => {
              throw e;
            })
          }--d
        }
      }
    },
    hp = () => {
      const a = Dc("INS");
      a.className = "adsbygoogle";
      a.className += " adsbygoogle-noablate";
      Qc(a);
      return a
    },
    ip = (a, b) => {
      const c = {};
      E(Nf, (f, g) => {
        !1 === a.enable_page_level_ads ? c[g] = !1 : a.hasOwnProperty(g) && (c[g] = a[g])
      });
      ea(a.enable_page_level_ads) && (c.page_level_pubvars = a.enable_page_level_ads);
      const d = hp();
      Wc.body.appendChild(d);
      const e = {
        google_reactive_ads_config: c,
        google_ad_client: a.google_ad_client
      };
      e.google_pause_ad_requests = !!T(H).pause_ad_requests;
      cp(d, e, b)
    },
    jp = (a, b) => {
      Of(m).wasPlaTagProcessed = !0;
      const c = () => ip(a, b),
        d = m.document;
      if (d.body || "complete" == d.readyState || "interactive" == d.readyState) ip(a, b);
      else {
        const e = nc(R.qa(191, c));
        oc(d, "DOMContentLoaded", e);
        (new m.MutationObserver((f, g) => {
          d.body && (e(), g.disconnect())
        })).observe(d, {
          childList: !0,
          subtree: !0
        })
      }
    },
    fp = (a, b, c) => {
      const d = {};
      lj(165, () => {
        kp(a, d, b, c)
      }, e => {
        e.client = e.client || d.google_ad_client || a.google_ad_client;
        e.slotname = e.slotname ||
          d.google_ad_slot;
        e.tag_origin = e.tag_origin || d.google_tag_origin
      })
    };

  function lp(a) {
    delete a.google_checked_head;
    E(a, (b, c) => {
      mi[c] || (delete a[c], m.console.warn(`AdSense head tag doesn't support ${c.replace("google","data").replace(/_/g,"-")} attribute.`))
    })
  }
  var op = (a, b) => {
    var c = H.document.querySelector('script[src*="/pagead/js/adsbygoogle.js?client="]:not([data-checked-head])') || H.document.querySelector('script[src*="/pagead/js/adsbygoogle.js"][data-ad-client]:not([data-checked-head])');
    if (c) {
      c.setAttribute("data-checked-head", "true");
      var d = T(window);
      if (d.head_tag_slot_vars) mp(c);
      else {
        var e = {};
        Oo(c, e);
        lp(e);
        var f = Wb(e);
        d.head_tag_slot_vars = f;
        c = {
          google_ad_client: e.google_ad_client,
          enable_page_level_ads: e
        };
        H.adsbygoogle || (H.adsbygoogle = []);
        d = H.adsbygoogle;
        d.loaded ? d.push(c) : d.splice(0, 0, c);
        e.google_adbreak_test || Gb(b, $k, 13, tb) ? .l() && L(ff) ? np(f, a) : Uo(() => {
          np(f, a)
        })
      }
    }
  };
  const mp = a => {
    const b = T(window).head_tag_slot_vars,
      c = a.getAttribute("src") || "";
    if ((a = zc(c) || a.getAttribute("data-ad-client") || "") && a !== b.google_ad_client) throw new Q("Warning: Do not add multiple property codes with AdSense tag to avoid seeing unexpected behavior. These codes were found on the page " + a + ", " + b.google_ad_client);
  };
  var pp = a => {
      if ("object" === typeof a && null != a) {
        if ("string" === typeof a.type) return 2;
        if ("string" === typeof a.sound || "string" === typeof a.preloadAdBreaks) return 3
      }
      return 0
    },
    kp = (a, b, c, d) => {
      if (null == a) throw new Q("push() called with no parameters.");
      rb(d, 14) && qp(a, ub(ll(d), 1), B(d, 2));
      var e = pp(a);
      if (0 !== e) L(Ye) && (d = El(), d.first_slotcar_request_processing_time || (d.first_slotcar_request_processing_time = Date.now(), d.adsbygoogle_execution_start_time = pa)), null == Xo ? (rp(a), Yo.push(a)) : 3 === e ? lj(787, () => {
          Xo.handleAdConfig(a)
        }) :
        R.fa(730, Xo.handleAdBreak(a));
      else {
        pa = (new Date).getTime();
        Eo(c, d, sp(a));
        tp();
        a: {
          if (void 0 != a.enable_page_level_ads) {
            if ("string" === typeof a.google_ad_client) {
              e = !0;
              break a
            }
            throw new Q("'google_ad_client' is missing from the tag config.");
          }
          e = !1
        }
        if (e) up(a, d);
        else if ((e = a.params) && E(e, (g, h) => {
            b[h] = g
          }), "js" === b.google_ad_output) console.warn("Ads with google_ad_output='js' have been deprecated and no longer work. Contact your AdSense account manager or switch to standard AdSense ads.");
        else {
          e = vp(a.element);
          Oo(e, b);
          c = T(m).head_tag_slot_vars || {};
          E(c, (g, h) => {
            b.hasOwnProperty(h) || (b[h] = g)
          });
          if (e.hasAttribute("data-require-head") && !T(m).head_tag_slot_vars) throw new Q("AdSense head tag is missing. AdSense body tags don't work without the head tag. You can copy the head tag from your account on https://adsense.com.");
          if (!b.google_ad_client) throw new Q("Ad client is missing from the slot.");
          b.google_apsail = wl(b.google_ad_client);
          var f = (c = 0 === (T(H).first_tag_on_page || 0) && am(b)) && bm(c);
          c && !f && (up(c, d), T(H).skip_next_reactive_tag = !0);
          0 === (T(H).first_tag_on_page || 0) && (T(H).first_tag_on_page = 2);
          b.google_pause_ad_requests = !!T(H).pause_ad_requests;
          cp(e, b, d);
          c && f && wp(c)
        }
      }
    };
  let xp = !1;
  const qp = (a, b, c) => {
      L(Ue) && !xp && (xp = !0, (a = sp(a)) || (a = Hn(H)), nj("predictive_abg", {
        a_c: a,
        p_c: b,
        b_v: c
      }, .01))
    },
    sp = a => a.google_ad_client ? a.google_ad_client : (a = a.params) && a.google_ad_client ? a.google_ad_client : "",
    tp = () => {
      if (L(Me)) {
        var a = Bl(H);
        if (!(a = a && a.Ga)) {
          try {
            var b = H.localStorage
          } catch (c) {
            b = null
          }
          b = b ? Wk(Xk(b)) : null;
          a = !(b && Vk(b) && b)
        }
        a || Cl(H, 1)
      }
    },
    wp = a => {
      Xc(() => {
        Of(m).wasPlaTagProcessed || m.adsbygoogle && m.adsbygoogle.push(a)
      })
    },
    up = (a, b) => {
      if (T(H).skip_next_reactive_tag) T(H).skip_next_reactive_tag = !1;
      else {
        0 ===
          (T(H).first_tag_on_page || 0) && (T(H).first_tag_on_page = 1);
        if (a.tag_partner) {
          var c = a.tag_partner;
          const d = T(m);
          d.tag_partners = d.tag_partners || [];
          d.tag_partners.push(c)
        }
        em(a, b);
        jp(a, b)
      }
    },
    vp = a => {
      if (a) {
        if (!ap(a) && (a.id ? a = ep(a.id) : a = null, !a)) throw new Q("'element' has already been filled.");
        if (!("innerHTML" in a)) throw new Q("'element' is not a good DOM element.");
      } else if (a = ep(), !a) throw new Q("All ins elements in the DOM with class=adsbygoogle already have ads in them.");
      return a
    },
    yp = () => {
      var a = new Fj(H),
        b = new Vo;
      const c = new Wo;
      var d = H.__cmp ? 1 : 0;
      a = Cj(a) ? 1 : 0;
      var e;
      (e = "function" === typeof b.i ? .__uspapi) || (b.h ? b = b.h : (b.h = Oc(b.i, "__uspapiLocator"), b = b.h), e = null != b);
      b = e ? 1 : 0;
      c.i || (c.h || (c.h = Oc(c.l, "googlefcPresent")), c.i = !0);
      nj("cmpMet", {
        tcfv1: d,
        tcfv2: a,
        usp: b,
        fc: c.h ? 1 : 0,
        ptt: 9
      }, M(re))
    },
    zp = a => {
      a = {
        value: w(a, 16)
      };
      let b = .01;
      M(Oe) && (a.eid = M(Oe), b = 1);
      a.frequency = b;
      nj("new_abg_tag", a, b)
    },
    Ap = a => {
      qj().S[tj(26)] = !!Number(a)
    },
    Bp = a => {
      Number(a) ? T(H).pause_ad_requests = !0 : (T(H).pause_ad_requests = !1, a = () => {
        if (!T(H).pause_ad_requests) {
          var b = {};
          let c;
          "function" === typeof window.CustomEvent ? c = new CustomEvent("adsbygoogle-pub-unpause-ad-requests-event", b) : (c = document.createEvent("CustomEvent"), c.initCustomEvent("adsbygoogle-pub-unpause-ad-requests-event", !!b.bubbles, !!b.cancelable, b.detail));
          H.dispatchEvent(c)
        }
      }, m.setTimeout(a, 0), m.setTimeout(a, 1E3))
    },
    Cp = a => {
      nj("adsenseGfpKnob", {
        value: a,
        ptt: 9
      }, .1);
      switch (a) {
        case 0:
        case 2:
          a = !0;
          break;
        case 1:
          a = !1;
          break;
        default:
          throw Error(`Illegal value of ${"cookieOptions"}: ${a}`);
      }
      H._gfp_a_ = a
    },
    Ep = a => {
      try {
        Object.defineProperty(a,
          "requestNonPersonalizedAds", {
            set: Ap
          }), Object.defineProperty(a, "pauseAdRequests", {
          set: Bp
        }), Object.defineProperty(a, "cookieOptions", {
          set: Cp
        }), Object.defineProperty(a, "onload", {
          set: Dp
        })
      } catch (b) {}
    };

  function Dp(a) {
    a && a.call && "function" === typeof a && window.setTimeout(a, 0)
  }
  var np = (a, b) => {
    b = $l(cc(fc(ec(b.qb).toString()), K(uf).h(te.h, te.defaultValue) ? {
      bust: K(uf).h(te.h, te.defaultValue)
    } : {})).then(c => {
      null == Xo && (c.init(a), Xo = c, Fp())
    });
    R.fa(723, b);
    b.finally(() => {
      Yo.length = 0;
      nj("slotcar", {
        event: "api_ld",
        time: Date.now() - pa,
        time_pr: Date.now() - $o
      })
    })
  };
  const Fp = () => {
      for (var a of Zo.keys()) {
        const b = Zo.get(a); - 1 !== b && (m.clearTimeout(b), Zo.delete(a))
      }
      for (a = 0; a < Yo.length; a++) {
        if (Zo.has(a)) continue;
        const b = Yo[a],
          c = pp(b);
        lj(723, () => {
          if (3 === c) Xo.handleAdConfig(b);
          else if (2 === c) {
            var d = Xo.handleAdBreakBeforeReady(b);
            R.fa(730, d)
          }
        })
      }
    },
    rp = a => {
      var b = Yo.length;
      if (2 === pp(a) && "preroll" === a.type && null != a.adBreakDone) {
        -1 === $o && ($o = Date.now());
        var c = m.setTimeout(() => {
          try {
            (0, a.adBreakDone)({
              breakType: "preroll",
              breakName: a.name,
              breakFormat: "preroll",
              breakStatus: "timeout"
            }),
            Zo.set(b, -1), nj("slotcar", {
              event: "pr_to",
              source: "adsbygoogle"
            })
          } catch (d) {
            console.error("[Ad Placement API] adBreakDone callback threw an error:", d instanceof Error ? d : Error(String(d)))
          }
        }, 1E3 * M(gf));
        Zo.set(b, c)
      }
    },
    Gp = () => {
      if (L(Xe) && !L(Fe)) {
        if (L(He)) {
          var a = H.document;
          const b = a.createElement("LINK"),
            c = L(We) ? cd `https://fonts.googleapis.com/css2?family=Google+Material+Icons:wght@400;500;700&text=shoppingmode` : cd `https://fonts.googleapis.com/css2?family=Google+Material+Icons:wght@400;500;700`;
          kc(b, c, "stylesheet");
          a.head.appendChild(b)
        }
        if (L(Ge)) {
          im();
          return
        }
      }
      L(Ge) && im()
    };
  (function (a, b, c, d = () => {}) {
    R.Ra(oj);
    lj(166, () => {
      const e = In(b);
      xn(e);
      d();
      $c(16, [1, e.toJSON()]);
      var f = bd(ad(H)) || H;
      const g = c(yn({
        ab: a,
        lb: B(e, 2)
      }), e);
      tl(f, e);
      Jm(f, e, null === H.document.currentScript ? 1 : km(g.sb));
      Ro();
      if ((!wa() || 0 <= sa(Ba(), 11)) && (null == (H.Prototype || {}).Version || !L(Re))) {
        kj(L(mf));
        Mo(e);
        Ck();
        try {
          Xn()
        } catch (q) {}
        Lo();
        op(g, e);
        f = window;
        var h = f.adsbygoogle;
        if (!h || !h.loaded) {
          if (L(Ne) && !w(e, 16)) try {
            if (H.document.querySelector('script[src*="/pagead/js/adsbygoogle.js?client="]')) return
          } catch (q) {}
          Gp();
          zp(e);
          M(re) && yp();
          var k = {
            push: q => {
              fp(q, g, e)
            },
            loaded: !0
          };
          Ep(k);
          if (h)
            for (var l of ["requestNonPersonalizedAds", "pauseAdRequests", "cookieOptions"]) void 0 !== h[l] && (k[l] = h[l]);
          "_gfp_a_" in window || (window._gfp_a_ = !0);
          gp(h, g, e);
          f.adsbygoogle = k;
          h && (k.onload = h.onload);
          (l = Ho(g)) && document.documentElement.appendChild(l);
          l = To();
          nj("modern_js", {
            fy: u(e, 1, 0),
            supports: l[0],
            c: 2021,
            e: l[1]
          }, .01)
        }
      }
    })
  })("m202207130101", "undefined" === typeof sttc ? void 0 : sttc, function (a, b) {
    const c = 2012 < u(b, 1, 0) ? `_fy${u(b,1,0)}` : "";
    var d =
      B(b, 3);
    const e = B(b, 2);
    b = cd `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/slotcar_library${c}.js`;
    d = cd `https://googleads.g.doubleclick.net/pagead/html/${e}/${d}/zrt_lookup.html`;
    return {
      qb: b,
      ob: cd `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/show_ads_impl${c}.js`,
      mb: cd `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/show_ads_impl_with_ama${c}.js`,
      nb: cd `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/show_ads_impl_instrumented${c}.js`,
      tb: d,
      sb: /^(?:https?:)?\/\/(?:pagead2\.googlesyndication\.com|securepubads\.g\.doubleclick\.net)\/pagead\/(?:js\/)?(?:show_ads|adsbygoogle)\.js(?:[?#].*)?$/
    }
  });
}).call(this, "[2021,\"r20220718\",\"r20190131\",null,null,null,null,\".google.cn\",null,null,null,[[[1082,null,null,[1]],[1154,null,null,[1]],[null,62,null,[null,0.001]],[null,1130,null,[null,100]],[null,1126,null,[null,5000],[[[12,null,null,null,4,null,\"Android\",[\"navigator.userAgent\"]],[null,5500]]]],[null,1032,null,[null,200],[[[12,null,null,null,4,null,\"Android\",[\"navigator.userAgent\"]],[null,500]]]],[1131,null,null,[1]],[null,1142,null,[null,8]],[null,1165,null,[null,1000]],[null,1195,null,[null,1]],[null,1193,null,[null,100]],[null,1114,null,[null,1]],[null,1116,null,[null,300]],[null,1117,null,[null,100]],[null,1115,null,[null,1]],[null,1194,null,[null,1]],[null,1159,null,[null,500]],[null,1119,null,[null,300]],[1122,null,null,[1]],[null,66,null,[null,-1]],[null,65,null,[null,-1]],[1087,null,null,[1]],[1167,null,null,[1]],[1129,null,null,[1]],[null,1169,null,[null,15000]],[1053,null,null,[1]],[1100,null,null,[1]],[1178,null,null,[1]],[1161,null,null,[1]],[null,1072,null,[null,0.75]],[1101,null,null,[1]],[null,1168,null,[null,15000]],[1036,null,null,[1]],[null,1085,null,[null,5]],[null,63,null,[null,30]],[null,1034,null,[]],[null,1080,null,[null,5]],[1054,null,null,[1]],[null,1027,null,[null,10]],[null,57,null,[null,120]],[null,1079,null,[null,5]],[null,1050,null,[null,30]],[null,58,null,[null,120]],[1033,null,null,[1]],[380254521,null,null,[],[[[1,[[4,null,63]]],[1]]]],[381914117,null,null,[1]],[null,null,null,[],null,1939],[null,null,null,[null,null,null,[\"AzoawhTRDevLR66Y6MROu167EDncFPBvcKOaQispTo9ouEt5LvcBjnRFqiAByRT+2cDHG1Yj4dXwpLeIhc98\/gIAAACFeyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjYxMjk5MTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ==\",\"A6+nc62kbJgC46ypOwRsNW6RkDn2x7tgRh0wp7jb3DtFF7oEhu1hhm4rdZHZ6zXvnKZLlYcBlQUImC4d3kKihAcAAACLeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjYxMjk5MTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ==\",\"A\/9La288e7MDEU2ifusFnMg1C2Ij6uoa\/Z\/ylwJIXSsWfK37oESIPbxbt4IU86OGqDEPnNVruUiMjfKo65H\/CQwAAACLeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXRhZ3NlcnZpY2VzLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjYxMjk5MTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ==\"]],null,1934],[1947,null,null,[1]],[null,1972,null,[]],[392736476,null,null,[]],[null,null,null,[],null,1932],[432938498,null,null,[]]],[[12,[[200,[[42531605],[42531606]]],[200,[[42531607],[42531608]]],[50,[[44764001],[44764002]]],[20,[[21065724],[21065725,[[203,null,null,[1]]]]],[4,null,9,null,null,null,null,[\"LayoutShift\"]]],[10,[[31061690],[31061691,[[83,null,null,[1]],[84,null,null,[1]]]]]],[10,[[31067825],[31067826,[[1971,null,null,[1]]]]]],[1,[[44769661],[44769662,[[1973,null,null,[1]]]]]]]],[10,[[50,[[31068105],[31068106,[[1141,null,null,[1]]]]]],[1,[[42531513],[42531514,[[316,null,null,[1]]]]]],[1,[[42531644],[42531645,[[368,null,null,[1]]]],[42531646,[[369,null,null,[1]],[368,null,null,[1]]]]]],[1,[[44719338],[44719339,[[334,null,null,[1]],[null,54,null,[null,100]],[null,66,null,[null,10]],[null,65,null,[null,1000]]]]]],[20,[[44760911],[44760912,[[1160,null,null,[1]]]],[44763827,[[1170,null,null,[1]]]],[44768832,[[1160,null,null,[1]]]]]],[10,[[44767166],[44767167]]],[10,[[44768326,[[null,1072,null,[]]]],[44768327,[[null,1072,null,[]]]]]],[1,[[44769305],[44769306,[[313,null,null,[1]]]]]],[null,[[44755592],[44755593,[[null,null,1166,[null,null,\"h.3.0.0\"]]]],[44755594,[[null,null,1166,[null,null,\"h.3.0.0\"]]]],[44755653,[[null,null,1166,[null,null,\"h.3.0.0\"]]]]],null,51],[1,[[44763957],[44763958,[[null,null,1166,[null,null,\"h.3.0.0\"]]]],[44766752,[[null,null,1166,[null,null,\"h.3.0.0\"]]]],[44768336,[[null,null,1166,[null,null,\"h.3.0.0\"]]]],[44768337,[[null,null,1166,[null,null,\"h.3.0.0\"]]]]],null,51],[50,[[44766558],[44766559,[[1184,null,null,[1]]]]],null,56],[10,[[21066428],[21066429]]],[50,[[31067527],[31067528,[[1147,null,null,[1]]]]],null,54],[50,[[31067983],[31067984,[[null,1169,null,[null,61440]],[null,1168,null,[null,61440]]]]]],[100,[[31068195],[31068196,[[1187,null,null,[1]]]]]],[20,[[31068226,[[null,1103,null,[null,31068226]]]],[31068227,[[null,1158,null,[null,45]],[null,1157,null,[null,400]],[null,1103,null,[null,31068227]],[1182,null,null,[1]],[null,1114,null,[null,-1]],[null,1116,null,[null,50]],[null,1110,null,[null,5]],[null,1111,null,[null,5]],[null,1112,null,[null,5]],[null,1113,null,[null,5]],[null,1104,null,[null,100]],[null,1106,null,[null,10]],[null,1107,null,[null,10]],[null,1105,null,[null,10]],[null,1115,null,[null,-1]],[1162,null,null,[1]],[1120,null,null,[1]],[1164,null,null,[1]]]]],[2,[[4,null,55],[1,[[12,null,null,null,2,null,\"smitmehta\\\\.com\/|autoplaced\\\\.com\/\"]]]]],49],[10,[[31068260],[31068261,[[1177,null,null,[1]]]]]],[5,[[31068390,[[null,1103,null,[null,31068390]]]],[31068391,[[null,1103,null,[null,31068391]],[1182,null,null,[1]],[null,1114,null,[null,0.9]],[null,1110,null,[null,5]],[null,1111,null,[null,5]],[null,1112,null,[null,5]],[null,1113,null,[null,5]],[null,1104,null,[null,100]],[null,1106,null,[null,10]],[null,1107,null,[null,10]],[null,1105,null,[null,10]],[null,1115,null,[null,-1]],[1120,null,null,[1]]]],[31068392,[[null,1103,null,[null,31068392]],[1182,null,null,[1]],[1186,null,null,[1]],[1120,null,null,[1]]]]],[2,[[4,null,55],[1,[[12,null,null,null,2,null,\"smitmehta\\\\.com\/|autoplaced\\\\.com\/\"]]]]],49],[1000,[[31068471,[[null,null,14,[null,null,\"31068471\"]]],[6,null,null,null,6,null,\"31068471\"]],[31068472,[[null,null,14,[null,null,\"31068472\"]]],[6,null,null,null,6,null,\"31068472\"]]],[4,null,55]],[1000,[[31068511,[[null,null,14,[null,null,\"31068511\"]]],[6,null,null,null,6,null,\"31068511\"]],[31068512,[[null,null,14,[null,null,\"31068512\"]]],[6,null,null,null,6,null,\"31068512\"]]],[4,null,55]],[1,[[31068521,[[null,1103,null,[null,31068521]]]],[31068522,[[null,1158,null,[null,45]],[null,1157,null,[null,400]],[null,1103,null,[null,31068522]],[1182,null,null,[1]],[null,1114,null,[null,0.9]],[null,1116,null,[null,50]],[null,1110,null,[null,5]],[null,1111,null,[null,5]],[null,1112,null,[null,5]],[null,1113,null,[null,5]],[null,1104,null,[null,100]],[null,1106,null,[null,10]],[null,1107,null,[null,10]],[null,1105,null,[null,10]],[null,1115,null,[null,-1]],[null,1119,null,[null,300]],[1162,null,null,[1]],[1120,null,null,[1]],[1164,null,null,[1]]]],[31068523,[[null,1158,null,[null,45]],[null,1157,null,[null,400]],[null,1103,null,[null,31068523]],[1182,null,null,[1]],[null,1116,null,[null,50]],[1186,null,null,[1]],[null,1119,null,[null,300]],[1162,null,null,[1]],[1120,null,null,[1]],[1164,null,null,[1]]]]],[2,[[4,null,55],[1,[[12,null,null,null,2,null,\"smitmehta\\\\.com\/|autoplaced\\\\.com\/\"]]]]],49],[500,[[31068530,[[null,1103,null,[null,31068530]],[1182,null,null,[1]],[1186,null,null,[1]],[1120,null,null,[1]]]]],[2,[[4,null,55],[12,null,null,null,2,null,\"smitmehta\\\\.com\/|autoplaced\\\\.com\/\"]]],49],[300,[[31068531,[[null,1158,null,[null,45]],[null,1157,null,[null,400]],[null,1103,null,[null,31068531]],[1182,null,null,[1]],[null,1116,null,[null,50]],[1186,null,null,[1]],[null,1119,null,[null,300]],[1162,null,null,[1]],[1120,null,null,[1]],[1164,null,null,[1]]]]],[2,[[4,null,55],[12,null,null,null,2,null,\"smitmehta\\\\.com\/|autoplaced\\\\.com\/\"]]],49],[1000,[[31068534,[[null,null,14,[null,null,\"31068534\"]]],[6,null,null,null,6,null,\"31068534\"]],[31068535,[[null,null,14,[null,null,\"31068535\"]]],[6,null,null,null,6,null,\"31068535\"]]],[4,null,55]],[3,[[44767921,[[null,1103,null,[null,44767921]],[1182,null,null,[1]],[null,1114,null,[null,0.9]],[null,1110,null,[null,5]],[null,1111,null,[null,5]],[null,1112,null,[null,5]],[null,1113,null,[null,5]],[null,1104,null,[null,100]],[null,1106,null,[null,10]],[null,1107,null,[null,10]],[null,1105,null,[null,10]],[null,1115,null,[null,-1]],[1120,null,null,[1]]]],[44767922,[[null,1103,null,[null,44767922]],[1182,null,null,[1]],[null,1114,null,[null,0.9]],[null,1110,null,[null,5]],[null,1111,null,[null,5]],[null,1112,null,[null,5]],[null,1113,null,[null,5]],[null,1104,null,[null,100]],[null,1106,null,[null,10]],[null,1107,null,[null,10]],[null,1105,null,[null,10]],[null,1115,null,[null,-1]],[1180,null,null,[1]],[1120,null,null,[1]]]]],[2,[[4,null,55],[1,[[12,null,null,null,2,null,\"smitmehta\\\\.com\/|autoplaced\\\\.com\/\"]]]]],49],[50,[[44768688],[44768689,[[1190,null,null,[1]]]]],null,57],[5,[[44768756,[[null,1103,null,[null,44768756]]]],[44768757,[[null,1103,null,[null,44768757]],[1143,null,null,[1]]]],[44768758,[[null,1103,null,[null,44768758]],[1120,null,null,[1]]]],[44768759,[[null,1103,null,[null,44768759]],[1182,null,null,[1]],[null,1114,null,[null,0.4]],[null,1110,null,[null,5]],[null,1111,null,[null,5]],[null,1112,null,[null,5]],[null,1113,null,[null,5]],[null,1104,null,[null,100]],[null,1106,null,[null,10]],[null,1107,null,[null,10]],[null,1105,null,[null,10]],[null,1115,null,[null,-1]],[1120,null,null,[1]]]]],[2,[[4,null,55],[1,[[12,null,null,null,2,null,\"smitmehta\\\\.com\/|autoplaced\\\\.com\/\"]]]]],49],[1,[[44768761,[[null,1103,null,[null,44768761]],[1121,null,null,[1]]]],[44768762,[[null,1103,null,[null,44768762]],[1182,null,null,[1]],[null,1114,null,[null,0.4]],[null,1110,null,[null,5]],[null,1111,null,[null,5]],[null,1112,null,[null,5]],[null,1113,null,[null,5]],[null,1104,null,[null,100]],[null,1106,null,[null,10]],[null,1107,null,[null,10]],[null,1105,null,[null,10]],[null,1115,null,[null,-1]],[1121,null,null,[1]],[1120,null,null,[1]]]]],[2,[[4,null,55],[1,[[12,null,null,null,2,null,\"smitmehta\\\\.com\/|autoplaced\\\\.com\/\"]]]]],49],[2,[[44768959,[[null,1158,null,[null,45]],[null,1157,null,[null,400]],[null,1103,null,[null,44768959]],[null,1114,null,[null,-1]],[null,1116,null,[null,50]],[null,1110,null,[null,5]],[null,1111,null,[null,5]],[null,1112,null,[null,5]],[null,1113,null,[null,5]],[null,1104,null,[null,100]],[null,1106,null,[null,10]],[null,1107,null,[null,10]],[null,1105,null,[null,10]],[null,1115,null,[null,-1]],[1162,null,null,[1]],[1120,null,null,[1]],[1164,null,null,[1]]]],[44768962,[[null,1158,null,[null,45]],[null,1157,null,[null,400]],[null,1103,null,[null,44768962]],[null,1114,null,[null,0.4]],[null,1116,null,[null,50]],[null,1110,null,[null,5]],[null,1111,null,[null,5]],[null,1112,null,[null,5]],[null,1113,null,[null,5]],[null,1104,null,[null,100]],[null,1106,null,[null,10]],[null,1107,null,[null,10]],[null,1105,null,[null,10]],[null,1115,null,[null,-1]],[1162,null,null,[1]],[1120,null,null,[1]],[1164,null,null,[1]]]]],[2,[[4,null,55],[1,[[12,null,null,null,2,null,\"smitmehta\\\\.com\/|autoplaced\\\\.com\/\"]]]]],49],[5,[[44769093,[[null,1103,null,[null,44769093]],[1182,null,null,[1]],[null,1114,null,[null,0.4]],[null,1110,null,[null,5]],[null,1111,null,[null,5]],[null,1112,null,[null,5]],[null,1113,null,[null,5]],[null,1104,null,[null,100]],[null,1106,null,[null,10]],[null,1107,null,[null,10]],[null,1105,null,[null,10]],[null,1115,null,[null,-1]],[1120,null,null,[1]]]],[44769094,[[null,1103,null,[null,44769094]],[1182,null,null,[1]],[null,1114,null,[null,0.4]],[null,1110,null,[null,5]],[null,1111,null,[null,5]],[null,1112,null,[null,5]],[null,1113,null,[null,5]],[null,1104,null,[null,200]],[null,1106,null,[null,10]],[null,1107,null,[null,10]],[null,1105,null,[null,10]],[null,1115,null,[null,-1]],[1120,null,null,[1]]]]],[2,[[4,null,55],[1,[[12,null,null,null,2,null,\"smitmehta\\\\.com\/|autoplaced\\\\.com\/\"]]]]],49],[5,[[44769096,[[null,1158,null,[null,45]],[null,1157,null,[null,400]],[null,1103,null,[null,44769096]],[1182,null,null,[1]],[null,1114,null,[null,-1]],[null,1116,null,[null,50]],[null,1110,null,[null,5]],[null,1111,null,[null,5]],[null,1112,null,[null,5]],[null,1113,null,[null,5]],[null,1104,null,[null,100]],[null,1106,null,[null,10]],[null,1107,null,[null,10]],[null,1105,null,[null,10]],[null,1115,null,[null,-1]],[1162,null,null,[1]],[1120,null,null,[1]],[1164,null,null,[1]]]],[44769097,[[null,1158,null,[null,45]],[null,1157,null,[null,400]],[null,1103,null,[null,44769097]],[1182,null,null,[1]],[null,1114,null,[null,-1]],[null,1116,null,[null,50]],[null,1110,null,[null,5]],[null,1111,null,[null,5]],[null,1112,null,[null,5]],[null,1113,null,[null,5]],[null,1104,null,[null,200]],[null,1106,null,[null,10]],[null,1107,null,[null,10]],[null,1105,null,[null,10]],[null,1115,null,[null,-1]],[1162,null,null,[1]],[1120,null,null,[1]],[1164,null,null,[1]]]]],[4,null,55],49],[1,[[44769431,[[null,1103,null,[null,44769431]],[1182,null,null,[1]],[null,1114,null,[null,0.4]],[null,1110,null,[null,5]],[null,1111,null,[null,5]],[null,1112,null,[null,5]],[null,1113,null,[null,5]],[null,1104,null,[null,100]],[null,1106,null,[null,10]],[null,1107,null,[null,10]],[null,1105,null,[null,10]],[null,1115,null,[null,-1]],[1120,null,null,[1]]]],[44769432,[[null,1103,null,[null,44769432]],[1182,null,null,[1]],[null,1114,null,[null,0.398]],[null,1110,null,[null,5]],[null,1111,null,[null,5]],[null,1112,null,[null,5]],[null,1113,null,[null,5]],[null,1104,null,[null,100]],[null,1106,null,[null,10]],[null,1107,null,[null,10]],[null,1105,null,[null,10]],[null,1115,null,[null,-1]],[1120,null,null,[1]]]]],[2,[[4,null,55],[1,[[12,null,null,null,2,null,\"smitmehta\\\\.com\/|autoplaced\\\\.com\/\"]]]]],49],[50,[[31061761],[31067422],[31067423,[[null,1032,null,[]]]],[31067605],[31068455],[31068456]],[3,[[4,null,8,null,null,null,null,[\"gmaSdk.getQueryInfo\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaQueryInfo.postMessage\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaSig.postMessage\"]]]],15]]],[20,[[50,[[31062930],[31062931,[[380025941,null,null,[1]]]]],null,null,null,null,null,101,null,102]]],[11,[[50,[[44766067],[44766069,[[1957,null,null,[1]]]]],null,48],[1,[[31067985],[31067986,[[447540095,null,null,[1]]]]],null,55],[100,[[31067987],[31067988,[[447540095,null,null,[1]]]]],[2,[[12,null,null,null,4,null,\"Chrome\/((?!100)\\\\d{3,})\",[\"navigator.userAgent\"]],[4,null,9,null,null,null,null,[\"document.browsingTopics\"]]]],55],[1,[[31068402],[31068403,[[447540098,null,null,[1]],[447540095,null,null,[1]],[447540096,null,null,[1]]]],[31068404,[[447540098,null,null,[1]],[447540095,null,null,[1]],[447540097,null,null,[1]],[447540096,null,null,[1]]]]],null,55]]],[17,[[10,[[21066430],[21066431],[21066432],[21066433]],null,null,null,44,22],[10,[[21066434],[21066435]],null,null,null,44,null,500],[10,[[31060047]],null,null,null,44,null,900],[10,[[31060048],[31060049]],null,null,null,null,null,null,null,101],[10,[[31060566]]],[10,[[31068405],[31068406,[[447540098,null,null,[1]],[447540095,null,null,[1]],[447540096,null,null,[1]]]],[31068407,[[447540098,null,null,[1]],[447540095,null,null,[1]],[447540097,null,null,[1]],[447540096,null,null,[1]]]]],[2,[[12,null,null,null,4,null,\"Chrome\/((?!100)\\\\d{3,})\",[\"navigator.userAgent\"]],[4,null,9,null,null,null,null,[\"document.browsingTopics\"]]]],null,null,null,null,null,null,112]]],[13,[[10,[[31065824],[31065825,[[424117738,null,null,[1]]]]]],[500,[[31061692],[31061693,[[77,null,null,[1]],[78,null,null,[1]],[85,null,null,[1]],[80,null,null,[1]],[76,null,null,[1]]]]],[4,null,6,null,null,null,null,[\"31061691\"]]],[50,[[31064018],[31064019,[[1961,null,null,[1]]]]]],[1000,[[31065981,null,[2,[[6,null,null,3,null,0],[12,null,null,null,4,null,\"Chrome\/(9[23456789]|\\\\d{3,})\",[\"navigator.userAgent\"]],[4,null,27,null,null,null,null,[\"crossOriginIsolated\"]]]]]]],[1000,[[31067146,null,[4,null,9,null,null,null,null,[\"document.browsingTopics\"]]]],[12,null,null,null,4,null,\"Chrome\/((?!100)\\\\d{3,})\",[\"navigator.userAgent\"]]],[1000,[[31067147,null,[2,[[4,null,9,null,null,null,null,[\"navigator.runAdAuction\"]],[4,null,9,null,null,null,null,[\"navigator.joinAdInterestGroup\"]]]]]],[12,null,null,null,4,null,\"Chrome\/((?!100)\\\\d{3,})\",[\"navigator.userAgent\"]]],[1000,[[31067148,null,[4,null,8,null,null,null,null,[\"attributionReporting\"]]]],[12,null,null,null,4,null,\"Chrome\/((?!100)\\\\d{3,})\",[\"navigator.userAgent\"]]],[1000,[[31067672,null,[2,[[4,null,69,null,null,null,null,[\"browsing-topics\"]],[1,[[4,null,70,null,null,null,null,[\"browsing-topics\"]]]]]]]],[12,null,null,null,4,null,\"Chrome\/((?!100)\\\\d{3,})\",[\"navigator.userAgent\"]]],[1000,[[31067673,null,[2,[[4,null,69,null,null,null,null,[\"join-ad-interest-group\"]],[1,[[4,null,70,null,null,null,null,[\"join-ad-interest-group\"]]]]]]]],[12,null,null,null,4,null,\"Chrome\/((?!100)\\\\d{3,})\",[\"navigator.userAgent\"]]],[1000,[[31067674,null,[2,[[4,null,69,null,null,null,null,[\"run-ad-auction\"]],[1,[[4,null,70,null,null,null,null,[\"run-ad-auction\"]]]]]]]],[12,null,null,null,4,null,\"Chrome\/((?!100)\\\\d{3,})\",[\"navigator.userAgent\"]]],[1000,[[31067675,null,[2,[[4,null,69,null,null,null,null,[\"attribution-reporting\"]],[1,[[4,null,70,null,null,null,null,[\"attribution-reporting\"]]]]]]]],[12,null,null,null,4,null,\"Chrome\/((?!100)\\\\d{3,})\",[\"navigator.userAgent\"]]],[null,[[44768158,null,[2,[[4,null,8,null,null,null,null,[\"attributionReporting\"]],[4,null,70,null,null,null,null,[\"attribution-reporting\"]]]]],[44768159,null,[2,[[4,null,8,null,null,null,null,[\"attributionReporting\"]],[4,null,70,null,null,null,null,[\"attribution-reporting\"]]]]]]]]]],null,null,[0.001,\"1000\",1,\"1000\"]],null,[[\"ca-pub-8739233621395816\",\"ca-pub-4764333688337558\",\"ca-pub-2754312069774654\",\"ca-pub-2104961258307381\",\"ca-pub-2316275586951220\"],[null,[]]],null,null,null,2026685943,[44759876,44759927,44759842,44763506,44761793]]");