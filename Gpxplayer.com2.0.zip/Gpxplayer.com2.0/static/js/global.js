var categoryList = [
  ["Action", "0"],
  [".IO", "1"],
  ["2Player", "2"],
  ["3D", "3"],
  ["Adventure", "4"],
  ["Arcade", "5"],
  ["Bejeweled", "6"],
  ["Boys", "7"],
  ["Clicker", "8"],
  ["Cooking", "9"],
  ["Girls", "10"],
  ["Hypercasual", "11"],
  ["Multiplayer", "12"],
  ["Puzzle", "13"],
  ["Racing", "14"],
  ["Shooting", "15"],
  ["Soccer", "16"],
  ["Sports", "17"],
  ["Stickman", "18"],
  ["Baby Hazel", "19"],
];


var _menu = "";
var _more = "";
categoryList.forEach(function (item, index) {
  if (index <= 8) {
    _menu += `
  <a href="./category.html?category=${item[1]}" class="classify-item">${item[0]}</a>`;
  } else {
    _more += `
    <a href="./category.html?category=${item[1]}" class="more_content-item">${item[0]}</a>`;
  }
});

$(".classify_games").html(_menu + $(".classify_games").html());
$(".moreContent").html(_more);

$(".classify-item-more").mouseenter(function () {
  $(".moreContent").show();
});
$(document).mouseover(function (e) {
  if (
    e.target != $(".classify-item-more")[0] &&
    e.target != $(".moreContent")[0] &&
    checkEl(e.target)
  ) {
    $(".moreContent").hide();
  }

  function checkEl(el) {
    var tempFlag = true;
    $(".more_content-item").each(function () {
      if ($(this)[0] == el) {
        tempFlag = false;
      }
    });
    return tempFlag;
  }
});
